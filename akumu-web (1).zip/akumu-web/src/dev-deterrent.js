// A LIGHT deterrent against casual right-click/inspect access. This does
// NOT stop anyone determined (devtools can still be opened via the browser
// menu, F12 can be remapped, etc.) — it only removes the easiest, most
// casual paths so a browsing customer doesn't stumble into "View Source"
// by accident. Real protection of business logic belongs on a server,
// not in client-side JavaScript. Only runs in production builds so it
// never gets in the way during local development.
if (import.meta.env.PROD) {
  document.addEventListener("contextmenu", (e) => e.preventDefault());

  document.addEventListener("keydown", (e) => {
    const blockedKey =
      e.key === "F12" ||
      (e.ctrlKey && e.shiftKey && ["I", "J", "C"].includes(e.key.toUpperCase())) ||
      (e.ctrlKey && e.key.toUpperCase() === "U");
    if (blockedKey) e.preventDefault();
  });
}

import React, { useState, useMemo, useEffect, useRef } from "react";
import {
  Home as HomeIcon,
  ShoppingCart,
  User,
  Search,
  Plus,
  Minus,
  ChevronLeft,
  Check,
  Truck,
  Smartphone,
  Wallet,
  CreditCard,
  MapPin,
  Trash2,
  Star,
  Package,
  Clock,
  CheckCircle2,
  ClipboardList,
  RefreshCw,
  Heart,
  Tag,
  MessageSquare,
  Bell,
  Ticket,
  X,
  Send,
  Phone,
  Mail,
  Edit3,
  HelpCircle,
  ChevronDown,
  SlidersHorizontal,
  Scale,
  Sun,
  Moon,
  Eye,
  RotateCcw,
  Gift,
} from "lucide-react";
import logoImg from "./assets/logo.png";
import wordmarkImg from "./assets/wordmark.svg";

/* ---------------------------------------------------
   design tokens (theme-aware)
   ---------------------------------------------------
   COLORS.xxx is used in hundreds of places across this file as a plain
   object property read. Instead of threading a "theme" prop through every
   single component, CURRENT_THEME is a module-level flag that App sets
   synchronously at the top of its render (before any child renders), and
   COLORS is a Proxy that resolves each property against the active
   palette. Every existing `COLORS.green`, `COLORS.bg`, etc. call site
   keeps working exactly as before, but now returns the right color for
   the active theme.
--------------------------------------------------- */
const PALETTES = {
  light: {
    frame: "#DDD8C8",
    bg: "#F3EEE2",
    surface: "#FFFFFF",
    ink: "#232A20",
    inkMuted: "#767C6C",
    line: "#E6E0CE",
    green: "#2C4A3B",
    greenDark: "#1C3226",
    greenSoft: "#E6EDE6",
    gold: "#C79A2B",
    goldSoft: "#F3E3B0",
    goldText: "#8A6A12",
    danger: "#B4462D",
    dangerSoft: "#FBEAE5",
    shimmer: "#EFE9D8",
  },
  dark: {
    frame: "#0E1210",
    bg: "#171B16",
    surface: "#20251E",
    ink: "#F1EFE6",
    inkMuted: "#9BA394",
    line: "#333B2F",
    green: "#6FA485",
    greenDark: "#4C7A61",
    greenSoft: "#26302A",
    gold: "#DCB24E",
    goldSoft: "#3A3220",
    goldText: "#E8C468",
    danger: "#E17A5D",
    dangerSoft: "#3A241E",
    shimmer: "#3A4335",
  },
};

let CURRENT_THEME = "light";

const COLORS = new Proxy(
  {},
  {
    get(_target, prop) {
      return PALETTES[CURRENT_THEME][prop];
    },
  }
);

const FONT_IMPORT = `
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800&family=Tajawal:wght@500;700;800&display=swap');

@keyframes ak-shimmer {
  0% { background-position: 100% 0; }
  100% { background-position: -100% 0; }
}
@keyframes ak-fadein {
  from { opacity: 0; transform: translateY(6px); }
  to { opacity: 1; transform: translateY(0); }
}
@keyframes ak-pulse-dot {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.4; }
}
button {
  transition: transform 0.12s ease, opacity 0.12s ease;
}
button:active {
  transform: scale(0.96);
}
`;

/* ---------------------------------------------------
   IMAGES
   ---------------------------------------------------
   Your original file has 8 real base64 image constants:
   UP_CARGO_GREEN, UP_DRESS_BUTTERFLY, UP_DRESS_LACE_BLACK, UP_SET_BLUE,
   UP_MEN_SHIRT_GREY, UP_MEN_TUX_BLACK, UP_MEN_JACKET_NAVY, LOGO_IMG.
   They're each tens of KB of base64 text, so I can't safely retype them
   here without risking corrupting the image data. Placeholders are used
   below instead. To restore your real photos: paste your 8 original
   `const UP_..." = "data:image/jpeg;base64,..."` lines (and LOGO_IMG)
   right below this comment, then change each `img:` value in PRODUCTS
   from the picsum URL back to the matching UP_* constant, and change
   `src={LOGO_IMG}` in HomeScreen back to the real logo (it already
   references LOGO_IMG by name, so once the constant exists above it,
   that line needs no further edit).
--------------------------------------------------- */
const LOGO_IMG = logoImg;
const WORDMARK_IMG = wordmarkImg;

/* ---------------------------------------------------
   sample catalog
--------------------------------------------------- */
const CATEGORIES = [
  { id: "all" },
  { id: "women" },
  { id: "men" },
  { id: "smartwear" },
];

const money = (n) => n.toLocaleString("en-US") + " ل.س";
const DELIVERY_FEE = 8000;
const FREE_SHIPPING_THRESHOLD = 200000;
const getDelivery = (subtotal) => (subtotal > 0 && subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : DELIVERY_FEE);
const variantKey = (id, size, color) => `${id}|${size}|${color}`;

const getReferralCode = (user) => {
  if (!user) return "";
  const namePart = (user.name || "AKM").replace(/\s/g, "").slice(0, 3).toUpperCase();
  const phonePart = (user.phone || "0000").slice(-4);
  return `${namePart}${phonePart}`;
};

// Hashes the vendor PIN with SHA-256 before it's ever stored, so the raw
// 4-digit code never sits in plaintext in localStorage. This isn't
// bank-grade security (a 4-digit PIN's keyspace is small either way) but
// it means anyone poking through storage sees an opaque hash, not the
// actual code.
async function hashPin(pin) {
  const bytes = new TextEncoder().encode(pin);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

const COUPONS = {
  AKUMU10: { type: "percent", value: 10 },
  WELCOME20: { type: "flat", value: 20000 },
  NEWUSER: { type: "percent", value: 15 },
};

const PRODUCTS = [
  { id: 11, name: "جاكيت تدفئة ذكي", cat: "smartwear", price: 265000, seed: "heatjacket1", img: "https://picsum.photos/seed/heatjacket1/400/400", images: ["https://picsum.photos/seed/heatjacket1/400/400", "https://picsum.photos/seed/heatjacket1b/400/400", "https://picsum.photos/seed/heatjacket1c/400/400"], rating: 4.6, badge: "جديد", sizes: ["S", "M", "L", "XL"], colors: ["أسود", "كحلي"], stock: 14 },
  { id: 12, name: "تيشيرت تتبع اللياقة", cat: "smartwear", price: 98000, seed: "fitshirt1", img: "https://picsum.photos/seed/fitshirt1/400/400", images: ["https://picsum.photos/seed/fitshirt1/400/400", "https://picsum.photos/seed/fitshirt1b/400/400", "https://picsum.photos/seed/fitshirt1c/400/400"], rating: 4.3, sizes: ["S", "M", "L", "XL"], colors: ["أسود", "رمادي"], stock: 6 },
  { id: 13, name: "قبعة LED مضيئة", cat: "smartwear", price: 54000, seed: "ledcap1", img: "https://picsum.photos/seed/ledcap1/400/400", images: ["https://picsum.photos/seed/ledcap1/400/400", "https://picsum.photos/seed/ledcap1b/400/400", "https://picsum.photos/seed/ledcap1c/400/400"], rating: 4.0, sizes: ["مقاس واحد"], colors: ["أسود"], stock: 22 },
  { id: 14, name: "حزام ذكي متعدد الاستخدامات", cat: "smartwear", price: 72000, seed: "smartbelt1", img: "https://picsum.photos/seed/smartbelt1/400/400", images: ["https://picsum.photos/seed/smartbelt1/400/400", "https://picsum.photos/seed/smartbelt1b/400/400", "https://picsum.photos/seed/smartbelt1c/400/400"], rating: 4.4, sizes: ["S/M", "L/XL"], colors: ["أسود", "بني"], stock: 9 },
  { id: 15, name: "جوارب تدفئة كهربائية", cat: "smartwear", price: 61000, seed: "heatsocks1", img: "https://picsum.photos/seed/heatsocks1/400/400", images: ["https://picsum.photos/seed/heatsocks1/400/400", "https://picsum.photos/seed/heatsocks1b/400/400", "https://picsum.photos/seed/heatsocks1c/400/400"], rating: 4.2, badge: "الأكثر مبيعاً", sizes: ["S/M", "L/XL"], colors: ["أسود"], stock: 18 },
  { id: 16, name: "طقم كارغو نسائي كاكي", cat: "women", price: 89000, seed: "cargogreen", img: "https://loremflickr.com/400/400/cargo,pants,women", images: ["https://loremflickr.com/400/400/cargo,pants,women", "https://loremflickr.com/400/400/khaki,outfit", "https://loremflickr.com/400/400/street,style,women"], rating: 4.5, badge: "جديد", sizes: ["S", "M", "L", "XL"], colors: ["كاكي"], stock: 7 },
  { id: 17, name: "فستان سهرة فراشات ذهبي", cat: "women", price: 175000, seed: "butterflydress", img: "https://loremflickr.com/400/400/gold,evening,dress", images: ["https://loremflickr.com/400/400/gold,evening,dress", "https://loremflickr.com/400/400/butterfly,dress", "https://loremflickr.com/400/400/glamour,dress"], rating: 4.8, badge: "جديد", sizes: ["S", "M", "L"], colors: ["بني/ذهبي"], stock: 3 },
  { id: 18, name: "فستان دانتيل أسود أنيق", cat: "women", price: 132000, seed: "blacklace", img: "https://loremflickr.com/400/400/black,lace,dress", images: ["https://loremflickr.com/400/400/black,lace,dress", "https://loremflickr.com/400/400/elegant,dress", "https://loremflickr.com/400/400/little,black,dress"], rating: 4.7, sizes: ["S", "M", "L", "XL"], colors: ["أسود"], stock: 11 },
  { id: 19, name: "طقم صيفي أزرق كتف مكشوف", cat: "women", price: 96000, seed: "bluesetoff", img: "https://loremflickr.com/400/400/blue,summer,dress", images: ["https://loremflickr.com/400/400/blue,summer,dress", "https://loremflickr.com/400/400/off,shoulder,top", "https://loremflickr.com/400/400/beach,outfit,women"], rating: 4.6, sizes: ["S", "M", "L"], colors: ["أزرق فاتح"], stock: 9 },
  { id: 20, name: "قميص وبنطال رجالي كاجوال", cat: "men", price: 74000, seed: "greysuitmen", img: "https://loremflickr.com/400/400/men,shirt,casual", images: ["https://loremflickr.com/400/400/men,shirt,casual", "https://loremflickr.com/400/400/menswear", "https://loremflickr.com/400/400/casual,outfit,men"], rating: 4.4, sizes: ["M", "L", "XL", "XXL"], colors: ["رمادي", "أسود"], stock: 16 },
  { id: 21, name: "بدلة سموكينج رجالية سوداء", cat: "men", price: 310000, seed: "tuxblack", img: "https://loremflickr.com/400/400/tuxedo,suit,men", images: ["https://loremflickr.com/400/400/tuxedo,suit,men", "https://loremflickr.com/400/400/black,tie,event", "https://loremflickr.com/400/400/formal,suit,men"], rating: 4.9, badge: "جديد", sizes: ["M", "L", "XL", "XXL"], colors: ["أسود"], stock: 4 },
  { id: 22, name: "جاكيت كاجوال كحلي رجالي", cat: "men", price: 118000, seed: "navyjacketmen", img: "https://loremflickr.com/400/400/jacket,men,navy", images: ["https://loremflickr.com/400/400/jacket,men,navy", "https://loremflickr.com/400/400/menswear,jacket", "https://loremflickr.com/400/400/casual,jacket,men"], rating: 4.5, sizes: ["S", "M", "L", "XL"], colors: ["كحلي"], stock: 13 },
];

const PAYMENT_METHODS = [
  { id: "cod", icon: Truck, badge: true },
  { id: "syriatel", icon: Smartphone },
  { id: "sham", icon: Wallet },
  { id: "mtn", icon: Smartphone },
  { id: "card", icon: CreditCard, badge: true },
];

/* ---------------------------------------------------
   i18n
--------------------------------------------------- */
const STRINGS = {
  ar: {
    dir: "rtl", font: "Cairo",
    nav_home: "الرئيسية", nav_cart: "السلة", nav_account: "حسابي",
    account_title: "حسابي",
    account_login_prompt: "سجّلي دخولك عشان تتابعي طلبياتك",
    account_login_cta: "تسجيل الدخول",
    account_logout: "تسجيل الخروج",
    account_orders: "طلبياتي", account_favorites: "المفضلة",
    account_coupons: "كوبوناتي", account_reviews: "تقييماتي",
    account_all_orders: "كل طلبياتي", account_reorder: "إعادة الطلب",
    account_language: "اللغة", account_soon: "قريباً",
    login_title: "تسجيل الدخول", signup_title: "إنشاء حساب",
    tab_login: "تسجيل الدخول", tab_signup: "إنشاء حساب",
    login_subtitle: "سجّلي دخولك لإتمام الطلب ومتابعة طلبياتك",
    signup_subtitle: "أنشئي حساب جديد بثواني",
    label_name: "الاسم", label_phone: "رقم الموبايل", label_email: "البريد الإلكتروني",
    placeholder_name: "اسمك الكامل", placeholder_email: "example@email.com",
    placeholder_short_name: "اسمك",
    btn_login: "تسجيل الدخول", btn_signup: "إنشاء الحساب",
    switch_to_signup: "ما عندك حساب؟ إنشئي واحد", switch_to_login: "عندك حساب؟ سجّلي دخولك",
    validation_name: "الاسم لازم يكون حرفين ع الأقل",
    validation_email: "أدخلي بريد إلكتروني صحيح",
    validation_phone: "رقم الموبايل لازم يبلش بـ 09 وطوله 10 أرقام",
    search_placeholder: "ابحث عن منتج...",
    location_label: "دمشق، سوريا",
    cat_all: "الكل", cat_women: "أزياء نسائية", cat_men: "أزياء رجالية", cat_smartwear: "ملابس إلكترونية",
    sort_default: "الأحدث", sort_price_asc: "السعر: الأقل", sort_price_desc: "السعر: الأعلى", sort_rating: "الأعلى تقييم",
    out_of_stock_badge: "نفذت الكمية", out_of_stock_line: "غير متوفر", low_stock: "باقي {n}",
    cart_title: "سلة التسوق", cart_empty: "سلتك فاضية لهلق", cart_subtotal: "المجموع الفرعي", cart_delivery: "التوصيل",
    cart_total: "الإجمالي", cart_checkout: "المتابعة للدفع", pieces_label: "قطع",
    free_shipping_hint: "ضيفي منتجات بـ {amount} كمان ليصير التوصيل مجاني",
    free_shipping_unlocked: "مبروك! التوصيل مجاني لهالطلبية",
    free_label: "مجاني",
    checkout_title: "إتمام الطلب", checkout_address: "عنوان التوصيل", checkout_add_address: "إضافة عنوان",
    checkout_payment: "طرق الدفع", checkout_confirm: "تأكيد الطلب", checkout_coupon: "كود الخصم",
    checkout_total_amount: "المبلغ الإجمالي",
    address_name_placeholder: "اسم العنوان (البيت، الشغل...)",
    address_text_placeholder: "الحي، الشارع، أقرب نقطة مميزة",
    address_save_btn: "حفظ العنوان",
    address_empty_hint: "ما في عندك عنوان محفوظ، ضيفي واحد",
    coupon_placeholder: "أدخلي كود الخصم", coupon_apply_btn: "تطبيق", coupon_invalid: "كود الخصم غير صحيح",
    pay_cod_name: "الدفع عند الاستلام", pay_cod_desc: "ادفعي كاش لما توصلك الطلبية",
    pay_syriatel_name: "سيريتل كاش", pay_sham_name: "شام كاش", pay_mtn_name: "إم تي إن كاش",
    pay_wallet_desc: "ادفعي مباشرة من محفظتك",
    pay_card_name: "بطاقة بنكية", pay_card_desc: "فيزا / ماستركارد",
    pay_cod_badge: "الأكثر استخداماً", pay_card_badge: "جديد",
    no_results: "ما في نتائج مطابقة",
    home_bestsellers_title: "الأكثر مبيعاً",
    home_new_arrivals_title: "وصل حديثاً",
    continue_shopping_btn: "تسوقي الآن",
    confirm_welcome_title: "يا هلا فيكي بعائلة Akumu!",
    confirm_title: "تم استلام طلبك!",
    confirm_order_number: "رقم الطلب",
    confirm_subtitle: "رح نتواصل معك قريباً لتأكيد التوصيل",
    confirm_gift_title: "هدية أول طلبية",
    confirm_gift_desc: "استخدمي كود WELCOME20 بالطلبية الجاية واحصلي على خصم 20,000 ل.س",
    confirm_track_btn: "تتبع الطلبية", confirm_home_btn: "العودة للرئيسية",
    order_step_placed: "تم استلام الطلب", order_step_preparing: "قيد التجهيز",
    order_step_shipping: "بالطريق إليك", order_step_delivered: "تم التوصيل",
    order_status_cancelled: "ملغى",
    product_detail_title: "تفاصيل المنتج",
    product_reviews_count: "تقييم",
    product_out_of_stock: "نفذت الكمية من هالمنتج",
    product_low_stock: "باقي {n} قطع بس!",
    product_size_label: "المقاس", product_color_label: "اللون",
    product_description_label: "الوصف",
    product_description_text: "{name} بجودة عالية وتصميم أنيق، مناسب للاستخدام اليومي والمناسبات. التوصيل خلال 2-4 أيام لكل المحافظات.",
    product_related_title: "منتجات قد تعجبك",
    product_reviews_title: "التقييمات والمراجعات",
    product_no_reviews: "ما في تقييمات لهلق، كوني أول وحدة تكتب رأيها",
    product_add_review: "ضيفي تقييمك",
    placeholder_review_comment: "شو رأيك بالمنتج؟",
    product_publish_review: "نشر التقييم",
    product_out_of_stock_btn: "نفذت الكمية",
    product_add_to_cart: "إضافة للسلة",
    contact_title: "تواصل معنا",
    contact_whatsapp: "واتساب", contact_phone: "اتصال هاتفي", contact_email: "البريد الإلكتروني",
    contact_faq_title: "أسئلة شائعة",
    edit_profile_title: "تعديل بيانات الحساب",
    edit_profile_save: "حفظ التعديلات",
    notifications_title: "الإشعارات",
    notifications_empty: "ما في إشعارات لهلق",
    favorites_empty: "ما ضفتي شي عالمفضلة لهلق",
    orders_search_placeholder: "دوّري برقم الطلب أو اسم المنتج",
    orders_empty: "ما عندك طلبيات لهلق",
    order_label: "طلب",
    order_copy: "نسخ رقم الطلب", order_copied: "تم النسخ!",
    share_label: "مشاركة",
    order_cancelled_msg: "تم إلغاء هالطلب",
    order_current_status: "الحالة الحالية",
    order_simulate_update: "محاكاة تحديث الحالة (تجريبي)",
    order_cancel_btn: "إلغاء الطلب",
    order_details_title: "تفاصيل الطلب",
    order_payment_method: "طريقة الدفع",
    order_coupon_label: "كود الخصم",
    notif_status_change: 'طلبك #{id} صار "{status}"',
    notif_order_cancelled: "تم إلغاء طلبك #{id}",
    notif_cart_reminder: "عندك {n} قطع بالسلة بتستناك، أكملي طلبك قبل ما تخلص الكمية!",
    filter_btn: "فلترة",
    filter_title: "فلترة النتائج",
    filter_price_label: "السعر",
    filter_price_all: "الكل",
    filter_price_under75: "أقل من 75,000",
    filter_price_75_150: "75,000 - 150,000",
    filter_price_150_250: "150,000 - 250,000",
    filter_price_above250: "أكتر من 250,000",
    filter_rating_label: "التقييم",
    filter_rating_all: "الكل",
    filter_rating_4: "4 نجوم فما فوق",
    filter_rating_45: "4.5 نجوم فما فوق",
    filter_clear: "مسح الفلاتر",
    filter_apply: "تطبيق",
    home_recently_viewed_title: "شاهدتها مؤخراً",
    compare_toggle_add: "أضيفي للمقارنة",
    compare_toggle_remove: "شيلي من المقارنة",
    compare_max_reached: "أقصى عدد 3 منتجات بالمقارنة",
    compare_bar_label: "قارني",
    compare_bar_clear: "مسح",
    compare_title: "مقارنة المنتجات",
    compare_empty: "ما ضفتي منتجات للمقارنة لهلق",
    compare_price_row: "السعر",
    compare_rating_row: "التقييم",
    compare_stock_row: "التوفر",
    compare_sizes_row: "المقاسات",
    compare_colors_row: "الألوان",
    compare_in_stock: "متوفر",
    dark_mode_label: "الوضع الداكن",
    size_guide_link: "دليل المقاسات",
    size_guide_title: "دليل المقاسات",
    size_guide_col_size: "المقاس",
    size_guide_col_chest: "الصدر (سم)",
    size_guide_col_waist: "الخصر (سم)",
    size_guide_col_length: "الطول (سم)",
    notify_stock_btn: "نبّهيني لما يتوفر",
    notify_stock_subscribed_btn: "رح نبلغك عند التوفر",
    notify_stock_toast: "تمام! رح نبلغك أول ما يتوفر المنتج",
    address_edit_btn: "تعديل",
    address_delete_btn: "حذف",
    address_edit_title: "تعديل العنوان",
    address_deleted_toast: "تم حذف العنوان",
    rating_breakdown_title: "توزيع التقييمات",
    rating_based_on: "بناءً على {n} تقييم",
    onboard_skip: "تخطي",
    onboard_next: "التالي",
    onboard_start: "ابدأي التسوق",
    loyalty_points_label: "نقاطي",
    loyalty_points_balance: "{n} نقطة",
    loyalty_earn_note: "بتكسبي نقطة عن كل 1,000 ل.س من كل طلبية",
    loyalty_redeem_toggle: "استخدمي 100 نقطة = خصم 5,000 ل.س",
    loyalty_redeem_need_more: "لازم يكون عندك 100 نقطة ع الأقل",
    loyalty_earned_toast: "كسبتي {n} نقطة من هالطلبية!",
    return_request_btn: "طلب إرجاع/استبدال",
    return_request_title: "طلب إرجاع أو استبدال",
    return_type_label: "نوع الطلب",
    return_type_return: "إرجاع",
    return_type_exchange: "استبدال",
    return_reason_label: "سبب الطلب",
    return_reason_placeholder: "احكيلنا شو المشكلة...",
    return_submit_btn: "إرسال الطلب",
    return_status_pending: "طلب الإرجاع قيد المراجعة",
    return_already_requested: "تم إرسال طلبك، رح نتواصل معك قريباً",
    complete_look_title: "منتجات بتكمل بعض",
    cart_suggestions_title: "أكملي طلبك",
    favorites_share_btn: "مشاركة المفضلة",
    account_reorder_btn: "إعادة الطلب",
    reorder_added_toast: "تمت إضافة القطع المتوفرة لسلتك",
    reorder_none_available: "للأسف كل قطع هالطلب نفدت من المخزون",
    referral_title: "دعوة أصدقاء",
    referral_desc: "شاركي كودك مع صاحباتك، وكل وحدة تستخدمه بتاخد 50 نقطة إضافية!",
    referral_code_label: "كودك الخاص",
    referral_share_btn: "مشاركة الكود",
    referral_share_text: "أهلين! جربي تطبيق Akumu للتسوق واستخدمي كودي {code} وخدي 50 نقطة إضافية 🎁",
    delivery_slot_label: "موعد التوصيل",
    delivery_slot_any: "أي وقت",
    delivery_slot_morning: "صباحي (9ص - 1ظ)",
    delivery_slot_evening: "مسائي (3م - 7م)",
    gift_wrap_toggle: "تغليف كهدية (+5,000 ل.س)",
    gift_message_placeholder: "اكتبي رسالة مرفقة مع الهدية (اختياري)",
    deals_title: "العروض والخصومات",
    deals_coupons_section: "أكواد الخصم المتوفرة",
    deals_products_section: "منتجات بعروض",
    deals_empty: "ما في عروض حالياً، رجعي لاحقاً",
    search_recent_title: "عمليات بحث سابقة",
    search_clear_history: "مسح",
    search_trending_title: "بحث شائع",
    my_reviews_title: "تقييماتي",
    my_reviews_empty: "لسا ما كتبتي أي تقييم، جربي منتج وشاركينا رأيك فيه",
    notif_prefs_title: "تفضيلات الإشعارات",
    notif_pref_order_updates: "تحديثات الطلبيات",
    notif_pref_cart_reminders: "تذكير السلة المتروكة",
    notif_pref_promotions: "العروض والتخفيضات",
    about_title: "عن التطبيق",
    about_version_label: "الإصدار",
    about_description: "Akumu متجر إلكتروني للأزياء النسائية والرجالية والملابس الذكية، بيوصلك بكل مكان بسوريا.",
    about_legal_title: "الشروط والخصوصية",
    about_terms_title: "شروط الاستخدام",
    about_terms_text: "باستخدامك تطبيق Akumu، إنتِ موافقة على شروط الاستخدام المتعلقة بالطلبيات والدفع والتوصيل. للمزيد من التفاصيل تواصلي معنا.",
    about_privacy_title: "سياسة الخصوصية",
    about_privacy_text: "بنحافظ على خصوصية بياناتك ومنستخدمها إلا لتحسين تجربتك بالتسوق وتوصيل طلبياتك. ما بنشارك معلوماتك مع أي طرف ثالث بدون إذنك.",
    cart_select_all: "تحديد الكل",
    cart_deselect_all: "إلغاء التحديد",
    cart_delete_selected: "حذف المحدد",
    cart_selected_count: "{n} محدد",
    product_qa_title: "أسئلة عن المنتج",
    product_qa_empty: "ما في أسئلة لهلق، اسألي أول سؤال",
    product_ask_question: "اسألي سؤال",
    placeholder_question: "شو حابة تعرفي عن المنتج؟",
    product_qa_submit: "إرسال السؤال",
    product_qa_pending: "بانتظار رد المتجر",
    flash_sale_title: "عرض محدود",
    flash_sale_ends_in: "بينتهي خلال",
    flash_sale_hours: "س",
    flash_sale_minutes: "د",
    flash_sale_seconds: "ث",
    chat_bubble_label: "تواصل مباشر",
    chat_title: "الدعم المباشر",
    chat_welcome_message: "أهلين! كيف فينا نساعدك اليوم؟",
    chat_input_placeholder: "اكتبي رسالتك...",
    chat_auto_reply: "شكراً لتواصلك معنا! فريق الدعم رح يرد عليك بأقرب وقت 💬",
    chat_send: "إرسال",
    vendor_panel_label: "لوحة البائع",
    vendor_dashboard_title: "لوحة البائع",
    vendor_tab_dashboard: "نظرة عامة",
    vendor_tab_products: "المنتجات",
    vendor_tab_orders: "الطلبيات",
    vendor_stat_orders: "الطلبيات",
    vendor_stat_revenue: "الإيرادات",
    vendor_stat_products: "المنتجات",
    vendor_stat_low_stock: "كمية منخفضة",
    vendor_add_product_btn: "إضافة منتج",
    vendor_edit_product_title: "تعديل المنتج",
    vendor_new_product_title: "منتج جديد",
    vendor_product_name_placeholder: "اسم المنتج",
    vendor_product_price_placeholder: "السعر (ل.س)",
    vendor_product_stock_placeholder: "الكمية بالمخزون",
    vendor_product_category_label: "الفئة",
    vendor_product_sizes_placeholder: "المقاسات (مفصولة بفاصلة)، مثلاً: S,M,L",
    vendor_product_colors_placeholder: "الألوان (مفصولة بفاصلة)، مثلاً: أسود,أبيض",
    vendor_save_product_btn: "حفظ المنتج",
    vendor_delete_product_btn: "حذف",
    vendor_edit_product_btn: "تعديل",
    vendor_no_products: "ما عندك منتجات بعد",
    vendor_no_orders: "ما في طلبيات لهلق",
    vendor_low_stock_badge: "كمية منخفضة",
    vendor_out_of_stock_badge: "نفدت الكمية",
    vendor_product_saved_toast: "تم حفظ المنتج",
    vendor_product_deleted_toast: "تم حذف المنتج",
    vendor_view_storefront: "عرض المتجر كزبونة",
    login_vendor_checkbox: "أنا بائعة، عندي متجر على Akumu",
    login_vendor_pin_label: "رمز دخول لوحة البائع (٤ أرقام)",
    login_vendor_pin_placeholder: "مثلاً: 1234",
    validation_vendor_pin: "الرمز لازم يكون ٤ أرقام",
    vendor_pin_gate_title: "الدخول للوحة البائع",
    vendor_pin_gate_subtitle: "أدخلي رمز الدخول الخاص فيك",
    vendor_pin_gate_placeholder: "••••",
    vendor_pin_gate_submit: "دخول",
    vendor_pin_gate_error: "الرمز غير صحيح",
  },
  en: {
    dir: "ltr", font: "Cairo",
    nav_home: "Home", nav_cart: "Cart", nav_account: "Account",
    account_title: "My Account",
    account_login_prompt: "Log in to track your orders",
    account_login_cta: "Log In",
    account_logout: "Log Out",
    account_orders: "My Orders", account_favorites: "Favorites",
    account_coupons: "My Coupons", account_reviews: "My Reviews",
    account_all_orders: "All Orders", account_reorder: "Reorder",
    account_language: "Language", account_soon: "Soon",
    login_title: "Log In", signup_title: "Sign Up",
    tab_login: "Log In", tab_signup: "Sign Up",
    login_subtitle: "Log in to complete your order and track it",
    signup_subtitle: "Create a new account in seconds",
    label_name: "Name", label_phone: "Phone Number", label_email: "Email",
    placeholder_name: "Your full name", placeholder_email: "example@email.com",
    placeholder_short_name: "Your name",
    btn_login: "Log In", btn_signup: "Create Account",
    switch_to_signup: "No account? Sign up", switch_to_login: "Have an account? Log in",
    validation_name: "Name must be at least 2 characters",
    validation_email: "Enter a valid email address",
    validation_phone: "Phone number must start with 09 and be 10 digits",
    search_placeholder: "Search for a product...",
    location_label: "Damascus, Syria",
    cat_all: "All", cat_women: "Women", cat_men: "Men", cat_smartwear: "Smart Wear",
    sort_default: "Newest", sort_price_asc: "Price: Low to High", sort_price_desc: "Price: High to Low", sort_rating: "Top Rated",
    out_of_stock_badge: "Out of stock", out_of_stock_line: "Unavailable", low_stock: "{n} left",
    cart_title: "Shopping Cart", cart_empty: "Your cart is empty", cart_subtotal: "Subtotal", cart_delivery: "Delivery",
    cart_total: "Total", cart_checkout: "Proceed to Checkout", pieces_label: "items",
    free_shipping_hint: "Add {amount} more to unlock free delivery",
    free_shipping_unlocked: "You've unlocked free delivery on this order",
    free_label: "Free",
    checkout_title: "Checkout", checkout_address: "Delivery Address", checkout_add_address: "Add Address",
    checkout_payment: "Payment Methods", checkout_confirm: "Confirm Order", checkout_coupon: "Discount Code",
    checkout_total_amount: "Total Amount",
    address_name_placeholder: "Address label (Home, Work...)",
    address_text_placeholder: "Neighborhood, street, nearest landmark",
    address_save_btn: "Save Address",
    address_empty_hint: "You don't have a saved address yet, add one",
    coupon_placeholder: "Enter discount code", coupon_apply_btn: "Apply", coupon_invalid: "Invalid discount code",
    pay_cod_name: "Cash on Delivery", pay_cod_desc: "Pay cash when your order arrives",
    pay_syriatel_name: "Syriatel Cash", pay_sham_name: "Sham Cash", pay_mtn_name: "MTN Cash",
    pay_wallet_desc: "Pay directly from your wallet",
    pay_card_name: "Bank Card", pay_card_desc: "Visa / Mastercard",
    pay_cod_badge: "Most used", pay_card_badge: "New",
    no_results: "No matching results",
    home_bestsellers_title: "Best Sellers",
    home_new_arrivals_title: "New Arrivals",
    continue_shopping_btn: "Continue Shopping",
    confirm_welcome_title: "Welcome to the Akumu family!",
    confirm_title: "Your order has been received!",
    confirm_order_number: "Order number",
    confirm_subtitle: "We'll reach out soon to confirm delivery",
    confirm_gift_title: "First order gift",
    confirm_gift_desc: "Use code WELCOME20 on your next order and get 20,000 SYP off",
    confirm_track_btn: "Track Order", confirm_home_btn: "Back to Home",
    order_step_placed: "Order received", order_step_preparing: "Preparing",
    order_step_shipping: "On its way", order_step_delivered: "Delivered",
    order_status_cancelled: "Cancelled",
    product_detail_title: "Product Details",
    product_reviews_count: "reviews",
    product_out_of_stock: "This product is out of stock",
    product_low_stock: "Only {n} left!",
    product_size_label: "Size", product_color_label: "Color",
    product_description_label: "Description",
    product_description_text: "{name} is high quality and elegantly designed, suitable for everyday use and occasions. Delivery within 2-4 days to all governorates.",
    product_related_title: "You might also like",
    product_reviews_title: "Ratings & Reviews",
    product_no_reviews: "No reviews yet, be the first to share your opinion",
    product_add_review: "Add your review",
    placeholder_review_comment: "What do you think of the product?",
    product_publish_review: "Post Review",
    product_out_of_stock_btn: "Out of stock",
    product_add_to_cart: "Add to Cart",
    contact_title: "Contact Us",
    contact_whatsapp: "WhatsApp", contact_phone: "Phone Call", contact_email: "Email",
    contact_faq_title: "Frequently Asked Questions",
    edit_profile_title: "Edit Account Info",
    edit_profile_save: "Save Changes",
    notifications_title: "Notifications",
    notifications_empty: "No notifications yet",
    favorites_empty: "You haven't added anything to favorites yet",
    orders_search_placeholder: "Search by order number or product name",
    orders_empty: "You don't have any orders yet",
    order_label: "Order",
    order_copy: "Copy order number", order_copied: "Copied!",
    share_label: "Share",
    order_cancelled_msg: "This order has been cancelled",
    order_current_status: "Current status",
    order_simulate_update: "Simulate status update (demo)",
    order_cancel_btn: "Cancel Order",
    order_details_title: "Order Details",
    order_payment_method: "Payment Method",
    order_coupon_label: "Discount Code",
    notif_status_change: 'Your order #{id} is now "{status}"',
    notif_order_cancelled: "Your order #{id} has been cancelled",
    notif_cart_reminder: "You have {n} items waiting in your cart, complete your order before stock runs out!",
    filter_btn: "Filter",
    filter_title: "Filter Results",
    filter_price_label: "Price",
    filter_price_all: "All",
    filter_price_under75: "Under 75,000",
    filter_price_75_150: "75,000 - 150,000",
    filter_price_150_250: "150,000 - 250,000",
    filter_price_above250: "Above 250,000",
    filter_rating_label: "Rating",
    filter_rating_all: "All",
    filter_rating_4: "4 stars & up",
    filter_rating_45: "4.5 stars & up",
    filter_clear: "Clear Filters",
    filter_apply: "Apply",
    home_recently_viewed_title: "Recently Viewed",
    compare_toggle_add: "Add to Compare",
    compare_toggle_remove: "Remove from Compare",
    compare_max_reached: "You can compare up to 3 products",
    compare_bar_label: "Compare",
    compare_bar_clear: "Clear",
    compare_title: "Compare Products",
    compare_empty: "You haven't added any products to compare yet",
    compare_price_row: "Price",
    compare_rating_row: "Rating",
    compare_stock_row: "Availability",
    compare_sizes_row: "Sizes",
    compare_colors_row: "Colors",
    compare_in_stock: "In Stock",
    dark_mode_label: "Dark Mode",
    size_guide_link: "Size Guide",
    size_guide_title: "Size Guide",
    size_guide_col_size: "Size",
    size_guide_col_chest: "Chest (cm)",
    size_guide_col_waist: "Waist (cm)",
    size_guide_col_length: "Length (cm)",
    notify_stock_btn: "Notify Me When Available",
    notify_stock_subscribed_btn: "We'll notify you",
    notify_stock_toast: "Got it! We'll let you know as soon as it's back in stock",
    address_edit_btn: "Edit",
    address_delete_btn: "Delete",
    address_edit_title: "Edit Address",
    address_deleted_toast: "Address deleted",
    rating_breakdown_title: "Rating Breakdown",
    rating_based_on: "Based on {n} reviews",
    onboard_skip: "Skip",
    onboard_next: "Next",
    onboard_start: "Start Shopping",
    loyalty_points_label: "My Points",
    loyalty_points_balance: "{n} pts",
    loyalty_earn_note: "Earn 1 point for every 1,000 SYP on each order",
    loyalty_redeem_toggle: "Use 100 points = 5,000 SYP off",
    loyalty_redeem_need_more: "You need at least 100 points",
    loyalty_earned_toast: "You earned {n} points from this order!",
    return_request_btn: "Request Return/Exchange",
    return_request_title: "Request a Return or Exchange",
    return_type_label: "Request Type",
    return_type_return: "Return",
    return_type_exchange: "Exchange",
    return_reason_label: "Reason",
    return_reason_placeholder: "Tell us what went wrong...",
    return_submit_btn: "Submit Request",
    return_status_pending: "Return request under review",
    return_already_requested: "Your request has been sent, we'll be in touch soon",
    complete_look_title: "Complete the Look",
    cart_suggestions_title: "Complete Your Order",
    favorites_share_btn: "Share Favorites",
    account_reorder_btn: "Reorder",
    reorder_added_toast: "Available items have been added to your cart",
    reorder_none_available: "Unfortunately all items from this order are out of stock",
    referral_title: "Invite Friends",
    referral_desc: "Share your code with friends — you both get 50 bonus points when they use it!",
    referral_code_label: "Your Code",
    referral_share_btn: "Share Code",
    referral_share_text: "Hey! Try the Akumu shopping app and use my code {code} to get 50 bonus points 🎁",
    delivery_slot_label: "Delivery Time",
    delivery_slot_any: "Any time",
    delivery_slot_morning: "Morning (9am - 1pm)",
    delivery_slot_evening: "Evening (3pm - 7pm)",
    gift_wrap_toggle: "Gift wrap (+5,000 SYP)",
    gift_message_placeholder: "Write a gift message (optional)",
    deals_title: "Deals & Offers",
    deals_coupons_section: "Available Discount Codes",
    deals_products_section: "Discounted Products",
    deals_empty: "No deals right now, check back later",
    search_recent_title: "Recent Searches",
    search_clear_history: "Clear",
    search_trending_title: "Trending Searches",
    my_reviews_title: "My Reviews",
    my_reviews_empty: "You haven't written any reviews yet, try a product and share your thoughts",
    notif_prefs_title: "Notification Preferences",
    notif_pref_order_updates: "Order Updates",
    notif_pref_cart_reminders: "Abandoned Cart Reminders",
    notif_pref_promotions: "Deals & Promotions",
    about_title: "About the App",
    about_version_label: "Version",
    about_description: "Akumu is an online store for women's, men's, and smart wear fashion, delivering anywhere in Syria.",
    about_legal_title: "Terms & Privacy",
    about_terms_title: "Terms of Use",
    about_terms_text: "By using the Akumu app, you agree to the terms of use related to orders, payment, and delivery. Contact us for more details.",
    about_privacy_title: "Privacy Policy",
    about_privacy_text: "We protect your data privacy and only use it to improve your shopping experience and deliver your orders. We never share your information with third parties without your consent.",
    cart_select_all: "Select All",
    cart_deselect_all: "Deselect All",
    cart_delete_selected: "Delete Selected",
    cart_selected_count: "{n} selected",
    product_qa_title: "Questions about this Product",
    product_qa_empty: "No questions yet, ask the first one",
    product_ask_question: "Ask a Question",
    placeholder_question: "What would you like to know about the product?",
    product_qa_submit: "Submit Question",
    product_qa_pending: "Awaiting store reply",
    flash_sale_title: "Limited Time Offer",
    flash_sale_ends_in: "Ends in",
    flash_sale_hours: "h",
    flash_sale_minutes: "m",
    flash_sale_seconds: "s",
    chat_bubble_label: "Live Chat",
    chat_title: "Live Support",
    chat_welcome_message: "Hi there! How can we help you today?",
    chat_input_placeholder: "Type your message...",
    chat_auto_reply: "Thanks for reaching out! Our support team will get back to you shortly 💬",
    chat_send: "Send",
    vendor_panel_label: "Seller Dashboard",
    vendor_dashboard_title: "Seller Dashboard",
    vendor_tab_dashboard: "Overview",
    vendor_tab_products: "Products",
    vendor_tab_orders: "Orders",
    vendor_stat_orders: "Orders",
    vendor_stat_revenue: "Revenue",
    vendor_stat_products: "Products",
    vendor_stat_low_stock: "Low Stock",
    vendor_add_product_btn: "Add Product",
    vendor_edit_product_title: "Edit Product",
    vendor_new_product_title: "New Product",
    vendor_product_name_placeholder: "Product name",
    vendor_product_price_placeholder: "Price (SYP)",
    vendor_product_stock_placeholder: "Stock quantity",
    vendor_product_category_label: "Category",
    vendor_product_sizes_placeholder: "Sizes (comma separated), e.g. S,M,L",
    vendor_product_colors_placeholder: "Colors (comma separated), e.g. Black,White",
    vendor_save_product_btn: "Save Product",
    vendor_delete_product_btn: "Delete",
    vendor_edit_product_btn: "Edit",
    vendor_no_products: "You don't have any products yet",
    vendor_no_orders: "No orders yet",
    vendor_low_stock_badge: "Low stock",
    vendor_out_of_stock_badge: "Out of stock",
    vendor_product_saved_toast: "Product saved",
    vendor_product_deleted_toast: "Product deleted",
    vendor_view_storefront: "View storefront as a customer",
    login_vendor_checkbox: "I'm a seller, I have a store on Akumu",
    login_vendor_pin_label: "Vendor panel access code (4 digits)",
    login_vendor_pin_placeholder: "e.g. 1234",
    validation_vendor_pin: "The code must be 4 digits",
    vendor_pin_gate_title: "Vendor Panel Access",
    vendor_pin_gate_subtitle: "Enter your access code",
    vendor_pin_gate_placeholder: "••••",
    vendor_pin_gate_submit: "Enter",
    vendor_pin_gate_error: "Incorrect code",
  },
  tr: {
    dir: "ltr", font: "Cairo",
    nav_home: "Anasayfa", nav_cart: "Sepetim", nav_account: "Hesabım",
    account_title: "Hesabım",
    account_login_prompt: "Siparişlerini takip etmek için giriş yap",
    account_login_cta: "Giriş Yap",
    account_logout: "Çıkış Yap",
    account_orders: "Siparişlerim", account_favorites: "Favorilerim",
    account_coupons: "Kuponlarım", account_reviews: "Değerlendirmelerim",
    account_all_orders: "Tüm Siparişlerim", account_reorder: "Tekrar Satın Al",
    account_language: "Dil", account_soon: "Yakında",
    login_title: "Giriş Yap", signup_title: "Hesap Oluştur",
    tab_login: "Giriş Yap", tab_signup: "Hesap Oluştur",
    login_subtitle: "Siparişini tamamlamak ve takip etmek için giriş yap",
    signup_subtitle: "Saniyeler içinde yeni hesap oluştur",
    label_name: "Ad Soyad", label_phone: "Telefon Numarası", label_email: "E-posta",
    placeholder_name: "Adınız Soyadınız", placeholder_email: "ornek@email.com",
    placeholder_short_name: "Adın",
    btn_login: "Giriş Yap", btn_signup: "Hesap Oluştur",
    switch_to_signup: "Hesabın yok mu? Kayıt ol", switch_to_login: "Hesabın var mı? Giriş yap",
    validation_name: "Ad en az 2 karakter olmalı",
    validation_email: "Geçerli bir e-posta adresi girin",
    validation_phone: "Telefon numarası 09 ile başlamalı ve 10 haneli olmalı",
    search_placeholder: "Ürün ara...",
    location_label: "Şam, Suriye",
    cat_all: "Tümü", cat_women: "Kadın", cat_men: "Erkek", cat_smartwear: "Akıllı Giyim",
    sort_default: "En Yeni", sort_price_asc: "Fiyat: Düşükten Yükseğe", sort_price_desc: "Fiyat: Yüksekten Düşüğe", sort_rating: "En Çok Puan Alan",
    out_of_stock_badge: "Stokta yok", out_of_stock_line: "Mevcut değil", low_stock: "{n} adet kaldı",
    cart_title: "Alışveriş Sepeti", cart_empty: "Sepetin şu an boş", cart_subtotal: "Ara Toplam", cart_delivery: "Teslimat",
    cart_total: "Toplam", cart_checkout: "Ödemeye Geç", pieces_label: "ürün",
    free_shipping_hint: "Ücretsiz teslimat için {amount} daha ekle",
    free_shipping_unlocked: "Bu siparişte ücretsiz teslimat kazandın",
    free_label: "Ücretsiz",
    checkout_title: "Siparişi Tamamla", checkout_address: "Teslimat Adresi", checkout_add_address: "Adres Ekle",
    checkout_payment: "Ödeme Yöntemleri", checkout_confirm: "Siparişi Onayla", checkout_coupon: "İndirim Kodu",
    checkout_total_amount: "Toplam Tutar",
    address_name_placeholder: "Adres etiketi (Ev, İş...)",
    address_text_placeholder: "Mahalle, sokak, en yakın nokta",
    address_save_btn: "Adresi Kaydet",
    address_empty_hint: "Henüz kayıtlı bir adresin yok, bir tane ekle",
    coupon_placeholder: "İndirim kodunu gir", coupon_apply_btn: "Uygula", coupon_invalid: "Geçersiz indirim kodu",
    pay_cod_name: "Kapıda Ödeme", pay_cod_desc: "Siparişin gelince nakit öde",
    pay_syriatel_name: "Syriatel Cash", pay_sham_name: "Sham Cash", pay_mtn_name: "MTN Cash",
    pay_wallet_desc: "Doğrudan cüzdanından öde",
    pay_card_name: "Banka Kartı", pay_card_desc: "Visa / Mastercard",
    pay_cod_badge: "En çok kullanılan", pay_card_badge: "Yeni",
    no_results: "Eşleşen sonuç yok",
    home_bestsellers_title: "Çok Satanlar",
    home_new_arrivals_title: "Yeni Gelenler",
    continue_shopping_btn: "Alışverişe Devam Et",
    confirm_welcome_title: "Akumu ailesine hoş geldin!",
    confirm_title: "Siparişin alındı!",
    confirm_order_number: "Sipariş numarası",
    confirm_subtitle: "Teslimatı onaylamak için yakında seninle iletişime geçeceğiz",
    confirm_gift_title: "İlk sipariş hediyesi",
    confirm_gift_desc: "Bir sonraki siparişinde WELCOME20 kodunu kullan ve 20.000 SYP indirim kazan",
    confirm_track_btn: "Siparişi Takip Et", confirm_home_btn: "Anasayfaya Dön",
    order_step_placed: "Sipariş alındı", order_step_preparing: "Hazırlanıyor",
    order_step_shipping: "Yolda", order_step_delivered: "Teslim edildi",
    order_status_cancelled: "İptal edildi",
    product_detail_title: "Ürün Detayları",
    product_reviews_count: "değerlendirme",
    product_out_of_stock: "Bu ürün stokta yok",
    product_low_stock: "Sadece {n} adet kaldı!",
    product_size_label: "Beden", product_color_label: "Renk",
    product_description_label: "Açıklama",
    product_description_text: "{name} yüksek kalitede ve şık tasarımlıdır, günlük kullanım ve özel günler için uygundur. Tüm illere 2-4 gün içinde teslimat.",
    product_related_title: "Bunlar da ilgini çekebilir",
    product_reviews_title: "Değerlendirmeler",
    product_no_reviews: "Henüz değerlendirme yok, fikrini paylaşan ilk kişi ol",
    product_add_review: "Değerlendirmeni ekle",
    placeholder_review_comment: "Ürün hakkında ne düşünüyorsun?",
    product_publish_review: "Değerlendirmeyi Yayınla",
    product_out_of_stock_btn: "Stokta yok",
    product_add_to_cart: "Sepete Ekle",
    contact_title: "Bize Ulaşın",
    contact_whatsapp: "WhatsApp", contact_phone: "Telefonla Ara", contact_email: "E-posta",
    contact_faq_title: "Sıkça Sorulan Sorular",
    edit_profile_title: "Hesap Bilgilerini Düzenle",
    edit_profile_save: "Değişiklikleri Kaydet",
    notifications_title: "Bildirimler",
    notifications_empty: "Henüz bildirim yok",
    favorites_empty: "Henüz favorilere bir şey eklemedin",
    orders_search_placeholder: "Sipariş numarası veya ürün adıyla ara",
    orders_empty: "Henüz siparişin yok",
    order_label: "Sipariş",
    order_copy: "Sipariş numarasını kopyala", order_copied: "Kopyalandı!",
    share_label: "Paylaş",
    order_cancelled_msg: "Bu sipariş iptal edildi",
    order_current_status: "Mevcut durum",
    order_simulate_update: "Durum güncellemesini simüle et (demo)",
    order_cancel_btn: "Siparişi İptal Et",
    order_details_title: "Sipariş Detayları",
    order_payment_method: "Ödeme Yöntemi",
    order_coupon_label: "İndirim Kodu",
    notif_status_change: 'Siparişin #{id} artık "{status}"',
    notif_order_cancelled: "Siparişin #{id} iptal edildi",
    notif_cart_reminder: "Sepetinde {n} ürün seni bekliyor, stok bitmeden siparişini tamamla!",
    filter_btn: "Filtrele",
    filter_title: "Sonuçları Filtrele",
    filter_price_label: "Fiyat",
    filter_price_all: "Tümü",
    filter_price_under75: "75.000'in altında",
    filter_price_75_150: "75.000 - 150.000",
    filter_price_150_250: "150.000 - 250.000",
    filter_price_above250: "250.000'in üzerinde",
    filter_rating_label: "Puan",
    filter_rating_all: "Tümü",
    filter_rating_4: "4 yıldız ve üzeri",
    filter_rating_45: "4.5 yıldız ve üzeri",
    filter_clear: "Filtreleri Temizle",
    filter_apply: "Uygula",
    home_recently_viewed_title: "Son Görüntülenenler",
    compare_toggle_add: "Karşılaştırmaya Ekle",
    compare_toggle_remove: "Karşılaştırmadan Çıkar",
    compare_max_reached: "En fazla 3 ürünü karşılaştırabilirsin",
    compare_bar_label: "Karşılaştır",
    compare_bar_clear: "Temizle",
    compare_title: "Ürünleri Karşılaştır",
    compare_empty: "Henüz karşılaştırmaya ürün eklemedin",
    compare_price_row: "Fiyat",
    compare_rating_row: "Puan",
    compare_stock_row: "Stok Durumu",
    compare_sizes_row: "Bedenler",
    compare_colors_row: "Renkler",
    compare_in_stock: "Stokta Var",
    dark_mode_label: "Karanlık Mod",
    size_guide_link: "Beden Rehberi",
    size_guide_title: "Beden Rehberi",
    size_guide_col_size: "Beden",
    size_guide_col_chest: "Göğüs (cm)",
    size_guide_col_waist: "Bel (cm)",
    size_guide_col_length: "Boy (cm)",
    notify_stock_btn: "Stokta Olunca Haber Ver",
    notify_stock_subscribed_btn: "Sana haber vereceğiz",
    notify_stock_toast: "Tamam! Ürün stoğa girer girmez sana haber vereceğiz",
    address_edit_btn: "Düzenle",
    address_delete_btn: "Sil",
    address_edit_title: "Adresi Düzenle",
    address_deleted_toast: "Adres silindi",
    rating_breakdown_title: "Değerlendirme Dağılımı",
    rating_based_on: "{n} değerlendirmeye göre",
    onboard_skip: "Atla",
    onboard_next: "İleri",
    onboard_start: "Alışverişe Başla",
    loyalty_points_label: "Puanlarım",
    loyalty_points_balance: "{n} puan",
    loyalty_earn_note: "Her siparişte her 1.000 SYP için 1 puan kazan",
    loyalty_redeem_toggle: "100 puan = 5.000 SYP indirim kullan",
    loyalty_redeem_need_more: "En az 100 puana ihtiyacın var",
    loyalty_earned_toast: "Bu siparişten {n} puan kazandın!",
    return_request_btn: "İade/Değişim Talebi",
    return_request_title: "İade veya Değişim Talebi",
    return_type_label: "Talep Türü",
    return_type_return: "İade",
    return_type_exchange: "Değişim",
    return_reason_label: "Sebep",
    return_reason_placeholder: "Sorunu bize anlat...",
    return_submit_btn: "Talebi Gönder",
    return_status_pending: "İade talebi inceleniyor",
    return_already_requested: "Talebin gönderildi, yakında seninle iletişime geçeceğiz",
    complete_look_title: "Kombini Tamamla",
    cart_suggestions_title: "Siparişini Tamamla",
    favorites_share_btn: "Favorileri Paylaş",
    account_reorder_btn: "Tekrar Satın Al",
    reorder_added_toast: "Mevcut ürünler sepetine eklendi",
    reorder_none_available: "Maalesef bu siparişteki tüm ürünler stokta yok",
    referral_title: "Arkadaşlarını Davet Et",
    referral_desc: "Kodunu arkadaşlarınla paylaş — kullandıklarında ikiniz de 50 bonus puan kazanır!",
    referral_code_label: "Kodun",
    referral_share_btn: "Kodu Paylaş",
    referral_share_text: "Selam! Akumu alışveriş uygulamasını dene ve {code} kodumu kullanarak 50 bonus puan kazan 🎁",
    delivery_slot_label: "Teslimat Saati",
    delivery_slot_any: "Fark etmez",
    delivery_slot_morning: "Sabah (9:00 - 13:00)",
    delivery_slot_evening: "Akşam (15:00 - 19:00)",
    gift_wrap_toggle: "Hediye paketi (+5.000 SYP)",
    gift_message_placeholder: "Hediye mesajı yaz (isteğe bağlı)",
    deals_title: "Fırsatlar ve İndirimler",
    deals_coupons_section: "Mevcut İndirim Kodları",
    deals_products_section: "İndirimli Ürünler",
    deals_empty: "Şu an fırsat yok, daha sonra tekrar bak",
    search_recent_title: "Son Aramalar",
    search_clear_history: "Temizle",
    search_trending_title: "Popüler Aramalar",
    my_reviews_title: "Değerlendirmelerim",
    my_reviews_empty: "Henüz değerlendirme yazmadın, bir ürünü dene ve fikrini paylaş",
    notif_prefs_title: "Bildirim Tercihleri",
    notif_pref_order_updates: "Sipariş Güncellemeleri",
    notif_pref_cart_reminders: "Sepet Hatırlatmaları",
    notif_pref_promotions: "Fırsatlar ve Kampanyalar",
    about_title: "Uygulama Hakkında",
    about_version_label: "Sürüm",
    about_description: "Akumu, kadın, erkek ve akıllı giyim modası için Suriye'nin her yerine teslimat yapan bir çevrimiçi mağazadır.",
    about_legal_title: "Şartlar ve Gizlilik",
    about_terms_title: "Kullanım Şartları",
    about_terms_text: "Akumu uygulamasını kullanarak sipariş, ödeme ve teslimatla ilgili kullanım şartlarını kabul etmiş olursun. Daha fazla bilgi için bize ulaş.",
    about_privacy_title: "Gizlilik Politikası",
    about_privacy_text: "Verilerinin gizliliğini koruyoruz ve yalnızca alışveriş deneyimini iyileştirmek ve siparişlerini teslim etmek için kullanıyoruz. Bilgilerini rızan olmadan üçüncü taraflarla asla paylaşmıyoruz.",
    cart_select_all: "Tümünü Seç",
    cart_deselect_all: "Seçimi Kaldır",
    cart_delete_selected: "Seçilenleri Sil",
    cart_selected_count: "{n} seçildi",
    product_qa_title: "Ürün Hakkında Sorular",
    product_qa_empty: "Henüz soru yok, ilk soruyu sen sor",
    product_ask_question: "Soru Sor",
    placeholder_question: "Ürün hakkında ne öğrenmek istersin?",
    product_qa_submit: "Soruyu Gönder",
    product_qa_pending: "Mağaza yanıtı bekleniyor",
    flash_sale_title: "Sınırlı Süreli Fırsat",
    flash_sale_ends_in: "Bitmesine kalan süre",
    flash_sale_hours: "sa",
    flash_sale_minutes: "dk",
    flash_sale_seconds: "sn",
    chat_bubble_label: "Canlı Destek",
    chat_title: "Canlı Destek",
    chat_welcome_message: "Merhaba! Bugün sana nasıl yardımcı olabiliriz?",
    chat_input_placeholder: "Mesajını yaz...",
    chat_auto_reply: "Bize ulaştığın için teşekkürler! Destek ekibimiz en kısa sürede sana dönecek 💬",
    chat_send: "Gönder",
    vendor_panel_label: "Satıcı Paneli",
    vendor_dashboard_title: "Satıcı Paneli",
    vendor_tab_dashboard: "Genel Bakış",
    vendor_tab_products: "Ürünler",
    vendor_tab_orders: "Siparişler",
    vendor_stat_orders: "Siparişler",
    vendor_stat_revenue: "Gelir",
    vendor_stat_products: "Ürünler",
    vendor_stat_low_stock: "Az Stok",
    vendor_add_product_btn: "Ürün Ekle",
    vendor_edit_product_title: "Ürünü Düzenle",
    vendor_new_product_title: "Yeni Ürün",
    vendor_product_name_placeholder: "Ürün adı",
    vendor_product_price_placeholder: "Fiyat (SYP)",
    vendor_product_stock_placeholder: "Stok miktarı",
    vendor_product_category_label: "Kategori",
    vendor_product_sizes_placeholder: "Bedenler (virgülle ayrılmış), örn: S,M,L",
    vendor_product_colors_placeholder: "Renkler (virgülle ayrılmış), örn: Siyah,Beyaz",
    vendor_save_product_btn: "Ürünü Kaydet",
    vendor_delete_product_btn: "Sil",
    vendor_edit_product_btn: "Düzenle",
    vendor_no_products: "Henüz ürünün yok",
    vendor_no_orders: "Henüz sipariş yok",
    vendor_low_stock_badge: "Az stok",
    vendor_out_of_stock_badge: "Stokta yok",
    vendor_product_saved_toast: "Ürün kaydedildi",
    vendor_product_deleted_toast: "Ürün silindi",
    vendor_view_storefront: "Mağazayı müşteri olarak görüntüle",
    login_vendor_checkbox: "Ben satıcıyım, Akumu'da mağazam var",
    login_vendor_pin_label: "Satıcı paneli erişim kodu (4 hane)",
    login_vendor_pin_placeholder: "örn: 1234",
    validation_vendor_pin: "Kod 4 haneli olmalı",
    vendor_pin_gate_title: "Satıcı Paneli Girişi",
    vendor_pin_gate_subtitle: "Erişim kodunu gir",
    vendor_pin_gate_placeholder: "••••",
    vendor_pin_gate_submit: "Giriş",
    vendor_pin_gate_error: "Kod yanlış",
  },
};

const FAQS_BY_LANG = {
  ar: [
    { q: "كم مدة التوصيل؟", a: "التوصيل بياخد عادة من 2 إلى 4 أيام حسب المحافظة." },
    { q: "كيف بقدر أرجع منتج؟", a: "تقدري تتواصلي معنا خلال 3 أيام من استلام الطلب لترتيب الإرجاع." },
    { q: "شو طرق الدفع المتوفرة؟", a: "الدفع عند الاستلام، سيريتل كاش، شام كاش، إم تي إن كاش، وبطاقة بنكية." },
    { q: "كيف بقدر أستخدم كود الخصم؟", a: "بصفحة الدفع في حقل مخصص لإدخال كود الخصم قبل تأكيد الطلب." },
  ],
  en: [
    { q: "How long does delivery take?", a: "Delivery usually takes 2 to 4 days depending on the governorate." },
    { q: "How do I return a product?", a: "Contact us within 3 days of receiving your order to arrange a return." },
    { q: "What payment methods are available?", a: "Cash on delivery, Syriatel Cash, Sham Cash, MTN Cash, and bank card." },
    { q: "How do I use a discount code?", a: "On the checkout page there's a dedicated field to enter your discount code before confirming the order." },
  ],
  tr: [
    { q: "Teslimat ne kadar sürer?", a: "Teslimat genellikle ile bağlı olarak 2 ile 4 gün sürer." },
    { q: "Bir ürünü nasıl iade ederim?", a: "İade düzenlemek için siparişini teslim aldıktan sonraki 3 gün içinde bize ulaş." },
    { q: "Hangi ödeme yöntemleri mevcut?", a: "Kapıda ödeme, Syriatel Cash, Sham Cash, MTN Cash ve banka kartı." },
    { q: "İndirim kodunu nasıl kullanırım?", a: "Ödeme sayfasında siparişi onaylamadan önce indirim kodunu girebileceğin özel bir alan var." },
  ],
};

const BANNERS_BY_LANG = {
  ar: [
    { tag: "عرض محدود", title: "تخفيضات نهاية الموسم", subtitle: "خصومات توصل لـ 30% على قطع مختارة" },
    { tag: "جديد", title: "وصل حديثاً", subtitle: "أحدث صيحات الموضة لهالموسم" },
    { tag: "لأي مكان بسوريا", title: "توصيل مجاني", subtitle: "على الطلبات فوق 200,000 ل.س" },
  ],
  en: [
    { tag: "Limited time", title: "End of Season Sale", subtitle: "Up to 30% off selected pieces" },
    { tag: "New", title: "New Arrivals", subtitle: "This season's latest styles" },
    { tag: "Anywhere in Syria", title: "Free Delivery", subtitle: "On orders over 200,000 SYP" },
  ],
  tr: [
    { tag: "Sınırlı süre", title: "Sezon Sonu İndirimi", subtitle: "Seçili ürünlerde %30'a varan indirim" },
    { tag: "Yeni", title: "Yeni Gelenler", subtitle: "Bu sezonun en yeni parçaları" },
    { tag: "Suriye'nin her yerine", title: "Ücretsiz Teslimat", subtitle: "200.000 SYP üzeri siparişlerde" },
  ],
};

const ONBOARDING_ICONS = [Tag, Truck, Heart];

const ONBOARDING_BY_LANG = {
  ar: [
    { title: "تشكيلة متنوعة", subtitle: "أزياء نسائية ورجالية وملابس ذكية بمكان واحد" },
    { title: "توصيل سريع لكل سوريا", subtitle: "تتبعي طلبك خطوة بخطوة لحد ما توصلك" },
    { title: "احفظي المفضلة وقارني", subtitle: "ضيفي المنتجات المفضلة وقارني بينها قبل ما تقرري" },
  ],
  en: [
    { title: "A Curated Collection", subtitle: "Women's, men's, and smart wear all in one place" },
    { title: "Fast Delivery Across Syria", subtitle: "Track your order step by step until it arrives" },
    { title: "Save & Compare", subtitle: "Add favorites and compare products before you decide" },
  ],
  tr: [
    { title: "Zengin Bir Koleksiyon", subtitle: "Kadın, erkek ve akıllı giyim tek bir yerde" },
    { title: "Suriye'nin Her Yerine Hızlı Teslimat", subtitle: "Siparişini adım adım takip et" },
    { title: "Kaydet ve Karşılaştır", subtitle: "Favorilere ekle, karar vermeden önce karşılaştır" },
  ],
};

const TRENDING_SEARCHES_BY_LANG = {
  ar: ["فستان", "جاكيت", "ساعة ذكية", "بدلة رجالي", "قبعة"],
  en: ["Dress", "Jacket", "Smart watch", "Men's suit", "Cap"],
  tr: ["Elbise", "Ceket", "Akıllı saat", "Erkek takım", "Şapka"],
};


function LangSwitch({ lang, setLang }) {
  const opts = [
    { id: "ar", label: "عربي" },
    { id: "en", label: "EN" },
    { id: "tr", label: "TR" },
  ];
  return (
    <div style={{ display: "flex", gap: 6 }}>
      {opts.map((o) => {
        const active = lang === o.id;
        return (
          <button
            key={o.id}
            onClick={() => setLang(o.id)}
            style={{
              padding: "6px 12px",
              borderRadius: 20,
              border: `1px solid ${active ? COLORS.green : COLORS.line}`,
              background: active ? COLORS.green : COLORS.surface,
              color: active ? "#fff" : COLORS.ink,
              fontFamily: "Cairo",
              fontWeight: 600,
              fontSize: 12,
              cursor: "pointer",
            }}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

const ORDER_STEP_KEYS = ["placed", "preparing", "shipping", "delivered"];
const ORDER_STEP_ICONS = { placed: Package, preparing: Clock, shipping: Truck, delivered: CheckCircle2 };

function StatusPill({ stepIndex, cancelled, t }) {
  if (cancelled) {
    return (
      <span
        style={{
          background: COLORS.dangerSoft,
          color: COLORS.danger,
          fontSize: 11,
          fontWeight: 700,
          padding: "4px 10px",
          borderRadius: 20,
          whiteSpace: "nowrap",
        }}
      >
        {t("order_status_cancelled")}
      </span>
    );
  }
  const stepKey = ORDER_STEP_KEYS[stepIndex];
  const done = stepIndex === ORDER_STEP_KEYS.length - 1;
  return (
    <span
      style={{
        background: done ? COLORS.greenSoft : COLORS.goldSoft,
        color: done ? COLORS.green : COLORS.goldText,
        fontSize: 11,
        fontWeight: 700,
        padding: "4px 10px",
        borderRadius: 20,
        whiteSpace: "nowrap",
      }}
    >
      {t(`order_step_${stepKey}`)}
    </span>
  );
}

/* ---------------------------------------------------
   small ui bits
--------------------------------------------------- */
function Badge({ children, tone = "gold" }) {
  const bg = tone === "gold" ? COLORS.goldSoft : COLORS.greenSoft;
  const fg = tone === "gold" ? COLORS.goldText : COLORS.green;
  return (
    <span
      style={{
        background: bg,
        color: fg,
        fontSize: 11,
        fontWeight: 700,
        padding: "3px 9px",
        borderRadius: 20,
        whiteSpace: "nowrap",
      }}
    >
      {children}
    </span>
  );
}

function TopBar({ title, onBack, action }) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "18px 18px 14px",
        background: COLORS.bg,
        position: "sticky",
        top: 0,
        zIndex: 5,
      }}
    >
      <div style={{ width: 34 }}>
        {onBack && (
          <button
            onClick={onBack}
            style={{
              width: 34,
              height: 34,
              borderRadius: "50%",
              border: `1px solid ${COLORS.line}`,
              background: COLORS.surface,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
            }}
          >
            <ChevronLeft size={18} color={COLORS.ink} style={{ transform: "rotate(180deg)" }} />
          </button>
        )}
      </div>
      <h1 style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 20, color: COLORS.ink, margin: 0 }}>
        {title}
      </h1>
      <div style={{ width: 34, display: "flex", justifyContent: "flex-end" }}>{action}</div>
    </div>
  );
}

function ProductImage({ src, alt, style }) {
  const [loaded, setLoaded] = useState(false);
  return (
    <div style={{ position: "relative", overflow: "hidden", background: COLORS.line, ...style }}>
      {!loaded && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            backgroundImage: `linear-gradient(90deg, ${COLORS.line} 25%, ${COLORS.shimmer} 37%, ${COLORS.line} 63%)`,
            backgroundSize: "400% 100%",
            animation: "ak-shimmer 1.4s ease infinite",
          }}
        />
      )}
      <img
        src={src}
        alt={alt}
        onLoad={() => setLoaded(true)}
        onError={() => setLoaded(true)}
        style={{
          width: "100%",
          height: "100%",
          objectFit: "cover",
          display: "block",
          position: "relative",
          opacity: loaded ? 1 : 0,
          transition: "opacity 0.35s ease",
        }}
      />
    </div>
  );
}

function MiniProductCard({ product, onOpen }) {
  return (
    <button
      onClick={() => onOpen(product.id)}
      style={{
        flexShrink: 0,
        width: 118,
        textAlign: "right",
        background: COLORS.surface,
        border: `1px solid ${COLORS.line}`,
        borderRadius: 14,
        overflow: "hidden",
        cursor: "pointer",
        padding: 0,
      }}
    >
      <ProductImage src={product.img || `https://picsum.photos/seed/${product.seed}/200/200`} alt={product.name} style={{ width: "100%", height: 90 }} />
      <div style={{ padding: 8 }}>
        <div style={{ fontFamily: "Cairo", fontWeight: 600, fontSize: 11, color: COLORS.ink, minHeight: 28 }}>
          {product.name}
        </div>
        <div style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 12, color: COLORS.greenDark, marginTop: 4 }}>
          {money(product.price)}
        </div>
      </div>
    </button>
  );
}

function PromoBanner({ lang }) {
  const slides = BANNERS_BY_LANG[lang] || BANNERS_BY_LANG.ar;
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => setIndex((i) => (i + 1) % slides.length), 4500);
    return () => clearInterval(timer);
  }, [slides.length]);

  const slide = slides[index];

  return (
    <div
      style={{
        margin: "4px 18px 16px",
        borderRadius: 18,
        padding: "18px 20px",
        background: `linear-gradient(120deg, ${COLORS.green}, ${COLORS.greenDark})`,
        position: "relative",
        overflow: "hidden",
        minHeight: 84,
      }}
    >
      <div
        style={{
          position: "absolute",
          top: -30,
          insetInlineEnd: -30,
          width: 120,
          height: 120,
          borderRadius: "50%",
          background: "rgba(199,154,43,0.18)",
        }}
      />
      <span
        style={{
          display: "inline-block",
          background: "rgba(199,154,43,0.25)",
          color: COLORS.goldSoft,
          fontFamily: "Cairo",
          fontWeight: 700,
          fontSize: 10.5,
          padding: "3px 10px",
          borderRadius: 20,
          marginBottom: 8,
        }}
      >
        {slide.tag}
      </span>
      <div style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 17, color: "#fff", position: "relative" }}>
        {slide.title}
      </div>
      <div style={{ fontFamily: "Cairo", fontSize: 12, color: "rgba(255,255,255,0.8)", marginTop: 4, position: "relative" }}>
        {slide.subtitle}
      </div>
      <div style={{ display: "flex", gap: 5, marginTop: 12, position: "relative" }}>
        {slides.map((_, i) => (
          <span
            key={i}
            style={{
              width: i === index ? 16 : 6,
              height: 6,
              borderRadius: 4,
              background: i === index ? COLORS.gold : "rgba(255,255,255,0.35)",
              transition: "width 0.25s ease",
            }}
          />
        ))}
      </div>
    </div>
  );
}


const PRICE_RANGES = [
  { id: "all", min: 0, max: Infinity, key: "filter_price_all" },
  { id: "under75", min: 0, max: 75000, key: "filter_price_under75" },
  { id: "75_150", min: 75000, max: 150000, key: "filter_price_75_150" },
  { id: "150_250", min: 150000, max: 250000, key: "filter_price_150_250" },
  { id: "above250", min: 250000, max: Infinity, key: "filter_price_above250" },
];

const RATING_TIERS = [
  { id: "all", min: 0, key: "filter_rating_all" },
  { id: "4", min: 4, key: "filter_rating_4" },
  { id: "45", min: 4.5, key: "filter_rating_45" },
];

function FilterModal({ open, onClose, priceFilter, setPriceFilter, ratingFilter, setRatingFilter, t }) {
  if (!open) return null;
  const activeCount = (priceFilter !== "all" ? 1 : 0) + (ratingFilter !== "all" ? 1 : 0);
  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.4)",
        zIndex: 40,
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "center",
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "100%",
          maxWidth: 390,
          background: COLORS.bg,
          borderTopLeftRadius: 22,
          borderTopRightRadius: 22,
          padding: "18px 18px 26px",
          animation: "ak-fadein 0.25s ease",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <span style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 16, color: COLORS.ink }}>{t("filter_title")}</span>
          <button onClick={onClose} style={{ border: "none", background: "none", cursor: "pointer", display: "flex" }}>
            <X size={20} color={COLORS.inkMuted} />
          </button>
        </div>

        <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.ink, marginBottom: 8 }}>{t("filter_price_label")}</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 18 }}>
          {PRICE_RANGES.map((r) => {
            const active = priceFilter === r.id;
            return (
              <button
                key={r.id}
                onClick={() => setPriceFilter(r.id)}
                style={{
                  padding: "8px 12px",
                  borderRadius: 20,
                  border: `1.5px solid ${active ? COLORS.green : COLORS.line}`,
                  background: active ? COLORS.green : COLORS.surface,
                  color: active ? "#fff" : COLORS.ink,
                  fontFamily: "Cairo",
                  fontWeight: 600,
                  fontSize: 12,
                  cursor: "pointer",
                }}
              >
                {t(r.key)}
              </button>
            );
          })}
        </div>

        <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.ink, marginBottom: 8 }}>{t("filter_rating_label")}</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 22 }}>
          {RATING_TIERS.map((r) => {
            const active = ratingFilter === r.id;
            return (
              <button
                key={r.id}
                onClick={() => setRatingFilter(r.id)}
                style={{
                  padding: "8px 12px",
                  borderRadius: 20,
                  border: `1.5px solid ${active ? COLORS.gold : COLORS.line}`,
                  background: active ? COLORS.goldSoft : COLORS.surface,
                  color: active ? COLORS.goldText : COLORS.ink,
                  fontFamily: "Cairo",
                  fontWeight: 600,
                  fontSize: 12,
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: 4,
                }}
              >
                {r.id !== "all" && <Star size={11} color={COLORS.gold} fill={COLORS.gold} />}
                {t(r.key)}
              </button>
            );
          })}
        </div>

        <div style={{ display: "flex", gap: 10 }}>
          <button
            onClick={() => {
              setPriceFilter("all");
              setRatingFilter("all");
            }}
            disabled={activeCount === 0}
            style={{
              flex: 1,
              background: "none",
              border: `1px solid ${COLORS.line}`,
              borderRadius: 12,
              padding: "12px 0",
              fontFamily: "Cairo",
              fontWeight: 700,
              fontSize: 13,
              color: activeCount === 0 ? COLORS.inkMuted : COLORS.ink,
              cursor: activeCount === 0 ? "default" : "pointer",
              opacity: activeCount === 0 ? 0.5 : 1,
            }}
          >
            {t("filter_clear")}
          </button>
          <button
            onClick={onClose}
            style={{
              flex: 1,
              background: COLORS.green,
              color: "#fff",
              border: "none",
              borderRadius: 12,
              padding: "12px 0",
              fontFamily: "Cairo",
              fontWeight: 700,
              fontSize: 13,
              cursor: "pointer",
            }}
          >
            {t("filter_apply")}
          </button>
        </div>
      </div>
    </div>
  );
}

const SIZE_CHART = [
  { size: "S", chest: 88, waist: 72, length: 66 },
  { size: "S/M", chest: 92, waist: 76, length: 67 },
  { size: "M", chest: 96, waist: 80, length: 68 },
  { size: "L", chest: 104, waist: 88, length: 70 },
  { size: "L/XL", chest: 108, waist: 92, length: 71 },
  { size: "XL", chest: 112, waist: 96, length: 72 },
  { size: "XXL", chest: 120, waist: 104, length: 74 },
];

function SizeGuideModal({ open, onClose, sizes, t }) {
  if (!open) return null;
  const rows = SIZE_CHART.filter((r) => sizes.includes(r.size));
  const visibleRows = rows.length > 0 ? rows : SIZE_CHART;
  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.4)",
        zIndex: 40,
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "center",
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "100%",
          maxWidth: 390,
          background: COLORS.bg,
          borderTopLeftRadius: 22,
          borderTopRightRadius: 22,
          padding: "18px 18px 30px",
          animation: "ak-fadein 0.25s ease",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <span style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 16, color: COLORS.ink }}>{t("size_guide_title")}</span>
          <button onClick={onClose} style={{ border: "none", background: "none", cursor: "pointer", display: "flex" }}>
            <X size={20} color={COLORS.inkMuted} />
          </button>
        </div>
        <div style={{ border: `1px solid ${COLORS.line}`, borderRadius: 14, overflow: "hidden" }}>
          <div style={{ display: "flex", background: COLORS.greenSoft, padding: "10px 12px" }}>
            <span style={{ flex: 1, fontFamily: "Cairo", fontWeight: 700, fontSize: 11.5, color: COLORS.green, textAlign: "center" }}>{t("size_guide_col_size")}</span>
            <span style={{ flex: 1, fontFamily: "Cairo", fontWeight: 700, fontSize: 11.5, color: COLORS.green, textAlign: "center" }}>{t("size_guide_col_chest")}</span>
            <span style={{ flex: 1, fontFamily: "Cairo", fontWeight: 700, fontSize: 11.5, color: COLORS.green, textAlign: "center" }}>{t("size_guide_col_waist")}</span>
            <span style={{ flex: 1, fontFamily: "Cairo", fontWeight: 700, fontSize: 11.5, color: COLORS.green, textAlign: "center" }}>{t("size_guide_col_length")}</span>
          </div>
          {visibleRows.map((r, i) => (
            <div
              key={r.size}
              style={{
                display: "flex",
                padding: "10px 12px",
                background: COLORS.surface,
                borderTop: i > 0 ? `1px solid ${COLORS.line}` : "none",
              }}
            >
              <span style={{ flex: 1, fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.ink, textAlign: "center" }}>{r.size}</span>
              <span style={{ flex: 1, fontFamily: "Cairo", fontSize: 12, color: COLORS.inkMuted, textAlign: "center" }}>{r.chest}</span>
              <span style={{ flex: 1, fontFamily: "Cairo", fontSize: 12, color: COLORS.inkMuted, textAlign: "center" }}>{r.waist}</span>
              <span style={{ flex: 1, fontFamily: "Cairo", fontSize: 12, color: COLORS.inkMuted, textAlign: "center" }}>{r.length}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function CompareBar({ compareIds, onOpenCompare, onClear, t }) {
  if (compareIds.length === 0) return null;
  const items = compareIds.map((id) => PRODUCTS.find((p) => p.id === id)).filter(Boolean);
  return (
    <div
      style={{
        position: "fixed",
        bottom: 78,
        left: "50%",
        transform: "translateX(-50%)",
        width: "calc(100% - 36px)",
        maxWidth: 354,
        background: COLORS.greenDark,
        borderRadius: 16,
        padding: "10px 12px",
        display: "flex",
        alignItems: "center",
        gap: 10,
        zIndex: 30,
        boxShadow: "0 8px 24px rgba(0,0,0,0.25)",
      }}
    >
      <div style={{ display: "flex", gap: -6 }}>
        {items.map((p) => (
          <div
            key={p.id}
            style={{
              width: 30,
              height: 30,
              borderRadius: 8,
              overflow: "hidden",
              border: "2px solid rgba(255,255,255,0.5)",
              marginInlineStart: -8,
              flexShrink: 0,
            }}
          >
            <img src={p.img} alt={p.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          </div>
        ))}
      </div>
      <button
        onClick={onOpenCompare}
        style={{
          flex: 1,
          background: COLORS.gold,
          color: COLORS.greenDark,
          border: "none",
          borderRadius: 10,
          padding: "9px 0",
          fontFamily: "Cairo",
          fontWeight: 700,
          fontSize: 12.5,
          cursor: "pointer",
        }}
      >
        {t("compare_bar_label")} ({compareIds.length})
      </button>
      <button onClick={onClear} style={{ border: "none", background: "none", cursor: "pointer", display: "flex", flexShrink: 0 }}>
        <X size={16} color="#fff" />
      </button>
    </div>
  );
}

function ChatWidget({ open, onToggle, messages, onSend, t }) {
  const [draft, setDraft] = useState("");

  const send = () => {
    if (!draft.trim()) return;
    onSend(draft.trim());
    setDraft("");
  };

  return (
    <>
      <button
        onClick={onToggle}
        title={t("chat_bubble_label")}
        style={{
          position: "fixed",
          bottom: 88,
          insetInlineEnd: 18,
          width: 50,
          height: 50,
          borderRadius: "50%",
          border: "none",
          background: COLORS.green,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: "pointer",
          boxShadow: "0 6px 18px rgba(0,0,0,0.25)",
          zIndex: 35,
        }}
      >
        {open ? <X size={20} color="#fff" /> : <MessageSquare size={20} color="#fff" />}
      </button>

      {open && (
        <div
          onClick={onToggle}
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.4)",
            zIndex: 45,
            display: "flex",
            alignItems: "flex-end",
            justifyContent: "center",
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: "100%",
              maxWidth: 390,
              height: "70vh",
              background: COLORS.bg,
              borderTopLeftRadius: 22,
              borderTopRightRadius: 22,
              display: "flex",
              flexDirection: "column",
              animation: "ak-fadein 0.25s ease",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "16px 18px", borderBottom: `1px solid ${COLORS.line}` }}>
              <span style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 15, color: COLORS.ink }}>{t("chat_title")}</span>
              <button onClick={onToggle} style={{ border: "none", background: "none", cursor: "pointer", display: "flex" }}>
                <X size={20} color={COLORS.inkMuted} />
              </button>
            </div>
            <div style={{ flex: 1, overflowY: "auto", padding: "14px 18px", display: "flex", flexDirection: "column", gap: 10 }}>
              {messages.map((m, i) => (
                <div
                  key={i}
                  style={{
                    alignSelf: m.from === "user" ? "flex-end" : "flex-start",
                    maxWidth: "78%",
                    background: m.from === "user" ? COLORS.green : COLORS.surface,
                    color: m.from === "user" ? "#fff" : COLORS.ink,
                    border: m.from === "user" ? "none" : `1px solid ${COLORS.line}`,
                    borderRadius: 14,
                    padding: "9px 13px",
                    fontFamily: "Cairo",
                    fontSize: 12.5,
                    lineHeight: 1.6,
                  }}
                >
                  {m.text}
                </div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 8, padding: "12px 18px", borderTop: `1px solid ${COLORS.line}` }}>
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && send()}
                placeholder={t("chat_input_placeholder")}
                style={{ flex: 1, border: `1px solid ${COLORS.line}`, background: COLORS.surface, borderRadius: 12, padding: "10px 14px", fontFamily: "Cairo", fontSize: 13, color: COLORS.ink, outline: "none" }}
              />
              <button
                onClick={send}
                style={{ background: COLORS.green, color: "#fff", border: "none", borderRadius: 12, padding: "0 16px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}
              >
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function OnboardingScreen({ lang, onFinish, t }) {
  const [index, setIndex] = useState(0);
  const slides = ONBOARDING_BY_LANG[lang] || ONBOARDING_BY_LANG.ar;
  const Icon = ONBOARDING_ICONS[index];
  const isLast = index === slides.length - 1;

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        padding: "40px 28px 32px",
        background: `linear-gradient(160deg, ${COLORS.greenDark}, ${COLORS.green})`,
      }}
    >
      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        {!isLast && (
          <button
            onClick={onFinish}
            style={{ border: "none", background: "none", cursor: "pointer", fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: "rgba(255,255,255,0.75)" }}
          >
            {t("onboard_skip")}
          </button>
        )}
      </div>

      <div style={{ textAlign: "center", animation: "ak-fadein 0.35s ease" }} key={index}>
        <div
          style={{
            width: 92,
            height: 92,
            borderRadius: "50%",
            background: "rgba(255,255,255,0.12)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            margin: "0 auto 26px",
          }}
        >
          <Icon size={40} color={COLORS.gold} />
        </div>
        <h2 style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 21, color: "#fff", marginBottom: 10 }}>
          {slides[index].title}
        </h2>
        <p style={{ fontFamily: "Cairo", fontSize: 13.5, color: "rgba(255,255,255,0.8)", lineHeight: 1.8, maxWidth: 280, margin: "0 auto" }}>
          {slides[index].subtitle}
        </p>
      </div>

      <div>
        <div style={{ display: "flex", justifyContent: "center", gap: 6, marginBottom: 24 }}>
          {slides.map((_, i) => (
            <span
              key={i}
              style={{
                width: i === index ? 22 : 7,
                height: 7,
                borderRadius: 4,
                background: i === index ? COLORS.gold : "rgba(255,255,255,0.3)",
                transition: "width 0.25s ease",
              }}
            />
          ))}
        </div>
        <button
          onClick={() => (isLast ? onFinish() : setIndex((i) => i + 1))}
          style={{
            width: "100%",
            background: COLORS.gold,
            color: COLORS.greenDark,
            border: "none",
            borderRadius: 14,
            padding: "15px 0",
            fontFamily: "Cairo",
            fontWeight: 700,
            fontSize: 15,
            cursor: "pointer",
          }}
        >
          {isLast ? t("onboard_start") : t("onboard_next")}
        </button>
      </div>
    </div>
  );
}

function HomeScreen({
  cart,
  addToCart,
  activeCat,
  setActiveCat,
  search,
  setSearch,
  favorites,
  toggleFavorite,
  onOpenProduct,
  lang,
  recentlyViewed,
  searchHistory,
  onCommitSearch,
  onClearSearchHistory,
  t,
}) {
  const [sortBy, setSortBy] = useState("default");
  const [priceFilter, setPriceFilter] = useState("all");
  const [ratingFilter, setRatingFilter] = useState("all");
  const [filterOpen, setFilterOpen] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);
  const activeFilterCount = (priceFilter !== "all" ? 1 : 0) + (ratingFilter !== "all" ? 1 : 0);
  const trendingSearches = TRENDING_SEARCHES_BY_LANG[lang] || TRENDING_SEARCHES_BY_LANG.ar;

  const SORT_OPTIONS = [
    { id: "default", label: t("sort_default") },
    { id: "price_asc", label: t("sort_price_asc") },
    { id: "price_desc", label: t("sort_price_desc") },
    { id: "rating", label: t("sort_rating") },
  ];

  const bestSellers = useMemo(() => [...PRODUCTS].sort((a, b) => b.rating - a.rating).slice(0, 6), []);
  const newArrivals = useMemo(() => PRODUCTS.filter((p) => p.badge === "جديد"), []);
  const recentlyViewedProducts = useMemo(
    () => recentlyViewed.map((id) => PRODUCTS.find((p) => p.id === id)).filter(Boolean),
    [recentlyViewed]
  );

  const filtered = useMemo(() => {
    const priceRange = PRICE_RANGES.find((r) => r.id === priceFilter) || PRICE_RANGES[0];
    const ratingTier = RATING_TIERS.find((r) => r.id === ratingFilter) || RATING_TIERS[0];
    let list = PRODUCTS.filter(
      (p) =>
        (activeCat === "all" || p.cat === activeCat) &&
        p.name.includes(search.trim()) &&
        p.price >= priceRange.min &&
        p.price < priceRange.max &&
        p.rating >= ratingTier.min
    );
    if (sortBy === "price_asc") list = [...list].sort((a, b) => a.price - b.price);
    else if (sortBy === "price_desc") list = [...list].sort((a, b) => b.price - a.price);
    else if (sortBy === "rating") list = [...list].sort((a, b) => b.rating - a.rating);
    return list;
  }, [activeCat, search, sortBy, priceFilter, ratingFilter]);

  return (
    <div>
      <div style={{ padding: "20px 18px 6px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <img
              src={LOGO_IMG}
              alt="Akumu"
              style={{ width: 30, height: 30, borderRadius: 8, objectFit: "cover" }}
            />
            <span style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 20, color: COLORS.greenDark, letterSpacing: 0.5 }}>
              Akumu
            </span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
            <MapPin size={14} color={COLORS.green} />
            <span style={{ fontFamily: "Cairo", fontWeight: 600, color: COLORS.ink, fontSize: 12 }}>
              {t("location_label")}
            </span>
          </div>
        </div>

        <div style={{ display: "flex", gap: 8 }}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              background: COLORS.surface,
              border: `1px solid ${COLORS.line}`,
              borderRadius: 14,
              padding: "10px 14px",
              flex: 1,
            }}
          >
            <Search size={18} color={COLORS.inkMuted} />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onFocus={() => setSearchFocused(true)}
              onBlur={() => setTimeout(() => setSearchFocused(false), 150)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && search.trim()) {
                  onCommitSearch(search);
                  setSearchFocused(false);
                  e.target.blur();
                }
              }}
              placeholder={t("search_placeholder")}
              style={{
                border: "none",
                outline: "none",
                background: "transparent",
                fontFamily: "Cairo",
                fontSize: 14,
                color: COLORS.ink,
                width: "100%",
              }}
            />
          </div>
          <button
            onClick={() => setFilterOpen(true)}
            style={{
              position: "relative",
              width: 44,
              flexShrink: 0,
              background: activeFilterCount > 0 ? COLORS.green : COLORS.surface,
              border: `1px solid ${activeFilterCount > 0 ? COLORS.green : COLORS.line}`,
              borderRadius: 14,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
            }}
          >
            <SlidersHorizontal size={18} color={activeFilterCount > 0 ? "#fff" : COLORS.ink} />
            {activeFilterCount > 0 && (
              <span
                style={{
                  position: "absolute",
                  top: -4,
                  insetInlineEnd: -4,
                  background: COLORS.gold,
                  color: COLORS.greenDark,
                  fontSize: 9,
                  fontWeight: 800,
                  borderRadius: 8,
                  minWidth: 15,
                  height: 15,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                {activeFilterCount}
              </span>
            )}
          </button>
        </div>

        {searchFocused && !search.trim() && (searchHistory.length > 0 || trendingSearches.length > 0) && (
          <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 12, marginTop: 8 }}>
            {searchHistory.length > 0 && (
              <>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                  <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 11.5, color: COLORS.inkMuted }}>{t("search_recent_title")}</span>
                  <button
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={onClearSearchHistory}
                    style={{ border: "none", background: "none", cursor: "pointer", fontFamily: "Cairo", fontSize: 11, fontWeight: 700, color: COLORS.danger }}
                  >
                    {t("search_clear_history")}
                  </button>
                </div>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 12 }}>
                  {searchHistory.map((term) => (
                    <button
                      key={term}
                      onMouseDown={(e) => e.preventDefault()}
                      onClick={() => {
                        setSearch(term);
                        setSearchFocused(false);
                      }}
                      style={{ display: "flex", alignItems: "center", gap: 5, padding: "6px 12px", borderRadius: 20, border: `1px solid ${COLORS.line}`, background: COLORS.bg, fontFamily: "Cairo", fontSize: 11.5, color: COLORS.ink, cursor: "pointer" }}
                    >
                      <Clock size={11} color={COLORS.inkMuted} />
                      {term}
                    </button>
                  ))}
                </div>
              </>
            )}
            <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 11.5, color: COLORS.inkMuted, marginBottom: 8 }}>
              {t("search_trending_title")}
            </div>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              {trendingSearches.map((term) => (
                <button
                  key={term}
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => {
                    setSearch(term);
                    onCommitSearch(term);
                    setSearchFocused(false);
                  }}
                  style={{ display: "flex", alignItems: "center", gap: 5, padding: "6px 12px", borderRadius: 20, border: `1px solid ${COLORS.gold}`, background: COLORS.goldSoft, fontFamily: "Cairo", fontSize: 11.5, color: COLORS.goldText, cursor: "pointer" }}
                >
                  <Search size={11} color={COLORS.goldText} />
                  {term}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      <FilterModal
        open={filterOpen}
        onClose={() => setFilterOpen(false)}
        priceFilter={priceFilter}
        setPriceFilter={setPriceFilter}
        ratingFilter={ratingFilter}
        setRatingFilter={setRatingFilter}
        t={t}
      />

      <PromoBanner lang={lang} />

      <div style={{ display: "flex", gap: 8, padding: "0 18px 16px", overflowX: "auto" }}>
        {CATEGORIES.map((c) => {
          const isActive = c.id === activeCat;
          return (
            <button
              key={c.id}
              onClick={() => setActiveCat(c.id)}
              style={{
                flexShrink: 0,
                padding: "8px 16px",
                borderRadius: 20,
                border: `1px solid ${isActive ? COLORS.green : COLORS.line}`,
                background: isActive ? COLORS.green : COLORS.surface,
                color: isActive ? "#fff" : COLORS.ink,
                fontFamily: "Cairo",
                fontWeight: 600,
                fontSize: 13,
                cursor: "pointer",
              }}
            >
              {t(`cat_${c.id}`)}
            </button>
          );
        })}
      </div>

      {activeCat === "all" && !search.trim() && recentlyViewedProducts.length > 0 && (
        <>
          <div style={{ padding: "0 18px", marginBottom: 6 }}>
            <div style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 15, color: COLORS.ink, marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
              <Eye size={15} color={COLORS.inkMuted} />
              {t("home_recently_viewed_title")}
            </div>
          </div>
          <div style={{ display: "flex", gap: 10, padding: "0 18px 20px", overflowX: "auto" }}>
            {recentlyViewedProducts.map((p) => (
              <MiniProductCard key={p.id} product={p} onOpen={onOpenProduct} />
            ))}
          </div>
        </>
      )}

      {activeCat === "all" && !search.trim() && (
        <>
          <div style={{ padding: "0 18px", marginBottom: 6 }}>
            <div style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 15, color: COLORS.ink, marginBottom: 10 }}>
              {t("home_bestsellers_title")}
            </div>
          </div>
          <div style={{ display: "flex", gap: 10, padding: "0 18px 20px", overflowX: "auto" }}>
            {bestSellers.map((p) => (
              <MiniProductCard key={p.id} product={p} onOpen={onOpenProduct} />
            ))}
          </div>

          {newArrivals.length > 0 && (
            <>
              <div style={{ padding: "0 18px", marginBottom: 6 }}>
                <div style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 15, color: COLORS.ink, marginBottom: 10 }}>
                  {t("home_new_arrivals_title")}
                </div>
              </div>
              <div style={{ display: "flex", gap: 10, padding: "0 18px 20px", overflowX: "auto" }}>
                {newArrivals.map((p) => (
                  <MiniProductCard key={p.id} product={p} onOpen={onOpenProduct} />
                ))}
              </div>
            </>
          )}
        </>
      )}

      <div style={{ display: "flex", gap: 8, padding: "0 18px 12px", overflowX: "auto" }}>
        {SORT_OPTIONS.map((s) => {
          const isActive = s.id === sortBy;
          return (
            <button
              key={s.id}
              onClick={() => setSortBy(s.id)}
              style={{
                flexShrink: 0,
                padding: "6px 13px",
                borderRadius: 16,
                border: `1px solid ${isActive ? COLORS.gold : COLORS.line}`,
                background: isActive ? COLORS.goldSoft : "transparent",
                color: isActive ? COLORS.goldText : COLORS.inkMuted,
                fontFamily: "Cairo",
                fontWeight: 600,
                fontSize: 11.5,
                cursor: "pointer",
              }}
            >
              {s.label}
            </button>
          );
        })}
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 12,
          padding: "4px 18px 100px",
        }}
      >
        {filtered.map((p) => {
          const defKey = variantKey(p.id, p.sizes[0], p.colors[0]);
          const qty = cart[defKey]?.qty || 0;
          const outOfStock = p.stock <= 0;
          const atMax = qty >= p.stock;
          return (
            <div
              key={p.id}
              style={{
                background: COLORS.surface,
                borderRadius: 16,
                overflow: "hidden",
                border: `1px solid ${COLORS.line}`,
              }}
            >
              <div style={{ position: "relative" }} onClick={() => onOpenProduct(p.id)}>
                <ProductImage
                  src={p.img || `https://picsum.photos/seed/${p.seed}/300/300`}
                  alt={p.name}
                  style={{ width: "100%", height: 120 }}
                />
                {p.badge && (
                  <div style={{ position: "absolute", top: 8, right: 8 }}>
                    <Badge>{p.badge}</Badge>
                  </div>
                )}
                {outOfStock && (
                  <div style={{ position: "absolute", inset: 0, background: "rgba(35,42,32,0.55)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <span style={{ background: "#fff", color: COLORS.danger, fontFamily: "Cairo", fontWeight: 700, fontSize: 11, padding: "4px 10px", borderRadius: 20 }}>
                      {t("out_of_stock_badge")}
                    </span>
                  </div>
                )}
                <button
                  onClick={(e) => { e.stopPropagation(); toggleFavorite(p.id); }}
                  style={{
                    position: "absolute",
                    top: 8,
                    left: 8,
                    width: 28,
                    height: 28,
                    borderRadius: "50%",
                    border: "none",
                    background: "rgba(255,255,255,0.9)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                  }}
                >
                  <Heart
                    size={15}
                    color={favorites[p.id] ? COLORS.danger : COLORS.inkMuted}
                    fill={favorites[p.id] ? COLORS.danger : "none"}
                  />
                </button>
              </div>
              <div style={{ padding: "10px 10px 12px" }}>
                <div
                  style={{
                    fontFamily: "Cairo",
                    fontWeight: 700,
                    fontSize: 13,
                    color: COLORS.ink,
                    marginBottom: 4,
                    minHeight: 34,
                  }}
                >
                  {p.name}
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 4, marginBottom: 8 }}>
                  <Star size={12} color={COLORS.gold} fill={COLORS.gold} />
                  <span style={{ fontFamily: "Cairo", fontSize: 11, color: COLORS.inkMuted }}>
                    {p.rating}
                  </span>
                  {!outOfStock && p.stock <= 5 && (
                    <span style={{ fontFamily: "Cairo", fontSize: 10, color: COLORS.danger, fontWeight: 700 }}>
                      · {t("low_stock").replace("{n}", p.stock)}
                    </span>
                  )}
                </div>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <span style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 14, color: COLORS.greenDark }}>
                    {money(p.price)}
                  </span>
                  {outOfStock ? (
                    <span style={{ fontFamily: "Cairo", fontSize: 10.5, color: COLORS.inkMuted }}>{t("out_of_stock_line")}</span>
                  ) : qty === 0 ? (
                    <button
                      onClick={() => addToCart(p.id, p.sizes[0], p.colors[0], 1)}
                      style={{
                        width: 28,
                        height: 28,
                        borderRadius: "50%",
                        border: "none",
                        background: COLORS.green,
                        color: "#fff",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        cursor: "pointer",
                      }}
                    >
                      <Plus size={15} />
                    </button>
                  ) : (
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 6,
                        background: COLORS.greenSoft,
                        borderRadius: 20,
                        padding: "3px 4px",
                      }}
                    >
                      <button
                        onClick={() => addToCart(p.id, p.sizes[0], p.colors[0], 1)}
                        disabled={atMax}
                        style={{ border: "none", background: "none", cursor: atMax ? "default" : "pointer", display: "flex", opacity: atMax ? 0.4 : 1 }}
                      >
                        <Plus size={13} color={COLORS.green} />
                      </button>
                      <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.green, minWidth: 12, textAlign: "center" }}>
                        {qty}
                      </span>
                      <button
                        onClick={() => addToCart(p.id, p.sizes[0], p.colors[0], -1)}
                        style={{ border: "none", background: "none", cursor: "pointer", display: "flex" }}
                      >
                        <Minus size={13} color={COLORS.green} />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
        {filtered.length === 0 && (
          <div style={{ gridColumn: "1 / -1", textAlign: "center", padding: "40px 0", color: COLORS.inkMuted, fontFamily: "Cairo" }}>
            {t("no_results")}
          </div>
        )}
      </div>
    </div>
  );
}

function CartScreen({ cart, addToCart, removeFromCart, onRemoveMultiple, subtotal, goCheckout, onGoHome, onOpenProduct, t }) {
  const items = Object.entries(cart).filter(([, entry]) => entry.qty > 0);
  const delivery = items.length ? getDelivery(subtotal) : 0;
  const remaining = FREE_SHIPPING_THRESHOLD - subtotal;
  const cartProductIds = items.map(([, entry]) => entry.productId);
  const suggestions = PRODUCTS.filter((p) => !cartProductIds.includes(p.id) && p.stock > 0)
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 4);
  const [selectedKeys, setSelectedKeys] = useState([]);
  const allKeys = items.map(([key]) => key);
  const allSelected = allKeys.length > 0 && selectedKeys.length === allKeys.length;

  const toggleSelectAll = () => setSelectedKeys(allSelected ? [] : allKeys);
  const toggleSelectKey = (key) => setSelectedKeys((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  const deleteSelected = () => {
    onRemoveMultiple(selectedKeys);
    setSelectedKeys([]);
  };

  return (
    <div>
      <TopBar title={t("cart_title")} />
      {items.length === 0 ? (
        <div style={{ textAlign: "center", padding: "80px 30px", fontFamily: "Cairo", color: COLORS.inkMuted }}>
          <ShoppingCart size={40} color={COLORS.line} style={{ marginBottom: 12 }} />
          <div style={{ marginBottom: 18 }}>{t("cart_empty")}</div>
          <button
            onClick={onGoHome}
            style={{ background: COLORS.green, color: "#fff", border: "none", borderRadius: 12, padding: "11px 26px", fontFamily: "Cairo", fontWeight: 700, fontSize: 13, cursor: "pointer" }}
          >
            {t("continue_shopping_btn")}
          </button>
        </div>
      ) : (
        <>
          <div style={{ padding: "0 18px", display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
            <button
              onClick={toggleSelectAll}
              style={{ display: "flex", alignItems: "center", gap: 6, border: "none", background: "none", cursor: "pointer" }}
            >
              <div
                style={{
                  width: 18,
                  height: 18,
                  borderRadius: 5,
                  border: `1.5px solid ${allSelected ? COLORS.green : COLORS.line}`,
                  background: allSelected ? COLORS.green : COLORS.surface,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                {allSelected && <Check size={12} color="#fff" />}
              </div>
              <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.ink }}>
                {selectedKeys.length > 0 ? t("cart_selected_count").replace("{n}", selectedKeys.length) : t("cart_select_all")}
              </span>
            </button>
            {selectedKeys.length > 0 && (
              <button
                onClick={deleteSelected}
                style={{ display: "flex", alignItems: "center", gap: 5, border: "none", background: "none", cursor: "pointer", fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.danger }}
              >
                <Trash2 size={13} color={COLORS.danger} />
                {t("cart_delete_selected")}
              </button>
            )}
          </div>

          <div style={{ padding: "0 18px", display: "flex", flexDirection: "column", gap: 10, paddingBottom: 20 }}>
            {items.map(([key, entry]) => {
              const p = PRODUCTS.find((x) => x.id === entry.productId);
              const atMax = entry.qty >= p.stock;
              const isSelected = selectedKeys.includes(key);
              return (
                <div
                  key={key}
                  style={{
                    display: "flex",
                    gap: 12,
                    background: COLORS.surface,
                    border: `1px solid ${isSelected ? COLORS.green : COLORS.line}`,
                    borderRadius: 14,
                    padding: 10,
                    alignItems: "center",
                  }}
                >
                  <button
                    onClick={() => toggleSelectKey(key)}
                    style={{
                      flexShrink: 0,
                      width: 18,
                      height: 18,
                      borderRadius: 5,
                      border: `1.5px solid ${isSelected ? COLORS.green : COLORS.line}`,
                      background: isSelected ? COLORS.green : COLORS.surface,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      cursor: "pointer",
                      padding: 0,
                    }}
                  >
                    {isSelected && <Check size={12} color="#fff" />}
                  </button>
                  <ProductImage
                    src={p.img || `https://picsum.photos/seed/${p.seed}/120/120`}
                    alt={p.name}
                    style={{ width: 56, height: 56, borderRadius: 10, flexShrink: 0 }}
                  />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.ink }}>
                      {p.name}
                    </div>
                    <div style={{ fontFamily: "Cairo", fontSize: 11, color: COLORS.inkMuted, marginTop: 2 }}>
                      {entry.size} · {entry.color}
                    </div>
                    <div style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 13, color: COLORS.greenDark, marginTop: 3 }}>
                      {money(p.price * entry.qty)}
                    </div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, background: COLORS.greenSoft, borderRadius: 20, padding: "4px 6px" }}>
                    <button
                      onClick={() => addToCart(entry.productId, entry.size, entry.color, 1)}
                      disabled={atMax}
                      style={{ border: "none", background: "none", cursor: atMax ? "default" : "pointer", display: "flex", opacity: atMax ? 0.4 : 1 }}
                    >
                      <Plus size={13} color={COLORS.green} />
                    </button>
                    <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.green, minWidth: 12, textAlign: "center" }}>
                      {entry.qty}
                    </span>
                    <button onClick={() => addToCart(entry.productId, entry.size, entry.color, -1)} style={{ border: "none", background: "none", cursor: "pointer", display: "flex" }}>
                      <Minus size={13} color={COLORS.green} />
                    </button>
                  </div>
                  <button onClick={() => removeFromCart(key)} style={{ border: "none", background: "none", cursor: "pointer" }}>
                    <Trash2 size={16} color={COLORS.danger} />
                  </button>
                </div>
              );
            })}
          </div>

          {suggestions.length > 0 && (
            <div style={{ marginBottom: 6 }}>
              <div style={{ padding: "0 18px", marginBottom: 10 }}>
                <span style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 15, color: COLORS.ink }}>
                  {t("cart_suggestions_title")}
                </span>
              </div>
              <div style={{ display: "flex", gap: 10, padding: "0 18px 20px", overflowX: "auto" }}>
                {suggestions.map((p) => (
                  <MiniProductCard key={p.id} product={p} onOpen={onOpenProduct} />
                ))}
              </div>
            </div>
          )}

          <div style={{ padding: "0 18px 140px" }}>
            {remaining > 0 ? (
              <div style={{ background: COLORS.goldSoft, borderRadius: 12, padding: "10px 14px", marginBottom: 12, fontFamily: "Cairo", fontSize: 12, color: COLORS.goldText, fontWeight: 600, textAlign: "center" }}>
                {t("free_shipping_hint").replace("{amount}", money(remaining))}
              </div>
            ) : (
              <div style={{ background: COLORS.greenSoft, borderRadius: 12, padding: "10px 14px", marginBottom: 12, fontFamily: "Cairo", fontSize: 12, color: COLORS.green, fontWeight: 700, textAlign: "center", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
                <Truck size={14} />
                {t("free_shipping_unlocked")}
              </div>
            )}
            <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 16, padding: 16 }}>
              <Row label={t("cart_subtotal")} value={money(subtotal)} />
              <Row label={t("cart_delivery")} value={delivery === 0 ? t("free_label") : money(delivery)} />
              <div style={{ height: 1, background: COLORS.line, margin: "10px 0" }} />
              <Row label={t("cart_total")} value={money(subtotal + delivery)} bold />
            </div>
          </div>

          <div style={{ position: "fixed", bottom: 78, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 390, padding: "0 18px" }}>
            <button
              onClick={goCheckout}
              style={{
                width: "100%",
                background: COLORS.green,
                color: "#fff",
                border: "none",
                borderRadius: 14,
                padding: "15px 0",
                fontFamily: "Cairo",
                fontWeight: 700,
                fontSize: 15,
                cursor: "pointer",
              }}
            >
              {t("cart_checkout")}
            </button>
          </div>
        </>
      )}
    </div>
  );
}

function Row({ label, value, bold }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", padding: "5px 0" }}>
      <span style={{ fontFamily: "Cairo", fontSize: 13, color: bold ? COLORS.ink : COLORS.inkMuted, fontWeight: bold ? 700 : 500 }}>
        {label}
      </span>
      <span style={{ fontFamily: "Tajawal", fontSize: bold ? 16 : 13, color: bold ? COLORS.greenDark : COLORS.ink, fontWeight: bold ? 800 : 600 }}>
        {value}
      </span>
    </div>
  );
}

function LoginScreen({ onLogin, onBack, lang, t }) {
  const [mode, setMode] = useState("login");
  const [phone, setPhone] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [touched, setTouched] = useState(false);
  const [isVendorSignup, setIsVendorSignup] = useState(false);
  const [vendorPin, setVendorPin] = useState("");

  const isSignup = mode === "signup";

  const phoneValid = /^09\d{8}$/.test(phone.trim());
  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
  const nameValid = name.trim().length >= 2;
  const vendorPinValid = !isVendorSignup || /^\d{4}$/.test(vendorPin.trim());

  const canSubmit = isSignup ? nameValid && phoneValid && emailValid && vendorPinValid : nameValid && phoneValid;

  const handleSubmit = async () => {
    setTouched(true);
    if (!canSubmit) return;
    const vendorFields =
      isSignup && isVendorSignup ? { isVendor: true, vendorPinHash: await hashPin(vendorPin.trim()) } : {};
    onLogin({
      name: name.trim(),
      phone: phone.trim(),
      email: email.trim(),
      ...vendorFields,
    });
  };

  return (
    <div dir={STRINGS[lang].dir}>
      <TopBar title={isSignup ? t("signup_title") : t("login_title")} onBack={onBack} />
      <div style={{ padding: "10px 24px" }}>
        <div style={{ display: "flex", background: COLORS.greenSoft, borderRadius: 14, padding: 4, marginBottom: 20 }}>
          {["login", "signup"].map((m) => (
            <button
              key={m}
              onClick={() => { setMode(m); setTouched(false); }}
              style={{
                flex: 1,
                border: "none",
                borderRadius: 11,
                padding: "10px 0",
                background: mode === m ? COLORS.green : "transparent",
                color: mode === m ? "#fff" : COLORS.green,
                fontFamily: "Cairo",
                fontWeight: 700,
                fontSize: 13,
                cursor: "pointer",
              }}
            >
              {m === "login" ? t("tab_login") : t("tab_signup")}
            </button>
          ))}
        </div>

        <p style={{ fontFamily: "Cairo", color: COLORS.inkMuted, fontSize: 13, marginBottom: 20, lineHeight: 1.7 }}>
          {isSignup ? t("signup_subtitle") : t("login_subtitle")}
        </p>

        <label style={{ fontFamily: "Cairo", fontSize: 13, fontWeight: 700, color: COLORS.ink }}>{t("label_name")}</label>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder={t("placeholder_name")} style={inputStyle} />
        {touched && !nameValid && (
          <div style={{ fontFamily: "Cairo", fontSize: 11, color: COLORS.danger, marginTop: -14, marginBottom: 14 }}>
            {t("validation_name")}
          </div>
        )}

        {isSignup && (
          <>
            <label style={{ fontFamily: "Cairo", fontSize: 13, fontWeight: 700, color: COLORS.ink }}>{t("label_email")}</label>
            <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder={t("placeholder_email")} style={inputStyle} dir="ltr" />
            {touched && !emailValid && (
              <div style={{ fontFamily: "Cairo", fontSize: 11, color: COLORS.danger, marginTop: -14, marginBottom: 14 }}>
                {t("validation_email")}
              </div>
            )}
          </>
        )}

        <label style={{ fontFamily: "Cairo", fontSize: 13, fontWeight: 700, color: COLORS.ink }}>{t("label_phone")}</label>
        <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="09xxxxxxxx" style={inputStyle} dir="ltr" />
        {touched && !phoneValid && (
          <div style={{ fontFamily: "Cairo", fontSize: 11, color: COLORS.danger, marginTop: -14, marginBottom: 14 }}>
            {t("validation_phone")}
          </div>
        )}

        {isSignup && (
          <>
            <button
              onClick={() => setIsVendorSignup((v) => !v)}
              style={{ display: "flex", alignItems: "center", gap: 8, border: "none", background: "none", cursor: "pointer", padding: 0, marginBottom: isVendorSignup ? 12 : 20 }}
            >
              <div
                style={{
                  width: 18,
                  height: 18,
                  borderRadius: 5,
                  border: `1.5px solid ${isVendorSignup ? COLORS.green : COLORS.line}`,
                  background: isVendorSignup ? COLORS.green : COLORS.surface,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                }}
              >
                {isVendorSignup && <Check size={12} color="#fff" />}
              </div>
              <span style={{ fontFamily: "Cairo", fontSize: 12.5, color: COLORS.ink }}>{t("login_vendor_checkbox")}</span>
            </button>

            {isVendorSignup && (
              <>
                <label style={{ fontFamily: "Cairo", fontSize: 13, fontWeight: 700, color: COLORS.ink }}>{t("login_vendor_pin_label")}</label>
                <input
                  value={vendorPin}
                  onChange={(e) => setVendorPin(e.target.value.replace(/[^0-9]/g, "").slice(0, 4))}
                  placeholder={t("login_vendor_pin_placeholder")}
                  style={inputStyle}
                  dir="ltr"
                  inputMode="numeric"
                />
                {touched && !vendorPinValid && (
                  <div style={{ fontFamily: "Cairo", fontSize: 11, color: COLORS.danger, marginTop: -14, marginBottom: 14 }}>
                    {t("validation_vendor_pin")}
                  </div>
                )}
              </>
            )}
          </>
        )}

        <button
          onClick={handleSubmit}
          style={{
            width: "100%",
            marginTop: 10,
            background: touched && !canSubmit ? COLORS.line : COLORS.green,
            color: "#fff",
            border: "none",
            borderRadius: 14,
            padding: "15px 0",
            fontFamily: "Cairo",
            fontWeight: 700,
            fontSize: 15,
            cursor: "pointer",
          }}
        >
          {isSignup ? t("btn_signup") : t("btn_login")}
        </button>

        <button
          onClick={() => { setMode(isSignup ? "login" : "signup"); setTouched(false); }}
          style={{ width: "100%", marginTop: 14, background: "none", border: "none", fontFamily: "Cairo", fontSize: 12, color: COLORS.green, cursor: "pointer" }}
        >
          {isSignup ? t("switch_to_login") : t("switch_to_signup")}
        </button>
      </div>
    </div>
  );
}

const inputStyle = {
  width: "100%",
  boxSizing: "border-box",
  border: `1px solid ${COLORS.line}`,
  background: COLORS.surface,
  borderRadius: 12,
  padding: "12px 14px",
  fontFamily: "Cairo",
  fontSize: 14,
  color: COLORS.ink,
  margin: "8px 0 18px",
  outline: "none",
};

function CheckoutScreen({
  subtotal,
  itemCount,
  addresses,
  selectedAddressId,
  setSelectedAddressId,
  addAddress,
  updateAddress,
  removeAddress,
  payment,
  setPayment,
  couponCode,
  setCouponCode,
  appliedCoupon,
  couponError,
  applyCoupon,
  removeCoupon,
  discountAmount,
  loyaltyPoints,
  redeemPoints,
  setRedeemPoints,
  pointsDiscount,
  deliverySlot,
  setDeliverySlot,
  giftWrap,
  setGiftWrap,
  giftMessage,
  setGiftMessage,
  onBack,
  onConfirm,
  t,
}) {
  const delivery = getDelivery(subtotal);
  const giftWrapFee = giftWrap ? 5000 : 0;
  const total = subtotal + delivery + giftWrapFee - discountAmount;
  const [addingAddress, setAddingAddress] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [newLabel, setNewLabel] = useState("");
  const [newText, setNewText] = useState("");
  const selected = addresses.find((a) => a.id === selectedAddressId);

  const startAdd = () => {
    setEditingId(null);
    setNewLabel("");
    setNewText("");
    setAddingAddress((v) => !v);
  };

  const startEdit = (a) => {
    setEditingId(a.id);
    setNewLabel(a.label);
    setNewText(a.text);
    setAddingAddress(true);
  };

  const submitNewAddress = () => {
    if (!newText.trim()) return;
    if (editingId) {
      updateAddress(editingId, { label: newLabel.trim() || t("checkout_add_address"), text: newText.trim() });
    } else {
      addAddress({ label: newLabel.trim() || t("checkout_add_address"), text: newText.trim() });
    }
    setNewLabel("");
    setNewText("");
    setEditingId(null);
    setAddingAddress(false);
  };

  return (
    <div>
      <TopBar title={t("checkout_title")} onBack={onBack} />
      <div style={{ padding: "0 18px 150px" }}>
        <div
          style={{
            background: COLORS.greenSoft,
            borderRadius: 16,
            padding: 18,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            marginBottom: 18,
          }}
        >
          <Badge tone="green">{itemCount} {t("pieces_label")}</Badge>
          <div style={{ textAlign: "left" }}>
            <div style={{ fontFamily: "Cairo", fontSize: 12, color: COLORS.inkMuted }}>{t("checkout_total_amount")}</div>
            <div style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 20, color: COLORS.greenDark }}>
              {money(total)}
            </div>
          </div>
        </div>

        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
          <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 14, color: COLORS.ink }}>{t("checkout_address")}</span>
          <button
            onClick={startAdd}
            style={{ border: "none", background: "none", cursor: "pointer", fontFamily: "Cairo", fontSize: 12, fontWeight: 700, color: COLORS.green, display: "flex", alignItems: "center", gap: 4 }}
          >
            <Plus size={13} /> {t("checkout_add_address")}
          </button>
        </div>

        {addingAddress && (
          <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 12, marginBottom: 14 }}>
            <input
              value={newLabel}
              onChange={(e) => setNewLabel(e.target.value)}
              placeholder={t("address_name_placeholder")}
              style={{ ...inputStyle, margin: "0 0 8px" }}
            />
            <input
              value={newText}
              onChange={(e) => setNewText(e.target.value)}
              placeholder={t("address_text_placeholder")}
              style={{ ...inputStyle, margin: "0 0 10px" }}
            />
            <button
              onClick={submitNewAddress}
              style={{ width: "100%", background: COLORS.green, color: "#fff", border: "none", borderRadius: 10, padding: "10px 0", fontFamily: "Cairo", fontWeight: 700, fontSize: 13, cursor: "pointer" }}
            >
              {editingId ? t("address_edit_title") : t("address_save_btn")}
            </button>
          </div>
        )}

        {addresses.length === 0 && !addingAddress && (
          <div style={{ background: COLORS.surface, border: `1px dashed ${COLORS.line}`, borderRadius: 14, padding: 16, textAlign: "center", marginBottom: 22 }}>
            <span style={{ fontFamily: "Cairo", fontSize: 12, color: COLORS.inkMuted }}>{t("address_empty_hint")}</span>
          </div>
        )}

        <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 22 }}>
          {addresses.map((a) => {
            const active = a.id === selectedAddressId;
            return (
              <div
                key={a.id}
                onClick={() => setSelectedAddressId(a.id)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  background: active ? COLORS.greenSoft : COLORS.surface,
                  border: `1.5px solid ${active ? COLORS.green : COLORS.line}`,
                  borderRadius: 12,
                  padding: "12px 14px",
                  cursor: "pointer",
                  textAlign: "right",
                }}
              >
                <MapPin size={16} color={COLORS.green} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.ink }}>{a.label}</div>
                  <div style={{ fontFamily: "Cairo", fontSize: 11.5, color: COLORS.inkMuted, marginTop: 2 }}>{a.text}</div>
                </div>
                {active && <Check size={16} color={COLORS.green} style={{ flexShrink: 0 }} />}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    startEdit(a);
                  }}
                  title={t("address_edit_btn")}
                  style={{ border: "none", background: "none", cursor: "pointer", display: "flex", flexShrink: 0, padding: 4 }}
                >
                  <Edit3 size={14} color={COLORS.inkMuted} />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    removeAddress(a.id);
                  }}
                  title={t("address_delete_btn")}
                  style={{ border: "none", background: "none", cursor: "pointer", display: "flex", flexShrink: 0, padding: 4 }}
                >
                  <Trash2 size={14} color={COLORS.danger} />
                </button>
              </div>
            );
          })}
        </div>

        <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 14, color: COLORS.ink, marginBottom: 10 }}>
          {t("delivery_slot_label")}
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 22 }}>
          {[
            { id: "any", key: "delivery_slot_any" },
            { id: "morning", key: "delivery_slot_morning" },
            { id: "evening", key: "delivery_slot_evening" },
          ].map((s) => {
            const active = deliverySlot === s.id;
            return (
              <button
                key={s.id}
                onClick={() => setDeliverySlot(s.id)}
                style={{
                  padding: "9px 14px",
                  borderRadius: 10,
                  border: `1.5px solid ${active ? COLORS.green : COLORS.line}`,
                  background: active ? COLORS.green : COLORS.surface,
                  color: active ? "#fff" : COLORS.ink,
                  fontFamily: "Cairo",
                  fontWeight: 700,
                  fontSize: 12,
                  cursor: "pointer",
                }}
              >
                {t(s.key)}
              </button>
            );
          })}
        </div>

        <div
          style={{
            background: giftWrap ? COLORS.greenSoft : COLORS.surface,
            border: `1.5px solid ${giftWrap ? COLORS.green : COLORS.line}`,
            borderRadius: 14,
            padding: 14,
            marginBottom: 22,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <Gift size={16} color={COLORS.green} />
              <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12.5, color: COLORS.ink }}>
                {t("gift_wrap_toggle")}
              </span>
            </div>
            <button
              onClick={() => setGiftWrap((v) => !v)}
              style={{
                width: 44,
                height: 26,
                borderRadius: 16,
                border: `1px solid ${COLORS.line}`,
                background: giftWrap ? COLORS.green : COLORS.bg,
                position: "relative",
                cursor: "pointer",
                padding: 0,
                flexShrink: 0,
              }}
            >
              <div
                style={{
                  position: "absolute",
                  top: 2,
                  insetInlineStart: giftWrap ? 20 : 2,
                  width: 20,
                  height: 20,
                  borderRadius: "50%",
                  background: giftWrap ? "#fff" : COLORS.inkMuted,
                  transition: "inset-inline-start 0.2s ease",
                }}
              />
            </button>
          </div>
          {giftWrap && (
            <textarea
              value={giftMessage}
              onChange={(e) => setGiftMessage(e.target.value)}
              placeholder={t("gift_message_placeholder")}
              rows={2}
              style={{ ...inputStyle, margin: "12px 0 0", resize: "none", fontFamily: "Cairo" }}
            />
          )}
        </div>

        <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 14, color: COLORS.ink, marginBottom: 10 }}>
          {t("checkout_coupon")}
        </div>
        {appliedCoupon ? (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", background: COLORS.greenSoft, border: `1px solid ${COLORS.green}`, borderRadius: 12, padding: "12px 14px", marginBottom: 22 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <Ticket size={16} color={COLORS.green} />
              <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.green }}>
                {appliedCoupon.code}
              </span>
            </div>
            <button onClick={removeCoupon} style={{ border: "none", background: "none", cursor: "pointer" }}>
              <X size={16} color={COLORS.danger} />
            </button>
          </div>
        ) : (
          <div style={{ marginBottom: 22 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 12, padding: "6px 6px 6px 14px" }}>
              <Ticket size={16} color={COLORS.inkMuted} />
              <input
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value)}
                placeholder={t("coupon_placeholder")}
                style={{ border: "none", outline: "none", background: "transparent", fontFamily: "Cairo", fontSize: 13, color: COLORS.ink, flex: 1 }}
                dir="ltr"
              />
              <button
                onClick={applyCoupon}
                style={{ background: COLORS.green, color: "#fff", border: "none", borderRadius: 9, padding: "9px 16px", fontFamily: "Cairo", fontWeight: 700, fontSize: 12, cursor: "pointer" }}
              >
                {t("coupon_apply_btn")}
              </button>
            </div>
            {couponError && (
              <div style={{ fontFamily: "Cairo", fontSize: 11.5, color: COLORS.danger, marginTop: 6 }}>{couponError}</div>
            )}
          </div>
        )}

        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            background: redeemPoints ? COLORS.greenSoft : COLORS.surface,
            border: `1.5px solid ${redeemPoints ? COLORS.green : COLORS.line}`,
            borderRadius: 12,
            padding: "12px 14px",
            marginBottom: 22,
            opacity: loyaltyPoints >= 100 ? 1 : 0.6,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <Tag size={16} color={COLORS.green} />
            <div>
              <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12.5, color: COLORS.ink }}>
                {t("loyalty_redeem_toggle")}
              </div>
              {loyaltyPoints < 100 && (
                <div style={{ fontFamily: "Cairo", fontSize: 10.5, color: COLORS.inkMuted, marginTop: 2 }}>
                  {t("loyalty_redeem_need_more")}
                </div>
              )}
            </div>
          </div>
          <button
            onClick={() => setRedeemPoints((v) => !v)}
            disabled={loyaltyPoints < 100}
            style={{
              width: 44,
              height: 26,
              borderRadius: 16,
              border: `1px solid ${COLORS.line}`,
              background: redeemPoints ? COLORS.green : COLORS.bg,
              position: "relative",
              cursor: loyaltyPoints < 100 ? "default" : "pointer",
              padding: 0,
              flexShrink: 0,
            }}
          >
            <div
              style={{
                position: "absolute",
                top: 2,
                insetInlineStart: redeemPoints ? 20 : 2,
                width: 20,
                height: 20,
                borderRadius: "50%",
                background: redeemPoints ? "#fff" : COLORS.inkMuted,
                transition: "inset-inline-start 0.2s ease",
              }}
            />
          </button>
        </div>

        <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 14, color: COLORS.ink, marginBottom: 10 }}>
          {t("checkout_payment")}
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {PAYMENT_METHODS.map((m) => {
            const Icon = m.icon;
            const active = payment === m.id;
            const descKey = m.id === "card" ? "pay_card_desc" : m.id === "cod" ? "pay_cod_desc" : "pay_wallet_desc";
            const badgeKey = m.id === "cod" ? "pay_cod_badge" : m.id === "card" ? "pay_card_badge" : null;
            return (
              <button
                key={m.id}
                onClick={() => setPayment(m.id)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  background: active ? COLORS.greenSoft : COLORS.surface,
                  border: `1.5px solid ${active ? COLORS.green : COLORS.line}`,
                  borderRadius: 16,
                  padding: 14,
                  cursor: "pointer",
                  textAlign: "right",
                }}
              >
                <div
                  style={{
                    width: 22,
                    height: 22,
                    borderRadius: "50%",
                    border: `2px solid ${active ? COLORS.green : COLORS.line}`,
                    background: active ? COLORS.green : "transparent",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexShrink: 0,
                  }}
                >
                  {active && <Check size={13} color="#fff" />}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 14, color: COLORS.ink }}>
                      {t(`pay_${m.id}_name`)}
                    </span>
                    {badgeKey && <Badge>{t(badgeKey)}</Badge>}
                  </div>
                  <div style={{ fontFamily: "Cairo", fontSize: 12, color: COLORS.inkMuted, marginTop: 2 }}>
                    {t(descKey)}
                  </div>
                </div>
                <div style={{ width: 40, height: 40, borderRadius: 12, background: COLORS.bg, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <Icon size={18} color={COLORS.green} />
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <div style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 390, padding: 18, background: `linear-gradient(to top, ${COLORS.bg} 70%, transparent)` }}>
        <button
          disabled={!selected}
          onClick={onConfirm}
          style={{
            width: "100%",
            background: !selected ? COLORS.line : COLORS.green,
            color: "#fff",
            border: "none",
            borderRadius: 14,
            padding: "16px 0",
            fontFamily: "Cairo",
            fontWeight: 700,
            fontSize: 15,
            cursor: !selected ? "default" : "pointer",
          }}
        >
          {t("checkout_confirm")}
        </button>
      </div>
    </div>
  );
}

function ConfirmScreen({ orderId, isFirstOrder, onHome, onTrack, t }) {
  return (
    <div style={{ padding: "100px 30px", textAlign: "center" }}>
      <div
        style={{
          width: 72,
          height: 72,
          borderRadius: "50%",
          background: COLORS.green,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          margin: "0 auto 22px",
        }}
      >
        <Check size={34} color="#fff" />
      </div>
      <h2 style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 20, color: COLORS.ink, marginBottom: 8 }}>
        {isFirstOrder ? t("confirm_welcome_title") : t("confirm_title")}
      </h2>
      <p style={{ fontFamily: "Cairo", fontSize: 13, color: COLORS.inkMuted, lineHeight: 1.8, marginBottom: 4 }}>
        {t("confirm_order_number")} <span style={{ fontWeight: 700, color: COLORS.ink }}>#{orderId}</span>
      </p>
      <p style={{ fontFamily: "Cairo", fontSize: 13, color: COLORS.inkMuted, lineHeight: 1.8, marginBottom: isFirstOrder ? 18 : 30 }}>
        {t("confirm_subtitle")}
      </p>
      {isFirstOrder && (
        <div style={{ background: COLORS.goldSoft, border: `1.5px dashed ${COLORS.gold}`, borderRadius: 14, padding: 16, marginBottom: 26 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 6, marginBottom: 6 }}>
            <Ticket size={15} color={COLORS.goldText} />
            <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12.5, color: COLORS.goldText }}>
              {t("confirm_gift_title")}
            </span>
          </div>
          <p style={{ fontFamily: "Cairo", fontSize: 11.5, color: COLORS.goldText, lineHeight: 1.7, margin: 0 }}>
            {t("confirm_gift_desc")}
          </p>
        </div>
      )}
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        <button
          onClick={onTrack}
          style={{
            background: COLORS.green,
            color: "#fff",
            border: "none",
            borderRadius: 14,
            padding: "14px 30px",
            fontFamily: "Cairo",
            fontWeight: 700,
            fontSize: 14,
            cursor: "pointer",
          }}
        >
          {t("confirm_track_btn")}
        </button>
        <button
          onClick={onHome}
          style={{
            background: "none",
            color: COLORS.ink,
            border: `1px solid ${COLORS.line}`,
            borderRadius: 14,
            padding: "14px 30px",
            fontFamily: "Cairo",
            fontWeight: 700,
            fontSize: 14,
            cursor: "pointer",
          }}
        >
          {t("confirm_home_btn")}
        </button>
      </div>
    </div>
  );
}

function ProductDetailScreen({ product, cart, addToCart, favorites, toggleFavorite, reviews, addReview, questions, addQuestion, onBack, onOpenProduct, compareIds, toggleCompare, stockAlerts, toggleStockAlert, user, t }) {
  const [revName, setRevName] = useState(user?.name || "");
  const [revRating, setRevRating] = useState(5);
  const [revComment, setRevComment] = useState("");
  const [selectedSize, setSelectedSize] = useState(product?.sizes?.[0]);
  const [selectedColor, setSelectedColor] = useState(product?.colors?.[0]);
  const [imgIndex, setImgIndex] = useState(0);
  const [sizeGuideOpen, setSizeGuideOpen] = useState(false);
  const [qName, setQName] = useState(user?.name || "");
  const [qText, setQText] = useState("");

  useEffect(() => {
    if (!product) return;
    setSelectedSize(product.sizes[0]);
    setSelectedColor(product.colors[0]);
    setImgIndex(0);
  }, [product?.id]);

  if (!product) return null;
  const key = variantKey(product.id, selectedSize, selectedColor);
  const qty = cart[key]?.qty || 0;
  const isFav = !!favorites[product.id];
  const inCompare = compareIds.includes(product.id);
  const isSubscribedToStock = stockAlerts.includes(product.id);
  const productReviews = reviews[product.id] || [];
  const productQuestions = questions[product.id] || [];
  const ratingBreakdown = [5, 4, 3, 2, 1].map((star) => {
    const count = productReviews.filter((r) => r.rating === star).length;
    const pct = productReviews.length > 0 ? Math.round((count / productReviews.length) * 100) : 0;
    return { star, count, pct };
  });
  const related = PRODUCTS.filter((p) => p.cat === product.cat && p.id !== product.id).slice(0, 4);
  const completeLook = PRODUCTS.filter((p) => p.cat !== product.cat).slice(0, 4);
  const outOfStock = product.stock <= 0;
  const atMax = qty >= product.stock;
  const gallery = product.images && product.images.length > 0 ? product.images : [product.img || `https://picsum.photos/seed/${product.seed}/500/500`];

  const shareProduct = () => {
    const text = `${product.name} - ${money(product.price)} - Akumu`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, "_blank");
  };

  const submitReview = () => {
    if (!revName.trim() || !revComment.trim()) return;
    addReview(product.id, { name: revName.trim(), rating: revRating, comment: revComment.trim() });
    setRevName("");
    setRevComment("");
    setRevRating(5);
  };

  const submitQuestion = () => {
    if (!qName.trim() || !qText.trim()) return;
    addQuestion(product.id, { name: qName.trim(), question: qText.trim() });
    setQText("");
  };

  return (
    <div>
      <TopBar title={t("product_detail_title")} onBack={onBack} />
      <SizeGuideModal open={sizeGuideOpen} onClose={() => setSizeGuideOpen(false)} sizes={product.sizes} t={t} />
      <div style={{ padding: "0 18px 130px" }}>
        <div style={{ position: "relative", borderRadius: 18, overflow: "hidden", marginBottom: 10 }}>
          <ProductImage
            key={gallery[imgIndex]}
            src={gallery[imgIndex]}
            alt={product.name}
            style={{ width: "100%", height: 280 }}
          />
          {product.badge && (
            <div style={{ position: "absolute", top: 12, right: 12 }}>
              <Badge>{product.badge}</Badge>
            </div>
          )}
          <div style={{ position: "absolute", top: 12, left: 12, display: "flex", gap: 8 }}>
            <button
              onClick={() => toggleFavorite(product.id)}
              style={{
                width: 34,
                height: 34,
                borderRadius: "50%",
                border: "none",
                background: "rgba(255,255,255,0.9)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
              }}
            >
              <Heart size={17} color={isFav ? COLORS.danger : COLORS.inkMuted} fill={isFav ? COLORS.danger : "none"} />
            </button>
            <button
              onClick={() => toggleCompare(product.id)}
              title={inCompare ? t("compare_toggle_remove") : t("compare_toggle_add")}
              style={{
                width: 34,
                height: 34,
                borderRadius: "50%",
                border: "none",
                background: inCompare ? COLORS.gold : "rgba(255,255,255,0.9)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
              }}
            >
              <Scale size={16} color={inCompare ? "#fff" : COLORS.inkMuted} />
            </button>
            <button
              onClick={shareProduct}
              style={{
                width: 34,
                height: 34,
                borderRadius: "50%",
                border: "none",
                background: "rgba(255,255,255,0.9)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
              }}
            >
              <Send size={15} color={COLORS.inkMuted} />
            </button>
          </div>
          {gallery.length > 1 && (
            <div style={{ position: "absolute", bottom: 10, left: "50%", transform: "translateX(-50%)", display: "flex", gap: 5 }}>
              {gallery.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setImgIndex(i)}
                  style={{
                    width: i === imgIndex ? 16 : 6,
                    height: 6,
                    borderRadius: 4,
                    border: "none",
                    background: i === imgIndex ? "#fff" : "rgba(255,255,255,0.5)",
                    cursor: "pointer",
                    padding: 0,
                    transition: "width 0.2s",
                  }}
                />
              ))}
            </div>
          )}
        </div>

        {gallery.length > 1 && (
          <div style={{ display: "flex", gap: 8, marginBottom: 16, overflowX: "auto" }}>
            {gallery.map((src, i) => (
              <button
                key={i}
                onClick={() => setImgIndex(i)}
                style={{
                  flexShrink: 0,
                  width: 52,
                  height: 52,
                  borderRadius: 10,
                  overflow: "hidden",
                  border: `2px solid ${i === imgIndex ? COLORS.green : "transparent"}`,
                  padding: 0,
                  cursor: "pointer",
                }}
              >
                <img src={src} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
              </button>
            ))}
          </div>
        )}

        <h2 style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 19, color: COLORS.ink, marginBottom: 8 }}>
          {product.name}
        </h2>

        <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 14 }}>
          <Star size={14} color={COLORS.gold} fill={COLORS.gold} />
          <span style={{ fontFamily: "Cairo", fontSize: 13, color: COLORS.inkMuted }}>{product.rating}</span>
          <span style={{ fontFamily: "Cairo", fontSize: 12, color: COLORS.inkMuted }}>
            · {t(`cat_${product.cat}`)}
          </span>
          {productReviews.length > 0 && (
            <span style={{ fontFamily: "Cairo", fontSize: 12, color: COLORS.inkMuted }}>· {productReviews.length} {t("product_reviews_count")}</span>
          )}
        </div>

        <div style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 24, color: COLORS.greenDark, marginBottom: 6 }}>
          {money(product.price)}
        </div>

        {outOfStock ? (
          <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.danger, marginBottom: 16 }}>
            {t("product_out_of_stock")}
          </div>
        ) : (
          product.stock <= 5 && (
            <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.danger, marginBottom: 16 }}>
              {t("product_low_stock").replace("{n}", product.stock)}
            </div>
          )
        )}

        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
          <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.ink }}>{t("product_size_label")}</span>
          {product.sizes.length > 1 && (
            <button
              onClick={() => setSizeGuideOpen(true)}
              style={{ border: "none", background: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 4, padding: 0 }}
            >
              <ClipboardList size={12} color={COLORS.green} />
              <span style={{ fontFamily: "Cairo", fontSize: 11.5, fontWeight: 700, color: COLORS.green, textDecoration: "underline" }}>
                {t("size_guide_link")}
              </span>
            </button>
          )}
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 16 }}>
          {product.sizes.map((s) => (
            <button
              key={s}
              onClick={() => setSelectedSize(s)}
              style={{
                padding: "8px 14px",
                borderRadius: 10,
                border: `1.5px solid ${selectedSize === s ? COLORS.green : COLORS.line}`,
                background: selectedSize === s ? COLORS.green : COLORS.surface,
                color: selectedSize === s ? "#fff" : COLORS.ink,
                fontFamily: "Cairo",
                fontWeight: 700,
                fontSize: 12.5,
                cursor: "pointer",
              }}
            >
              {s}
            </button>
          ))}
        </div>

        <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.ink, marginBottom: 8 }}>{t("product_color_label")}</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 18 }}>
          {product.colors.map((c) => (
            <button
              key={c}
              onClick={() => setSelectedColor(c)}
              style={{
                padding: "8px 14px",
                borderRadius: 20,
                border: `1.5px solid ${selectedColor === c ? COLORS.green : COLORS.line}`,
                background: selectedColor === c ? COLORS.greenSoft : COLORS.surface,
                color: selectedColor === c ? COLORS.green : COLORS.ink,
                fontFamily: "Cairo",
                fontWeight: 700,
                fontSize: 12.5,
                cursor: "pointer",
              }}
            >
              {c}
            </button>
          ))}
        </div>

        <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 16, padding: 16, marginBottom: 18 }}>
          <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.ink, marginBottom: 6 }}>
            {t("product_description_label")}
          </div>
          <p style={{ fontFamily: "Cairo", fontSize: 12.5, color: COLORS.inkMuted, lineHeight: 1.9, margin: 0 }}>
            {t("product_description_text").replace("{name}", product.name)}
          </p>
        </div>

        <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 14, color: COLORS.ink, marginBottom: 10 }}>
          {t("product_qa_title")}
        </div>
        {productQuestions.length === 0 ? (
          <div style={{ fontFamily: "Cairo", fontSize: 12, color: COLORS.inkMuted, marginBottom: 14 }}>
            {t("product_qa_empty")}
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 14 }}>
            {productQuestions.map((q, i) => (
              <div key={i} style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 12 }}>
                <div style={{ display: "flex", alignItems: "flex-start", gap: 8, marginBottom: 6 }}>
                  <HelpCircle size={14} color={COLORS.green} style={{ flexShrink: 0, marginTop: 1 }} />
                  <div>
                    <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.ink }}>{q.name}: </span>
                    <span style={{ fontFamily: "Cairo", fontSize: 12, color: COLORS.ink }}>{q.question}</span>
                  </div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 5, paddingInlineStart: 22 }}>
                  <Clock size={11} color={COLORS.goldText} />
                  <span style={{ fontFamily: "Cairo", fontSize: 11, color: COLORS.goldText }}>{t("product_qa_pending")}</span>
                </div>
              </div>
            ))}
          </div>
        )}
        <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 16, padding: 14, marginBottom: 18 }}>
          <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12.5, color: COLORS.ink, marginBottom: 10 }}>
            {t("product_ask_question")}
          </div>
          <input
            value={qName}
            onChange={(e) => setQName(e.target.value)}
            placeholder={t("placeholder_short_name")}
            style={{ ...inputStyle, margin: "0 0 8px" }}
          />
          <textarea
            value={qText}
            onChange={(e) => setQText(e.target.value)}
            placeholder={t("placeholder_question")}
            rows={2}
            style={{ ...inputStyle, margin: "0 0 10px", resize: "none", fontFamily: "Cairo" }}
          />
          <button
            onClick={submitQuestion}
            style={{ width: "100%", background: COLORS.green, color: "#fff", border: "none", borderRadius: 10, padding: "11px 0", fontFamily: "Cairo", fontWeight: 700, fontSize: 13, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}
          >
            <Send size={14} /> {t("product_qa_submit")}
          </button>
        </div>

        {related.length > 0 && (
          <div style={{ marginBottom: 22 }}>
            <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 14, color: COLORS.ink, marginBottom: 10 }}>
              {t("product_related_title")}
            </div>
            <div style={{ display: "flex", gap: 10, overflowX: "auto", paddingBottom: 4 }}>
              {related.map((rp) => (
                <MiniProductCard key={rp.id} product={rp} onOpen={onOpenProduct} />
              ))}
            </div>
          </div>
        )}

        {completeLook.length > 0 && (
          <div style={{ marginBottom: 22 }}>
            <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 14, color: COLORS.ink, marginBottom: 10 }}>
              {t("complete_look_title")}
            </div>
            <div style={{ display: "flex", gap: 10, overflowX: "auto", paddingBottom: 4 }}>
              {completeLook.map((rp) => (
                <MiniProductCard key={rp.id} product={rp} onOpen={onOpenProduct} />
              ))}
            </div>
          </div>
        )}

        <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 14, color: COLORS.ink, marginBottom: 10 }}>
          {t("product_reviews_title")}
        </div>

        {productReviews.length > 0 && (
          <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 14, marginBottom: 14 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
              <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12.5, color: COLORS.ink }}>{t("rating_breakdown_title")}</span>
              <span style={{ fontFamily: "Cairo", fontSize: 11, color: COLORS.inkMuted }}>{t("rating_based_on").replace("{n}", productReviews.length)}</span>
            </div>
            {ratingBreakdown.map((row) => (
              <div key={row.star} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 5 }}>
                <span style={{ fontFamily: "Cairo", fontSize: 11, color: COLORS.inkMuted, width: 34, flexShrink: 0, display: "flex", alignItems: "center", gap: 2 }}>
                  {row.star} <Star size={9} color={COLORS.gold} fill={COLORS.gold} />
                </span>
                <div style={{ flex: 1, height: 6, borderRadius: 4, background: COLORS.line, overflow: "hidden" }}>
                  <div style={{ width: `${row.pct}%`, height: "100%", background: COLORS.gold, borderRadius: 4, transition: "width 0.3s ease" }} />
                </div>
                <span style={{ fontFamily: "Cairo", fontSize: 10.5, color: COLORS.inkMuted, width: 20, textAlign: "left", flexShrink: 0 }}>{row.count}</span>
              </div>
            ))}
          </div>
        )}

        {productReviews.length === 0 ? (
          <div style={{ fontFamily: "Cairo", fontSize: 12, color: COLORS.inkMuted, marginBottom: 14 }}>
            {t("product_no_reviews")}
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 14 }}>
            {productReviews.map((r, i) => (
              <div key={i} style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 12 }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
                  <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12.5, color: COLORS.ink }}>{r.name}</span>
                  <div style={{ display: "flex", gap: 1 }}>
                    {[1, 2, 3, 4, 5].map((n) => (
                      <Star key={n} size={11} color={COLORS.gold} fill={n <= r.rating ? COLORS.gold : "none"} />
                    ))}
                  </div>
                </div>
                <p style={{ fontFamily: "Cairo", fontSize: 12, color: COLORS.inkMuted, lineHeight: 1.7, margin: 0 }}>{r.comment}</p>
              </div>
            ))}
          </div>
        )}

        <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 16, padding: 14 }}>
          <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12.5, color: COLORS.ink, marginBottom: 10 }}>
            {t("product_add_review")}
          </div>
          <div style={{ display: "flex", gap: 4, marginBottom: 10 }}>
            {[1, 2, 3, 4, 5].map((n) => (
              <button key={n} onClick={() => setRevRating(n)} style={{ border: "none", background: "none", cursor: "pointer", padding: 0 }}>
                <Star size={20} color={COLORS.gold} fill={n <= revRating ? COLORS.gold : "none"} />
              </button>
            ))}
          </div>
          <input
            value={revName}
            onChange={(e) => setRevName(e.target.value)}
            placeholder={t("placeholder_short_name")}
            style={{ ...inputStyle, margin: "0 0 8px" }}
          />
          <textarea
            value={revComment}
            onChange={(e) => setRevComment(e.target.value)}
            placeholder={t("placeholder_review_comment")}
            rows={3}
            style={{ ...inputStyle, margin: "0 0 10px", resize: "none", fontFamily: "Cairo" }}
          />
          <button
            onClick={submitReview}
            style={{ width: "100%", background: COLORS.green, color: "#fff", border: "none", borderRadius: 10, padding: "11px 0", fontFamily: "Cairo", fontWeight: 700, fontSize: 13, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}
          >
            <Send size={14} /> {t("product_publish_review")}
          </button>
        </div>
      </div>

      <div style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 390, padding: 18, background: `linear-gradient(to top, ${COLORS.bg} 70%, transparent)`, display: "flex", gap: 10 }}>
        {outOfStock ? (
          <button
            onClick={() => toggleStockAlert(product.id)}
            style={{
              flex: 1,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              background: isSubscribedToStock ? COLORS.greenSoft : COLORS.green,
              color: isSubscribedToStock ? COLORS.green : "#fff",
              border: isSubscribedToStock ? `1.5px solid ${COLORS.green}` : "none",
              borderRadius: 14,
              padding: "15px 0",
              fontFamily: "Cairo",
              fontWeight: 700,
              fontSize: 14,
              cursor: "pointer",
            }}
          >
            <Bell size={16} />
            {isSubscribedToStock ? t("notify_stock_subscribed_btn") : t("notify_stock_btn")}
          </button>
        ) : qty === 0 ? (
          <button
            onClick={() => addToCart(product.id, selectedSize, selectedColor, 1)}
            style={{
              flex: 1,
              background: COLORS.green,
              color: "#fff",
              border: "none",
              borderRadius: 14,
              padding: "15px 0",
              fontFamily: "Cairo",
              fontWeight: 700,
              fontSize: 15,
              cursor: "pointer",
            }}
          >
            {t("product_add_to_cart")}
          </button>
        ) : (
          <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "space-between", background: COLORS.greenSoft, borderRadius: 14, padding: "8px 16px" }}>
            <button
              onClick={() => addToCart(product.id, selectedSize, selectedColor, 1)}
              disabled={atMax}
              style={{ border: "none", background: "none", cursor: atMax ? "default" : "pointer", display: "flex", opacity: atMax ? 0.4 : 1 }}
            >
              <Plus size={18} color={COLORS.green} />
            </button>
            <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 15, color: COLORS.green }}>{qty}</span>
            <button onClick={() => addToCart(product.id, selectedSize, selectedColor, -1)} style={{ border: "none", background: "none", cursor: "pointer", display: "flex" }}>
              <Minus size={18} color={COLORS.green} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function CompareScreen({ compareIds, onRemove, onBack, t }) {
  const items = compareIds.map((id) => PRODUCTS.find((p) => p.id === id)).filter(Boolean);

  const rows = [
    { key: "compare_price_row", render: (p) => money(p.price) },
    {
      key: "compare_rating_row",
      render: (p) => (
        <span style={{ display: "flex", alignItems: "center", gap: 4, justifyContent: "center" }}>
          <Star size={12} color={COLORS.gold} fill={COLORS.gold} />
          {p.rating}
        </span>
      ),
    },
    {
      key: "compare_stock_row",
      render: (p) => (p.stock > 0 ? t("compare_in_stock") : t("out_of_stock_line")),
    },
    { key: "compare_sizes_row", render: (p) => p.sizes.join(" · ") },
    { key: "compare_colors_row", render: (p) => p.colors.join(" · ") },
  ];

  return (
    <div>
      <TopBar title={t("compare_title")} onBack={onBack} />
      {items.length === 0 ? (
        <div style={{ textAlign: "center", padding: "80px 30px", fontFamily: "Cairo", color: COLORS.inkMuted }}>
          <Scale size={40} color={COLORS.line} style={{ marginBottom: 12 }} />
          <div>{t("compare_empty")}</div>
        </div>
      ) : (
        <div style={{ padding: "0 18px 40px", overflowX: "auto" }}>
          <div style={{ display: "flex", gap: 10, minWidth: items.length * 140 }}>
            {items.map((p) => (
              <div
                key={p.id}
                style={{
                  width: 140,
                  flexShrink: 0,
                  background: COLORS.surface,
                  border: `1px solid ${COLORS.line}`,
                  borderRadius: 16,
                  overflow: "hidden",
                }}
              >
                <div style={{ position: "relative" }}>
                  <ProductImage src={p.img} alt={p.name} style={{ width: "100%", height: 100 }} />
                  <button
                    onClick={() => onRemove(p.id)}
                    style={{
                      position: "absolute",
                      top: 6,
                      insetInlineEnd: 6,
                      width: 22,
                      height: 22,
                      borderRadius: "50%",
                      border: "none",
                      background: "rgba(255,255,255,0.9)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      cursor: "pointer",
                    }}
                  >
                    <X size={12} color={COLORS.danger} />
                  </button>
                </div>
                <div style={{ padding: 10 }}>
                  <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.ink, minHeight: 32, textAlign: "center" }}>
                    {p.name}
                  </div>
                  {rows.map((row) => (
                    <div key={row.key} style={{ borderTop: `1px solid ${COLORS.line}`, padding: "8px 0", textAlign: "center" }}>
                      <div style={{ fontFamily: "Cairo", fontSize: 9.5, color: COLORS.inkMuted, marginBottom: 3 }}>{t(row.key)}</div>
                      <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 11, color: COLORS.ink }}>{row.render(p)}</div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}


function FlashSaleBanner({ product, onOpen, t }) {
  const [secondsLeft, setSecondsLeft] = useState(() => 3 * 3600 + 45 * 60);

  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsLeft((s) => (s > 0 ? s - 1 : 3 * 3600));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const h = String(Math.floor(secondsLeft / 3600)).padStart(2, "0");
  const m = String(Math.floor((secondsLeft % 3600) / 60)).padStart(2, "0");
  const s = String(secondsLeft % 60).padStart(2, "0");

  return (
    <button
      onClick={onOpen}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        width: "100%",
        background: `linear-gradient(120deg, ${COLORS.danger}, #8A3320)`,
        border: "none",
        borderRadius: 16,
        padding: 14,
        cursor: "pointer",
        textAlign: "start",
        marginBottom: 20,
      }}
    >
      <ProductImage src={product.img} alt={product.name} style={{ width: 56, height: 56, borderRadius: 12, flexShrink: 0 }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 5, marginBottom: 3 }}>
          <Clock size={12} color="#fff" />
          <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 11, color: "#fff" }}>{t("flash_sale_title")}</span>
        </div>
        <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12.5, color: "#fff", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
          {product.name}
        </div>
        <div style={{ fontFamily: "Cairo", fontSize: 10.5, color: "rgba(255,255,255,0.85)", marginTop: 2 }}>
          {t("flash_sale_ends_in")} {h}{t("flash_sale_hours")} {m}{t("flash_sale_minutes")} {s}{t("flash_sale_seconds")}
        </div>
      </div>
      <div style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 14, color: "#fff", flexShrink: 0 }}>
        {money(product.price)}
      </div>
    </button>
  );
}

function DealsScreen({ onBack, onOpenProduct, lang, t }) {
  const couponDesc = (c) => {
    if (c.type === "percent") {
      return lang === "ar" ? `خصم ${c.value}%` : lang === "tr" ? `%${c.value} indirim` : `${c.value}% off`;
    }
    return lang === "ar" ? `خصم ${money(c.value)}` : lang === "tr" ? `${money(c.value)} indirim` : `${money(c.value)} off`;
  };
  const [copiedCode, setCopiedCode] = useState(null);
  const copyCode = (code) => {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(code).then(() => {
        setCopiedCode(code);
        setTimeout(() => setCopiedCode(null), 1500);
      }).catch(() => {});
    }
  };
  const dealProducts = PRODUCTS.filter((p) => !!p.badge);
  const flashProduct = [...PRODUCTS].sort((a, b) => b.price - a.price)[0];

  return (
    <div>
      <TopBar title={t("deals_title")} onBack={onBack} />
      <div style={{ padding: "0 18px 100px" }}>
        <FlashSaleBanner product={flashProduct} onOpen={() => onOpenProduct(flashProduct.id)} t={t} />

        {Object.keys(COUPONS).length === 0 && dealProducts.length === 0 ? (
          <div style={{ textAlign: "center", padding: "80px 20px", color: COLORS.inkMuted, fontFamily: "Cairo" }}>
            <Ticket size={36} color={COLORS.line} style={{ marginBottom: 12 }} />
            <div>{t("deals_empty")}</div>
          </div>
        ) : (
          <>
            <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 14, color: COLORS.ink, marginBottom: 10 }}>
              {t("deals_coupons_section")}
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 24 }}>
              {Object.entries(COUPONS).map(([code, c]) => (
                <button
                  key={code}
                  onClick={() => copyCode(code)}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    background: `linear-gradient(120deg, ${COLORS.green}, ${COLORS.greenDark})`,
                    border: "none",
                    borderRadius: 14,
                    padding: "14px 16px",
                    cursor: "pointer",
                    textAlign: "start",
                  }}
                >
                  <div>
                    <div style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 16, color: "#fff", letterSpacing: 1 }} dir="ltr">
                      {code}
                    </div>
                    <div style={{ fontFamily: "Cairo", fontSize: 11.5, color: "rgba(255,255,255,0.8)", marginTop: 2 }}>
                      {couponDesc(c)}
                    </div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 5, background: "rgba(255,255,255,0.15)", borderRadius: 10, padding: "6px 10px" }}>
                    <ClipboardList size={12} color="#fff" />
                    <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 11, color: "#fff" }}>
                      {copiedCode === code ? t("order_copied") : t("order_copy")}
                    </span>
                  </div>
                </button>
              ))}
            </div>

            {dealProducts.length > 0 && (
              <>
                <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 14, color: COLORS.ink, marginBottom: 10 }}>
                  {t("deals_products_section")}
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  {dealProducts.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => onOpenProduct(p.id)}
                      style={{ textAlign: "start", background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 16, overflow: "hidden", cursor: "pointer", padding: 0 }}
                    >
                      <ProductImage src={p.img} alt={p.name} style={{ width: "100%", height: 110 }} />
                      <div style={{ padding: 10 }}>
                        <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12.5, color: COLORS.ink, minHeight: 32 }}>{p.name}</div>
                        <div style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 13, color: COLORS.greenDark, marginTop: 4 }}>{money(p.price)}</div>
                      </div>
                    </button>
                  ))}
                </div>
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function MyReviewsScreen({ reviews, user, onBack, onOpenProduct, t }) {
  const myReviews = [];
  Object.entries(reviews).forEach(([productId, list]) => {
    const product = PRODUCTS.find((p) => p.id === Number(productId));
    if (!product) return;
    list.forEach((r) => {
      if (user && r.name === user.name) {
        myReviews.push({ ...r, product });
      }
    });
  });

  return (
    <div>
      <TopBar title={t("my_reviews_title")} onBack={onBack} />
      {myReviews.length === 0 ? (
        <div style={{ textAlign: "center", padding: "80px 30px", fontFamily: "Cairo", color: COLORS.inkMuted }}>
          <MessageSquare size={40} color={COLORS.line} style={{ marginBottom: 12 }} />
          <div>{t("my_reviews_empty")}</div>
        </div>
      ) : (
        <div style={{ padding: "0 18px 100px", display: "flex", flexDirection: "column", gap: 10 }}>
          {myReviews.map((r, i) => (
            <button
              key={i}
              onClick={() => onOpenProduct(r.product.id)}
              style={{
                display: "flex",
                gap: 12,
                background: COLORS.surface,
                border: `1px solid ${COLORS.line}`,
                borderRadius: 14,
                padding: 12,
                cursor: "pointer",
                textAlign: "start",
              }}
            >
              <ProductImage src={r.product.img} alt={r.product.name} style={{ width: 52, height: 52, borderRadius: 10, flexShrink: 0 }} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12.5, color: COLORS.ink }}>{r.product.name}</div>
                <div style={{ display: "flex", gap: 1, margin: "4px 0" }}>
                  {[1, 2, 3, 4, 5].map((n) => (
                    <Star key={n} size={11} color={COLORS.gold} fill={n <= r.rating ? COLORS.gold : "none"} />
                  ))}
                </div>
                <div style={{ fontFamily: "Cairo", fontSize: 11.5, color: COLORS.inkMuted, lineHeight: 1.6 }}>{r.comment}</div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function AboutScreen({ onBack, t }) {
  return (
    <div>
      <TopBar title={t("about_title")} onBack={onBack} />
      <div style={{ padding: "0 18px 40px", textAlign: "center" }}>
        <img src={LOGO_IMG} alt="Akumu" style={{ width: 64, height: 64, borderRadius: 16, margin: "10px auto 14px" }} />
        <div style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 20, color: COLORS.ink, marginBottom: 4 }}>Akumu</div>
        <div style={{ fontFamily: "Cairo", fontSize: 11.5, color: COLORS.inkMuted, marginBottom: 18 }}>
          {t("about_version_label")} 1.0.0
        </div>
        <p style={{ fontFamily: "Cairo", fontSize: 12.5, color: COLORS.inkMuted, lineHeight: 1.9, marginBottom: 26, textAlign: "start" }}>
          {t("about_description")}
        </p>

        <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.ink, marginBottom: 10, textAlign: "start" }}>
          {t("about_legal_title")}
        </div>
        <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 14, marginBottom: 10, textAlign: "start" }}>
          <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.ink, marginBottom: 6 }}>
            {t("about_terms_title")}
          </div>
          <p style={{ fontFamily: "Cairo", fontSize: 11.5, color: COLORS.inkMuted, lineHeight: 1.8, margin: 0 }}>
            {t("about_terms_text")}
          </p>
        </div>
        <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 14, textAlign: "start" }}>
          <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.ink, marginBottom: 6 }}>
            {t("about_privacy_title")}
          </div>
          <p style={{ fontFamily: "Cairo", fontSize: 11.5, color: COLORS.inkMuted, lineHeight: 1.8, margin: 0 }}>
            {t("about_privacy_text")}
          </p>
        </div>
      </div>
    </div>
  );
}

function VendorProductModal({ open, onClose, onSave, editingProduct, t }) {
  const [name, setName] = useState("");
  const [cat, setCat] = useState("women");
  const [price, setPrice] = useState("");
  const [stock, setStock] = useState("");
  const [sizesText, setSizesText] = useState("");
  const [colorsText, setColorsText] = useState("");

  useEffect(() => {
    if (editingProduct) {
      setName(editingProduct.name);
      setCat(editingProduct.cat);
      setPrice(String(editingProduct.price));
      setStock(String(editingProduct.stock));
      setSizesText(editingProduct.sizes.join(","));
      setColorsText(editingProduct.colors.join(","));
    } else {
      setName("");
      setCat("women");
      setPrice("");
      setStock("");
      setSizesText("");
      setColorsText("");
    }
  }, [editingProduct, open]);

  if (!open) return null;

  const canSave = name.trim() && Number(price) > 0 && Number(stock) >= 0 && sizesText.trim() && colorsText.trim();

  const submit = () => {
    if (!canSave) return;
    onSave(
      {
        name: name.trim(),
        cat,
        price: Number(price),
        stock: Number(stock),
        sizes: sizesText.split(",").map((s) => s.trim()).filter(Boolean),
        colors: colorsText.split(",").map((c) => c.trim()).filter(Boolean),
      },
      editingProduct ? editingProduct.id : null
    );
    onClose();
  };

  return (
    <div
      onClick={onClose}
      style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)", zIndex: 40, display: "flex", alignItems: "flex-end", justifyContent: "center" }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "100%",
          maxWidth: 390,
          maxHeight: "85vh",
          overflowY: "auto",
          background: COLORS.bg,
          borderTopLeftRadius: 22,
          borderTopRightRadius: 22,
          padding: "18px 18px 30px",
          animation: "ak-fadein 0.25s ease",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <span style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 16, color: COLORS.ink }}>
            {editingProduct ? t("vendor_edit_product_title") : t("vendor_new_product_title")}
          </span>
          <button onClick={onClose} style={{ border: "none", background: "none", cursor: "pointer", display: "flex" }}>
            <X size={20} color={COLORS.inkMuted} />
          </button>
        </div>

        <input value={name} onChange={(e) => setName(e.target.value)} placeholder={t("vendor_product_name_placeholder")} style={inputStyle} />

        <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.ink, marginBottom: 8 }}>
          {t("vendor_product_category_label")}
        </div>
        <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
          {CATEGORIES.filter((c) => c.id !== "all").map((c) => (
            <button
              key={c.id}
              onClick={() => setCat(c.id)}
              style={{
                flex: 1,
                padding: "9px 0",
                borderRadius: 10,
                border: `1.5px solid ${cat === c.id ? COLORS.green : COLORS.line}`,
                background: cat === c.id ? COLORS.green : COLORS.surface,
                color: cat === c.id ? "#fff" : COLORS.ink,
                fontFamily: "Cairo",
                fontWeight: 700,
                fontSize: 11.5,
                cursor: "pointer",
              }}
            >
              {t(`cat_${c.id}`)}
            </button>
          ))}
        </div>

        <div style={{ display: "flex", gap: 10 }}>
          <input value={price} onChange={(e) => setPrice(e.target.value.replace(/[^0-9]/g, ""))} placeholder={t("vendor_product_price_placeholder")} style={{ ...inputStyle, flex: 1 }} dir="ltr" />
          <input value={stock} onChange={(e) => setStock(e.target.value.replace(/[^0-9]/g, ""))} placeholder={t("vendor_product_stock_placeholder")} style={{ ...inputStyle, flex: 1 }} dir="ltr" />
        </div>

        <input value={sizesText} onChange={(e) => setSizesText(e.target.value)} placeholder={t("vendor_product_sizes_placeholder")} style={inputStyle} />
        <input value={colorsText} onChange={(e) => setColorsText(e.target.value)} placeholder={t("vendor_product_colors_placeholder")} style={inputStyle} />

        <button
          onClick={submit}
          disabled={!canSave}
          style={{
            width: "100%",
            background: canSave ? COLORS.green : COLORS.line,
            color: "#fff",
            border: "none",
            borderRadius: 12,
            padding: "13px 0",
            fontFamily: "Cairo",
            fontWeight: 700,
            fontSize: 14,
            cursor: canSave ? "pointer" : "default",
          }}
        >
          {t("vendor_save_product_btn")}
        </button>
      </div>
    </div>
  );
}

function VendorPinGateScreen({ user, onSuccess, onBack, t }) {
  const [pin, setPin] = useState("");
  const [error, setError] = useState(false);

  const submit = async () => {
    const enteredHash = await hashPin(pin.trim());
    if (enteredHash === user?.vendorPinHash) {
      onSuccess();
    } else {
      setError(true);
    }
  };

  return (
    <div>
      <TopBar title={t("vendor_pin_gate_title")} onBack={onBack} />
      <div style={{ padding: "20px 24px", textAlign: "center" }}>
        <div
          style={{
            width: 60,
            height: 60,
            borderRadius: "50%",
            background: COLORS.greenSoft,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            margin: "10px auto 18px",
          }}
        >
          <Package size={26} color={COLORS.green} />
        </div>
        <p style={{ fontFamily: "Cairo", fontSize: 13, color: COLORS.inkMuted, marginBottom: 22 }}>
          {t("vendor_pin_gate_subtitle")}
        </p>
        <input
          value={pin}
          onChange={(e) => {
            setPin(e.target.value.replace(/[^0-9]/g, "").slice(0, 4));
            setError(false);
          }}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          placeholder={t("vendor_pin_gate_placeholder")}
          maxLength={4}
          inputMode="numeric"
          style={{ ...inputStyle, textAlign: "center", fontSize: 22, letterSpacing: 8, fontFamily: "Tajawal" }}
          dir="ltr"
        />
        {error && (
          <div style={{ fontFamily: "Cairo", fontSize: 12, color: COLORS.danger, marginTop: -10, marginBottom: 16 }}>
            {t("vendor_pin_gate_error")}
          </div>
        )}
        <button
          onClick={submit}
          disabled={pin.length !== 4}
          style={{
            width: "100%",
            marginTop: 8,
            background: pin.length === 4 ? COLORS.green : COLORS.line,
            color: "#fff",
            border: "none",
            borderRadius: 14,
            padding: "14px 0",
            fontFamily: "Cairo",
            fontWeight: 700,
            fontSize: 14,
            cursor: pin.length === 4 ? "pointer" : "default",
          }}
        >
          {t("vendor_pin_gate_submit")}
        </button>
      </div>
    </div>
  );
}

function VendorScreen({ orders, onAdvanceOrder, onBack, onSaveProduct, onDeleteProduct, onGoStorefront, t }) {
  const [tab, setTab] = useState("dashboard");
  const [formOpen, setFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);

  const totalOrders = orders.length;
  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);
  const totalProducts = PRODUCTS.length;
  const lowStockCount = PRODUCTS.filter((p) => p.stock > 0 && p.stock <= 5).length;

  const openAdd = () => {
    setEditingProduct(null);
    setFormOpen(true);
  };
  const openEdit = (p) => {
    setEditingProduct(p);
    setFormOpen(true);
  };

  return (
    <div>
      <TopBar title={t("vendor_dashboard_title")} onBack={onBack} />
      <VendorProductModal open={formOpen} onClose={() => setFormOpen(false)} onSave={onSaveProduct} editingProduct={editingProduct} t={t} />

      <div style={{ padding: "0 18px 12px" }}>
        <div style={{ display: "flex", background: COLORS.greenSoft, borderRadius: 14, padding: 4 }}>
          {[
            { id: "dashboard", label: t("vendor_tab_dashboard") },
            { id: "products", label: t("vendor_tab_products") },
            { id: "orders", label: t("vendor_tab_orders") },
          ].map((tb) => (
            <button
              key={tb.id}
              onClick={() => setTab(tb.id)}
              style={{
                flex: 1,
                border: "none",
                borderRadius: 11,
                padding: "9px 0",
                background: tab === tb.id ? COLORS.green : "transparent",
                color: tab === tb.id ? "#fff" : COLORS.green,
                fontFamily: "Cairo",
                fontWeight: 700,
                fontSize: 12,
                cursor: "pointer",
              }}
            >
              {tb.label}
            </button>
          ))}
        </div>
      </div>

      <div style={{ padding: "0 18px 100px" }}>
        {tab === "dashboard" && (
          <>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 20 }}>
              {[
                { label: t("vendor_stat_orders"), value: totalOrders, icon: ClipboardList },
                { label: t("vendor_stat_revenue"), value: money(totalRevenue), icon: Tag },
                { label: t("vendor_stat_products"), value: totalProducts, icon: Package },
                { label: t("vendor_stat_low_stock"), value: lowStockCount, icon: Bell },
              ].map((s, i) => {
                const Icon = s.icon;
                return (
                  <div key={i} style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 14 }}>
                    <Icon size={16} color={COLORS.green} style={{ marginBottom: 8 }} />
                    <div style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 17, color: COLORS.ink }}>{s.value}</div>
                    <div style={{ fontFamily: "Cairo", fontSize: 11, color: COLORS.inkMuted, marginTop: 2 }}>{s.label}</div>
                  </div>
                );
              })}
            </div>
            <button
              onClick={onGoStorefront}
              style={{ width: "100%", border: `1px solid ${COLORS.line}`, background: COLORS.surface, borderRadius: 12, padding: "12px 0", fontFamily: "Cairo", fontWeight: 700, fontSize: 12.5, color: COLORS.ink, cursor: "pointer" }}
            >
              {t("vendor_view_storefront")}
            </button>
          </>
        )}

        {tab === "products" && (
          <>
            <button
              onClick={openAdd}
              style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, background: COLORS.green, color: "#fff", border: "none", borderRadius: 12, padding: "12px 0", fontFamily: "Cairo", fontWeight: 700, fontSize: 13, cursor: "pointer", marginBottom: 16 }}
            >
              <Plus size={15} /> {t("vendor_add_product_btn")}
            </button>
            {PRODUCTS.length === 0 ? (
              <div style={{ textAlign: "center", padding: "60px 20px", color: COLORS.inkMuted, fontFamily: "Cairo" }}>
                {t("vendor_no_products")}
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {PRODUCTS.map((p) => (
                  <div key={p.id} style={{ display: "flex", gap: 12, background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 10, alignItems: "center" }}>
                    <ProductImage src={p.img} alt={p.name} style={{ width: 52, height: 52, borderRadius: 10, flexShrink: 0 }} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12.5, color: COLORS.ink }}>{p.name}</div>
                      <div style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 12.5, color: COLORS.greenDark, marginTop: 2 }}>{money(p.price)}</div>
                      <div style={{ marginTop: 3 }}>
                        {p.stock <= 0 ? (
                          <span style={{ fontFamily: "Cairo", fontSize: 10, fontWeight: 700, color: COLORS.danger }}>{t("vendor_out_of_stock_badge")}</span>
                        ) : p.stock <= 5 ? (
                          <span style={{ fontFamily: "Cairo", fontSize: 10, fontWeight: 700, color: COLORS.goldText }}>{t("vendor_low_stock_badge")} · {p.stock}</span>
                        ) : (
                          <span style={{ fontFamily: "Cairo", fontSize: 10, color: COLORS.inkMuted }}>{p.stock}</span>
                        )}
                      </div>
                    </div>
                    <button onClick={() => openEdit(p)} style={{ border: "none", background: "none", cursor: "pointer", display: "flex", flexShrink: 0, padding: 6 }} title={t("vendor_edit_product_btn")}>
                      <Edit3 size={15} color={COLORS.inkMuted} />
                    </button>
                    <button onClick={() => onDeleteProduct(p.id)} style={{ border: "none", background: "none", cursor: "pointer", display: "flex", flexShrink: 0, padding: 6 }} title={t("vendor_delete_product_btn")}>
                      <Trash2 size={15} color={COLORS.danger} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {tab === "orders" && (
          <>
            {orders.length === 0 ? (
              <div style={{ textAlign: "center", padding: "60px 20px", color: COLORS.inkMuted, fontFamily: "Cairo" }}>
                {t("vendor_no_orders")}
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {orders.slice().reverse().map((o) => (
                  <div key={o.id} style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 14 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                      <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12.5, color: COLORS.ink }}>{t("order_label")} #{o.id}</span>
                      <StatusPill stepIndex={o.stepIndex} cancelled={o.cancelled} t={t} />
                    </div>
                    <div style={{ fontFamily: "Cairo", fontSize: 11, color: COLORS.inkMuted, marginBottom: 8 }}>
                      {o.items.reduce((s, i) => s + i.qty, 0)} {t("pieces_label")} · {money(o.total)}
                    </div>
                    {!o.cancelled && o.stepIndex < ORDER_STEP_KEYS.length - 1 && (
                      <button
                        onClick={() => onAdvanceOrder(o.id)}
                        style={{ width: "100%", border: `1px dashed ${COLORS.line}`, background: "none", borderRadius: 10, padding: "8px 0", fontFamily: "Cairo", fontSize: 11.5, color: COLORS.inkMuted, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}
                      >
                        <RefreshCw size={12} />
                        {t(`order_step_${ORDER_STEP_KEYS[Math.min(o.stepIndex + 1, ORDER_STEP_KEYS.length - 1)]}`)}
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function ContactScreen({ onBack, lang, t }) {
  const [openFaq, setOpenFaq] = useState(null);
  const faqs = FAQS_BY_LANG[lang] || FAQS_BY_LANG.ar;
  return (
    <div>
      <TopBar title={t("contact_title")} onBack={onBack} />
      <div style={{ padding: "0 18px 100px" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 24 }}>
          <a
            href="https://wa.me/963900000000"
            target="_blank"
            rel="noreferrer"
            style={{ display: "flex", alignItems: "center", gap: 12, background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 14, textDecoration: "none" }}
          >
            <div style={{ width: 38, height: 38, borderRadius: "50%", background: COLORS.greenSoft, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <MessageSquare size={17} color={COLORS.green} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.ink }}>{t("contact_whatsapp")}</div>
              <div style={{ fontFamily: "Cairo", fontSize: 11.5, color: COLORS.inkMuted }} dir="ltr">+963 900 000 000</div>
            </div>
          </a>
          <a
            href="tel:+963900000000"
            style={{ display: "flex", alignItems: "center", gap: 12, background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 14, textDecoration: "none" }}
          >
            <div style={{ width: 38, height: 38, borderRadius: "50%", background: COLORS.greenSoft, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Phone size={17} color={COLORS.green} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.ink }}>{t("contact_phone")}</div>
              <div style={{ fontFamily: "Cairo", fontSize: 11.5, color: COLORS.inkMuted }} dir="ltr">+963 900 000 000</div>
            </div>
          </a>
          <a
            href="mailto:support@akumu.com"
            style={{ display: "flex", alignItems: "center", gap: 12, background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 14, textDecoration: "none" }}
          >
            <div style={{ width: 38, height: 38, borderRadius: "50%", background: COLORS.greenSoft, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Mail size={17} color={COLORS.green} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.ink }}>{t("contact_email")}</div>
              <div style={{ fontFamily: "Cairo", fontSize: 11.5, color: COLORS.inkMuted }} dir="ltr">support@akumu.com</div>
            </div>
          </a>
        </div>

        <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 14, color: COLORS.ink, marginBottom: 10 }}>
          {t("contact_faq_title")}
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {faqs.map((f, i) => {
            const isOpen = openFaq === i;
            return (
              <div key={i} style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, overflow: "hidden" }}>
                <button
                  onClick={() => setOpenFaq(isOpen ? null : i)}
                  style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between", padding: 14, border: "none", background: "none", cursor: "pointer", textAlign: "right" }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <HelpCircle size={15} color={COLORS.green} />
                    <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12.5, color: COLORS.ink }}>{f.q}</span>
                  </div>
                  <ChevronDown size={16} color={COLORS.inkMuted} style={{ transform: isOpen ? "rotate(180deg)" : "none", transition: "transform 0.2s" }} />
                </button>
                {isOpen && (
                  <div style={{ padding: "0 14px 14px 38px" }}>
                    <p style={{ fontFamily: "Cairo", fontSize: 12, color: COLORS.inkMuted, lineHeight: 1.8, margin: 0 }}>{f.a}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function EditProfileScreen({ user, onSave, onBack, t }) {
  const [name, setName] = useState(user?.name || "");
  const [email, setEmail] = useState(user?.email || "");
  const [phone, setPhone] = useState(user?.phone || "");
  const [touched, setTouched] = useState(false);

  const nameValid = name.trim().length >= 2;
  const phoneValid = /^09\d{8}$/.test(phone.trim());
  const emailValid = email.trim() === "" || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
  const canSubmit = nameValid && phoneValid && emailValid;

  const handleSave = () => {
    setTouched(true);
    if (!canSubmit) return;
    onSave({ name: name.trim(), email: email.trim(), phone: phone.trim() });
    onBack();
  };

  return (
    <div>
      <TopBar title={t("edit_profile_title")} onBack={onBack} />
      <div style={{ padding: "10px 24px 40px" }}>
        <label style={{ fontFamily: "Cairo", fontSize: 13, fontWeight: 700, color: COLORS.ink }}>{t("label_name")}</label>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder={t("placeholder_name")} style={inputStyle} />
        {touched && !nameValid && (
          <div style={{ fontFamily: "Cairo", fontSize: 11, color: COLORS.danger, marginTop: -14, marginBottom: 14 }}>
            {t("validation_name")}
          </div>
        )}

        <label style={{ fontFamily: "Cairo", fontSize: 13, fontWeight: 700, color: COLORS.ink }}>{t("label_email")}</label>
        <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder={t("placeholder_email")} style={inputStyle} dir="ltr" />
        {touched && !emailValid && (
          <div style={{ fontFamily: "Cairo", fontSize: 11, color: COLORS.danger, marginTop: -14, marginBottom: 14 }}>
            {t("validation_email")}
          </div>
        )}

        <label style={{ fontFamily: "Cairo", fontSize: 13, fontWeight: 700, color: COLORS.ink }}>{t("label_phone")}</label>
        <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="09xxxxxxxx" style={inputStyle} dir="ltr" />
        {touched && !phoneValid && (
          <div style={{ fontFamily: "Cairo", fontSize: 11, color: COLORS.danger, marginTop: -14, marginBottom: 14 }}>
            {t("validation_phone")}
          </div>
        )}

        <button
          onClick={handleSave}
          style={{
            width: "100%",
            marginTop: 10,
            background: COLORS.green,
            color: "#fff",
            border: "none",
            borderRadius: 14,
            padding: "15px 0",
            fontFamily: "Cairo",
            fontWeight: 700,
            fontSize: 15,
            cursor: "pointer",
          }}
        >
          {t("edit_profile_save")}
        </button>
      </div>
    </div>
  );
}

function NotificationsScreen({ notifications, onBack, t }) {
  return (
    <div>
      <TopBar title={t("notifications_title")} onBack={onBack} />
      <div style={{ padding: "0 18px 100px", display: "flex", flexDirection: "column", gap: 10 }}>
        {notifications.length === 0 && (
          <div style={{ textAlign: "center", padding: "80px 20px", color: COLORS.inkMuted, fontFamily: "Cairo" }}>
            <Bell size={36} color={COLORS.line} style={{ marginBottom: 12 }} />
            <div>{t("notifications_empty")}</div>
          </div>
        )}
        {notifications.slice().reverse().map((n) => (
          <div key={n.id} style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 14, display: "flex", gap: 10, alignItems: "flex-start" }}>
            <div style={{ width: 32, height: 32, borderRadius: "50%", background: COLORS.greenSoft, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <Truck size={15} color={COLORS.green} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "Cairo", fontWeight: 600, fontSize: 12.5, color: COLORS.ink, lineHeight: 1.6 }}>{n.text}</div>
              <div style={{ fontFamily: "Cairo", fontSize: 10.5, color: COLORS.inkMuted, marginTop: 4 }}>{n.time}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function FavoritesScreen({ favorites, toggleFavorite, cart, addToCart, onBack, onGoHome, t }) {
  const items = PRODUCTS.filter((p) => favorites[p.id]);

  const shareFavorites = () => {
    const lines = items.map((p) => `• ${p.name} - ${money(p.price)}`).join("\n");
    const text = `Akumu ${t("account_favorites")}:\n${lines}`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, "_blank");
  };

  return (
    <div>
      <TopBar
        title={t("account_favorites")}
        onBack={onBack}
        action={
          items.length > 0 ? (
            <button onClick={shareFavorites} title={t("favorites_share_btn")} style={{ border: "none", background: "none", cursor: "pointer", display: "flex" }}>
              <Send size={17} color={COLORS.green} />
            </button>
          ) : null
        }
      />
      {items.length === 0 ? (
        <div style={{ textAlign: "center", padding: "80px 30px", fontFamily: "Cairo", color: COLORS.inkMuted }}>
          <Heart size={40} color={COLORS.line} style={{ marginBottom: 12 }} />
          <div style={{ marginBottom: 18 }}>{t("favorites_empty")}</div>
          <button
            onClick={onGoHome}
            style={{ background: COLORS.green, color: "#fff", border: "none", borderRadius: 12, padding: "11px 26px", fontFamily: "Cairo", fontWeight: 700, fontSize: 13, cursor: "pointer" }}
          >
            {t("continue_shopping_btn")}
          </button>
        </div>
      ) : (
        <div style={{ padding: "0 18px 100px", display: "flex", flexDirection: "column", gap: 10 }}>
          {items.map((p) => {
            const defKey = variantKey(p.id, p.sizes[0], p.colors[0]);
            const qty = cart[defKey]?.qty || 0;
            const outOfStock = p.stock <= 0;
            const atMax = qty >= p.stock;
            return (
              <div
                key={p.id}
                style={{
                  display: "flex",
                  gap: 12,
                  background: COLORS.surface,
                  border: `1px solid ${COLORS.line}`,
                  borderRadius: 14,
                  padding: 10,
                  alignItems: "center",
                }}
              >
                <ProductImage
                  src={p.img || `https://picsum.photos/seed/${p.seed}/120/120`}
                  alt={p.name}
                  style={{ width: 56, height: 56, borderRadius: 10, flexShrink: 0 }}
                />
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.ink }}>
                    {p.name}
                  </div>
                  <div style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 13, color: COLORS.greenDark, marginTop: 3 }}>
                    {money(p.price)}
                  </div>
                </div>
                {outOfStock ? (
                  <span style={{ fontFamily: "Cairo", fontSize: 10.5, color: COLORS.inkMuted, flexShrink: 0 }}>{t("out_of_stock_line")}</span>
                ) : qty === 0 ? (
                  <button
                    onClick={() => addToCart(p.id, p.sizes[0], p.colors[0], 1)}
                    style={{
                      width: 30,
                      height: 30,
                      borderRadius: "50%",
                      border: "none",
                      background: COLORS.green,
                      color: "#fff",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      cursor: "pointer",
                      flexShrink: 0,
                    }}
                  >
                    <Plus size={15} />
                  </button>
                ) : (
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 6,
                      background: COLORS.greenSoft,
                      borderRadius: 20,
                      padding: "3px 4px",
                      flexShrink: 0,
                    }}
                  >
                    <button
                      onClick={() => addToCart(p.id, p.sizes[0], p.colors[0], 1)}
                      disabled={atMax}
                      style={{ border: "none", background: "none", cursor: atMax ? "default" : "pointer", display: "flex", opacity: atMax ? 0.4 : 1 }}
                    >
                      <Plus size={13} color={COLORS.green} />
                    </button>
                    <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.green, minWidth: 12, textAlign: "center" }}>
                      {qty}
                    </span>
                    <button onClick={() => addToCart(p.id, p.sizes[0], p.colors[0], -1)} style={{ border: "none", background: "none", cursor: "pointer", display: "flex" }}>
                      <Minus size={13} color={COLORS.green} />
                    </button>
                  </div>
                )}
                <button onClick={() => toggleFavorite(p.id)} style={{ border: "none", background: "none", cursor: "pointer", flexShrink: 0 }}>
                  <Heart size={16} color={COLORS.danger} fill={COLORS.danger} />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function OrdersScreen({ orders, onBack, onOpenOrder, t }) {
  const [query, setQuery] = useState("");
  const filtered = orders.filter((o) => {
    const q = query.trim();
    if (!q) return true;
    if (String(o.id).includes(q)) return true;
    return o.items.some((it) => it.name.includes(q));
  });

  return (
    <div>
      <TopBar title={t("account_orders")} onBack={onBack} />
      {orders.length > 0 && (
        <div style={{ padding: "0 18px 14px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: "10px 14px" }}>
            <Search size={16} color={COLORS.inkMuted} />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t("orders_search_placeholder")}
              style={{ border: "none", outline: "none", background: "transparent", fontFamily: "Cairo", fontSize: 13, color: COLORS.ink, width: "100%" }}
            />
          </div>
        </div>
      )}
      <div style={{ padding: "0 18px 100px", display: "flex", flexDirection: "column", gap: 12 }}>
        {orders.length === 0 && (
          <div style={{ textAlign: "center", padding: "80px 20px", color: COLORS.inkMuted, fontFamily: "Cairo" }}>
            <ClipboardList size={36} color={COLORS.line} style={{ marginBottom: 12 }} />
            <div>{t("orders_empty")}</div>
          </div>
        )}
        {orders.length > 0 && filtered.length === 0 && (
          <div style={{ textAlign: "center", padding: "60px 20px", color: COLORS.inkMuted, fontFamily: "Cairo", fontSize: 13 }}>
            {t("no_results")}
          </div>
        )}
        {filtered.slice().reverse().map((o) => (
          <button
            key={o.id}
            onClick={() => onOpenOrder(o.id)}
            style={{
              textAlign: "right",
              background: COLORS.surface,
              border: `1px solid ${COLORS.line}`,
              borderRadius: 16,
              padding: 14,
              cursor: "pointer",
              display: "flex",
              flexDirection: "column",
              gap: 8,
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.ink }}>
                {t("order_label")} #{o.id}
              </span>
              <StatusPill stepIndex={o.stepIndex} cancelled={o.cancelled} t={t} />
            </div>
            <div style={{ fontFamily: "Cairo", fontSize: 11, color: COLORS.inkMuted }}>{o.date}</div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontFamily: "Cairo", fontSize: 12, color: COLORS.inkMuted }}>
                {o.items.reduce((s, i) => s + i.qty, 0)} {t("pieces_label")}
              </span>
              <span style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 14, color: COLORS.greenDark }}>
                {money(o.total)}
              </span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function OrderDetailScreen({ order, onBack, onAdvance, onCancel, onRequestReturn, onReorder, t }) {
  const [copied, setCopied] = useState(false);
  const [returnFormOpen, setReturnFormOpen] = useState(false);
  const [returnType, setReturnType] = useState("return");
  const [returnReason, setReturnReason] = useState("");
  if (!order) return null;
  const isCancelled = order.cancelled;
  const canCancel = !isCancelled && order.stepIndex <= 1;
  const isDelivered = !isCancelled && order.stepIndex === ORDER_STEP_KEYS.length - 1;

  const submitReturn = () => {
    if (!returnReason.trim()) return;
    onRequestReturn(order.id, { type: returnType, reason: returnReason.trim() });
    setReturnFormOpen(false);
    setReturnReason("");
  };

  const copyOrderNumber = () => {
    const text = `#${order.id}`;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }).catch(() => {});
    }
  };

  const shareOrder = () => {
    const statusLabel = isCancelled ? t("order_status_cancelled") : t(`order_step_${ORDER_STEP_KEYS[order.stepIndex]}`);
    const text = `Akumu #${order.id} - ${statusLabel}`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, "_blank");
  };

  return (
    <div>
      <TopBar title={`${t("order_label")} #${order.id}`} onBack={onBack} />
      <div style={{ padding: "0 18px 100px" }}>
        <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
          <button
            onClick={copyOrderNumber}
            style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 12, padding: "10px 0", fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.ink, cursor: "pointer" }}
          >
            <ClipboardList size={14} color={COLORS.green} />
            {copied ? t("order_copied") : t("order_copy")}
          </button>
          <button
            onClick={shareOrder}
            style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 12, padding: "10px 0", fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.ink, cursor: "pointer" }}
          >
            <Send size={13} color={COLORS.green} />
            {t("share_label")}
          </button>
        </div>

        {isCancelled ? (
          <div style={{ background: COLORS.dangerSoft, border: `1px solid ${COLORS.danger}`, borderRadius: 16, padding: 16, marginBottom: 16, display: "flex", alignItems: "center", gap: 10 }}>
            <X size={18} color={COLORS.danger} />
            <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.danger }}>{t("order_cancelled_msg")}</span>
          </div>
        ) : (
          <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 16, padding: 18, marginBottom: 16 }}>
            {ORDER_STEP_KEYS.map((stepKey, i) => {
              const Icon = ORDER_STEP_ICONS[stepKey];
              const done = i <= order.stepIndex;
              const isLast = i === ORDER_STEP_KEYS.length - 1;
              return (
                <div key={stepKey} style={{ display: "flex", gap: 12 }}>
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
                    <div
                      style={{
                        width: 30,
                        height: 30,
                        borderRadius: "50%",
                        background: done ? COLORS.green : COLORS.bg,
                        border: `1.5px solid ${done ? COLORS.green : COLORS.line}`,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        flexShrink: 0,
                      }}
                    >
                      <Icon size={15} color={done ? "#fff" : COLORS.inkMuted} />
                    </div>
                    {!isLast && (
                      <div style={{ width: 2, flex: 1, minHeight: 26, background: i < order.stepIndex ? COLORS.green : COLORS.line }} />
                    )}
                  </div>
                  <div style={{ paddingBottom: isLast ? 0 : 20 }}>
                    <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: done ? COLORS.ink : COLORS.inkMuted }}>
                      {t(`order_step_${stepKey}`)}
                    </div>
                    {i === order.stepIndex && (
                      <div style={{ fontFamily: "Cairo", fontSize: 11, color: COLORS.green, marginTop: 2 }}>{t("order_current_status")}</div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {!isCancelled && order.stepIndex < ORDER_STEP_KEYS.length - 1 && (
          <button
            onClick={() => onAdvance(order.id)}
            style={{
              width: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              border: `1px dashed ${COLORS.line}`,
              background: "none",
              borderRadius: 12,
              padding: "10px 0",
              fontFamily: "Cairo",
              fontSize: 12,
              color: COLORS.inkMuted,
              cursor: "pointer",
              marginBottom: 12,
            }}
          >
            <RefreshCw size={13} />
            {t("order_simulate_update")}
          </button>
        )}

        {canCancel && (
          <button
            onClick={() => onCancel(order.id)}
            style={{
              width: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              border: `1px solid ${COLORS.danger}`,
              background: "none",
              borderRadius: 12,
              padding: "11px 0",
              fontFamily: "Cairo",
              fontWeight: 700,
              fontSize: 12.5,
              color: COLORS.danger,
              cursor: "pointer",
              marginBottom: 12,
            }}
          >
            <X size={14} />
            {t("order_cancel_btn")}
          </button>
        )}

        <button
          onClick={() => onReorder(order)}
          style={{
            width: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            border: `1px solid ${COLORS.green}`,
            background: "none",
            borderRadius: 12,
            padding: "11px 0",
            fontFamily: "Cairo",
            fontWeight: 700,
            fontSize: 12.5,
            color: COLORS.green,
            cursor: "pointer",
            marginBottom: 12,
          }}
        >
          <RefreshCw size={14} />
          {t("account_reorder_btn")}
        </button>

        {isDelivered && (
          order.returnRequest ? (
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                background: COLORS.goldSoft,
                border: `1px solid ${COLORS.gold}`,
                borderRadius: 12,
                padding: "11px 14px",
                marginBottom: 20,
              }}
            >
              <Clock size={14} color={COLORS.goldText} />
              <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.goldText }}>
                {t("return_status_pending")}
              </span>
            </div>
          ) : returnFormOpen ? (
            <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 14, marginBottom: 20 }}>
              <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.ink, marginBottom: 10 }}>
                {t("return_request_title")}
              </div>
              <div style={{ fontFamily: "Cairo", fontSize: 11.5, fontWeight: 700, color: COLORS.inkMuted, marginBottom: 6 }}>
                {t("return_type_label")}
              </div>
              <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
                {["return", "exchange"].map((tp) => (
                  <button
                    key={tp}
                    onClick={() => setReturnType(tp)}
                    style={{
                      flex: 1,
                      padding: "9px 0",
                      borderRadius: 10,
                      border: `1.5px solid ${returnType === tp ? COLORS.green : COLORS.line}`,
                      background: returnType === tp ? COLORS.green : COLORS.bg,
                      color: returnType === tp ? "#fff" : COLORS.ink,
                      fontFamily: "Cairo",
                      fontWeight: 700,
                      fontSize: 12,
                      cursor: "pointer",
                    }}
                  >
                    {tp === "return" ? t("return_type_return") : t("return_type_exchange")}
                  </button>
                ))}
              </div>
              <div style={{ fontFamily: "Cairo", fontSize: 11.5, fontWeight: 700, color: COLORS.inkMuted, marginBottom: 6 }}>
                {t("return_reason_label")}
              </div>
              <textarea
                value={returnReason}
                onChange={(e) => setReturnReason(e.target.value)}
                placeholder={t("return_reason_placeholder")}
                rows={3}
                style={{ ...inputStyle, margin: "0 0 12px", resize: "none", fontFamily: "Cairo" }}
              />
              <button
                onClick={submitReturn}
                style={{ width: "100%", background: COLORS.green, color: "#fff", border: "none", borderRadius: 10, padding: "11px 0", fontFamily: "Cairo", fontWeight: 700, fontSize: 13, cursor: "pointer" }}
              >
                {t("return_submit_btn")}
              </button>
            </div>
          ) : (
            <button
              onClick={() => setReturnFormOpen(true)}
              style={{
                width: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 8,
                border: `1px solid ${COLORS.line}`,
                background: "none",
                borderRadius: 12,
                padding: "11px 0",
                fontFamily: "Cairo",
                fontWeight: 700,
                fontSize: 12.5,
                color: COLORS.ink,
                cursor: "pointer",
                marginBottom: 20,
              }}
            >
              <RotateCcw size={14} color={COLORS.inkMuted} />
              {t("return_request_btn")}
            </button>
          )
        )}

        <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 14, color: COLORS.ink, marginBottom: 10 }}>
          {t("order_details_title")}
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 18 }}>
          {order.items.map((it, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 12, padding: 12 }}>
              <span style={{ fontFamily: "Cairo", fontSize: 12, color: COLORS.ink }}>
                {it.name} {it.size ? `(${it.size} · ${it.color})` : ""} × {it.qty}
              </span>
              <span style={{ fontFamily: "Cairo", fontSize: 12, fontWeight: 700, color: COLORS.greenDark }}>
                {money(it.price * it.qty)}
              </span>
            </div>
          ))}
        </div>

        <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 16, padding: 16 }}>
          <Row label={t("order_payment_method")} value={t(`pay_${order.payment}_name`)} />
          <Row label={t("checkout_address")} value={order.address} />
          {order.deliverySlot && order.deliverySlot !== "any" && (
            <Row label={t("delivery_slot_label")} value={t(`delivery_slot_${order.deliverySlot}`)} />
          )}
          {order.giftWrap && <Row label={t("gift_wrap_toggle")} value="🎁" />}
          {order.coupon && <Row label={`${t("order_coupon_label")} (${order.coupon})`} value={`- ${money(order.discount)}`} />}
          <div style={{ height: 1, background: COLORS.line, margin: "10px 0" }} />
          <Row label={t("cart_total")} value={money(order.total)} bold />
        </div>
      </div>
    </div>
  );
}

function AccountScreen({ user, onLoginTap, onLogout, onOpenOrders, onOpenFavorites, onOpenNotifications, onOpenContact, onOpenEditProfile, onOpenDeals, onOpenMyReviews, onOpenAbout, onOpenVendor, ordersCount, favoritesCount, unreadCount, lang, setLang, theme, setTheme, loyaltyPoints, notifPrefs, setNotifPrefs, t }) {
  const initials = user ? user.name.trim().slice(0, 2).toUpperCase() : "?";
  const referralCode = getReferralCode(user);

  const quickLinks = [
    { id: "orders", label: t("account_orders"), icon: ClipboardList, onClick: onOpenOrders, active: true },
    { id: "favorites", label: t("account_favorites"), icon: Heart, onClick: onOpenFavorites, active: true },
    { id: "coupons", label: t("account_coupons"), icon: Tag, onClick: onOpenDeals, active: true },
    { id: "reviews", label: t("account_reviews"), icon: MessageSquare, onClick: onOpenMyReviews, active: true },
  ];

  const toggleNotifPref = (key) => {
    setNotifPrefs((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const shareReferral = () => {
    const text = t("referral_share_text").replace("{code}", referralCode);
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, "_blank");
  };

  return (
    <div dir={STRINGS[lang].dir}>
      {/* header */}
      <div style={{ padding: "20px 18px 16px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div
            style={{
              width: 56,
              height: 56,
              borderRadius: "50%",
              background: user ? `linear-gradient(135deg, ${COLORS.gold}, ${COLORS.green})` : COLORS.greenSoft,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}
          >
            {user ? (
              <span style={{ color: "#fff", fontFamily: "Tajawal", fontWeight: 800, fontSize: 18 }}>{initials}</span>
            ) : (
              <User size={24} color={COLORS.green} />
            )}
          </div>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 16, color: COLORS.ink }}>
                {user ? user.name : t("account_title")}
              </span>
              {user && (
                <button onClick={onOpenEditProfile} style={{ border: "none", background: "none", cursor: "pointer", display: "flex", padding: 0 }}>
                  <Edit3 size={13} color={COLORS.inkMuted} />
                </button>
              )}
            </div>
            {user && (
              <div style={{ fontFamily: "Cairo", fontSize: 12, color: COLORS.inkMuted, marginTop: 2 }} dir="ltr">
                {user.email || user.phone}
              </div>
            )}
          </div>
        </div>
        <button
          onClick={onOpenNotifications}
          style={{ position: "relative", width: 38, height: 38, borderRadius: "50%", background: COLORS.surface, border: `1px solid ${COLORS.line}`, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}
        >
          <Bell size={17} color={COLORS.ink} />
          {unreadCount > 0 && (
            <span style={{ position: "absolute", top: -2, insetInlineEnd: -2, background: COLORS.danger, color: "#fff", fontSize: 9, fontWeight: 700, borderRadius: 8, minWidth: 15, height: 15, display: "flex", alignItems: "center", justifyContent: "center" }}>
              {unreadCount}
            </span>
          )}
        </button>
      </div>

      <div style={{ padding: "0 18px" }}>
        {user && (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              background: `linear-gradient(120deg, ${COLORS.green}, ${COLORS.greenDark})`,
              borderRadius: 16,
              padding: "14px 16px",
              marginBottom: 16,
            }}
          >
            <div>
              <div style={{ fontFamily: "Cairo", fontSize: 11.5, color: "rgba(255,255,255,0.75)", marginBottom: 3 }}>
                {t("loyalty_points_label")}
              </div>
              <div style={{ fontFamily: "Tajawal", fontWeight: 800, fontSize: 20, color: "#fff" }}>
                {t("loyalty_points_balance").replace("{n}", loyaltyPoints)}
              </div>
            </div>
            <div style={{ width: 42, height: 42, borderRadius: "50%", background: "rgba(255,255,255,0.15)", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Tag size={19} color={COLORS.gold} />
            </div>
          </div>
        )}

        {user && (
          <div
            style={{
              background: COLORS.surface,
              border: `1px solid ${COLORS.line}`,
              borderRadius: 16,
              padding: 14,
              marginBottom: 16,
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
              <Send size={14} color={COLORS.green} />
              <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.ink }}>{t("referral_title")}</span>
            </div>
            <p style={{ fontFamily: "Cairo", fontSize: 11.5, color: COLORS.inkMuted, lineHeight: 1.7, margin: "0 0 12px" }}>
              {t("referral_desc")}
            </p>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <div
                style={{
                  flex: 1,
                  background: COLORS.greenSoft,
                  border: `1px dashed ${COLORS.green}`,
                  borderRadius: 10,
                  padding: "9px 12px",
                  fontFamily: "Tajawal",
                  fontWeight: 800,
                  fontSize: 15,
                  color: COLORS.green,
                  textAlign: "center",
                  letterSpacing: 1,
                }}
                dir="ltr"
              >
                {referralCode}
              </div>
              <button
                onClick={shareReferral}
                style={{ background: COLORS.green, color: "#fff", border: "none", borderRadius: 10, padding: "10px 14px", fontFamily: "Cairo", fontWeight: 700, fontSize: 12, cursor: "pointer", flexShrink: 0 }}
              >
                {t("referral_share_btn")}
              </button>
            </div>
          </div>
        )}

        {/* language switcher */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.inkMuted }}>{t("account_language")}</span>
          <LangSwitch lang={lang} setLang={setLang} />
        </div>

        {/* dark mode toggle */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.inkMuted }}>{t("dark_mode_label")}</span>
          <button
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            style={{
              width: 52,
              height: 30,
              borderRadius: 20,
              border: `1px solid ${COLORS.line}`,
              background: theme === "dark" ? COLORS.green : COLORS.surface,
              position: "relative",
              cursor: "pointer",
              padding: 0,
            }}
          >
            <div
              style={{
                position: "absolute",
                top: 2,
                insetInlineStart: theme === "dark" ? 24 : 2,
                width: 24,
                height: 24,
                borderRadius: "50%",
                background: theme === "dark" ? "#fff" : COLORS.green,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                transition: "inset-inline-start 0.2s ease",
              }}
            >
              {theme === "dark" ? <Moon size={13} color={COLORS.green} /> : <Sun size={13} color="#fff" />}
            </div>
          </button>
        </div>

        {/* notification preferences */}
        <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 16, padding: 14, marginBottom: 16 }}>
          <div style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12.5, color: COLORS.ink, marginBottom: 10 }}>
            {t("notif_prefs_title")}
          </div>
          {[
            { key: "orderUpdates", label: t("notif_pref_order_updates") },
            { key: "cartReminders", label: t("notif_pref_cart_reminders") },
            { key: "promotions", label: t("notif_pref_promotions") },
          ].map((pref, i) => (
            <div
              key={pref.key}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                paddingTop: i > 0 ? 10 : 0,
                marginTop: i > 0 ? 10 : 0,
                borderTop: i > 0 ? `1px solid ${COLORS.line}` : "none",
              }}
            >
              <span style={{ fontFamily: "Cairo", fontSize: 12, color: COLORS.ink }}>{pref.label}</span>
              <button
                onClick={() => toggleNotifPref(pref.key)}
                style={{
                  width: 40,
                  height: 24,
                  borderRadius: 14,
                  border: `1px solid ${COLORS.line}`,
                  background: notifPrefs[pref.key] ? COLORS.green : COLORS.bg,
                  position: "relative",
                  cursor: "pointer",
                  padding: 0,
                  flexShrink: 0,
                }}
              >
                <div
                  style={{
                    position: "absolute",
                    top: 2,
                    insetInlineStart: notifPrefs[pref.key] ? 18 : 2,
                    width: 18,
                    height: 18,
                    borderRadius: "50%",
                    background: notifPrefs[pref.key] ? "#fff" : COLORS.inkMuted,
                    transition: "inset-inline-start 0.2s ease",
                  }}
                />
              </button>
            </div>
          ))}
        </div>

        {!user && (
          <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 16, padding: "20px 16px", textAlign: "center", marginBottom: 16 }}>
            <p style={{ fontFamily: "Cairo", color: COLORS.inkMuted, fontSize: 13, marginBottom: 14 }}>
              {t("account_login_prompt")}
            </p>
            <button
              onClick={onLoginTap}
              style={{ background: COLORS.green, color: "#fff", border: "none", borderRadius: 12, padding: "12px 30px", fontFamily: "Cairo", fontWeight: 700, fontSize: 13, cursor: "pointer" }}
            >
              {t("account_login_cta")}
            </button>
          </div>
        )}

        {/* quick access grid */}
        <div
          style={{
            background: COLORS.surface,
            border: `1px solid ${COLORS.line}`,
            borderRadius: 16,
            padding: "16px 4px",
            display: "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            marginBottom: 12,
          }}
        >
          {quickLinks.map((q) => {
            const Icon = q.icon;
            return (
              <button
                key={q.id}
                onClick={q.onClick}
                style={{
                  border: "none",
                  background: "none",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 6,
                  cursor: q.onClick ? "pointer" : "default",
                  padding: "4px 2px",
                  position: "relative",
                }}
              >
                <Icon size={20} color={q.active ? COLORS.green : COLORS.inkMuted} />
                <span style={{ fontFamily: "Cairo", fontSize: 10.5, fontWeight: 600, color: COLORS.ink, textAlign: "center", lineHeight: 1.3 }}>
                  {q.label}
                </span>
                {q.id === "orders" && ordersCount > 0 && (
                  <span style={{ position: "absolute", top: 0, insetInlineEnd: "22%", background: COLORS.danger, color: "#fff", fontSize: 9, fontWeight: 700, borderRadius: 8, minWidth: 14, height: 14, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    {ordersCount}
                  </span>
                )}
                {q.id === "favorites" && favoritesCount > 0 && (
                  <span style={{ position: "absolute", top: 0, insetInlineEnd: "22%", background: COLORS.danger, color: "#fff", fontSize: 9, fontWeight: 700, borderRadius: 8, minWidth: 14, height: 14, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    {favoritesCount}
                  </span>
                )}
                {!q.onClick && (
                  <span style={{ fontFamily: "Cairo", fontSize: 8.5, color: COLORS.gold, fontWeight: 700 }}>{t("account_soon")}</span>
                )}
              </button>
            );
          })}
        </div>

        {/* two-column cards */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
          <button
            onClick={onOpenOrders}
            style={{ display: "flex", alignItems: "center", justifyContent: "space-between", background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 14, cursor: "pointer", textAlign: "start" }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <Package size={17} color={COLORS.green} />
              <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.ink }}>{t("account_all_orders")}</span>
            </div>
          </button>
          <button
            onClick={onOpenContact}
            style={{ display: "flex", alignItems: "center", gap: 8, background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 14, cursor: "pointer", textAlign: "start" }}
          >
            <MessageSquare size={17} color={COLORS.green} />
            <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.ink }}>{t("contact_title")}</span>
          </button>
        </div>

        <button
          onClick={onOpenAbout}
          style={{ width: "100%", display: "flex", alignItems: "center", gap: 8, background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 14, cursor: "pointer", textAlign: "start", marginBottom: 10 }}
        >
          <HelpCircle size={17} color={COLORS.green} />
          <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.ink }}>{t("about_title")}</span>
        </button>

        {user?.isVendor && (
          <button
            onClick={onOpenVendor}
            style={{ width: "100%", display: "flex", alignItems: "center", gap: 8, background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 14, cursor: "pointer", textAlign: "start", marginBottom: 20 }}
          >
            <Package size={17} color={COLORS.green} />
            <span style={{ fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: COLORS.ink }}>{t("vendor_panel_label")}</span>
          </button>
        )}

        {user && (
          <button
            onClick={onLogout}
            style={{ width: "100%", border: `1px solid ${COLORS.line}`, background: "none", borderRadius: 12, padding: "12px 0", fontFamily: "Cairo", fontWeight: 700, fontSize: 13, color: COLORS.danger, cursor: "pointer", marginBottom: 24 }}
          >
            {t("account_logout")}
          </button>
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------
   bottom nav
--------------------------------------------------- */
function BottomNav({ screen, setScreen, cartCount, t }) {
  const items = [
    { id: "home", label: t("nav_home"), icon: HomeIcon },
    { id: "cart", label: t("nav_cart"), icon: ShoppingCart },
    { id: "account", label: t("nav_account"), icon: User },
  ];
  return (
    <div
      style={{
        position: "fixed",
        bottom: 0,
        left: "50%",
        transform: "translateX(-50%)",
        width: "100%",
        maxWidth: 390,
        background: COLORS.surface,
        borderTop: `1px solid ${COLORS.line}`,
        display: "flex",
        padding: "10px 10px 14px",
        zIndex: 10,
      }}
    >
      {items.map((it) => {
        const Icon = it.icon;
        const active = screen === it.id;
        return (
          <button
            key={it.id}
            onClick={() => setScreen(it.id)}
            style={{
              flex: 1,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: 3,
              border: "none",
              background: "none",
              cursor: "pointer",
              position: "relative",
            }}
          >
            <Icon size={20} color={active ? COLORS.green : COLORS.inkMuted} />
            {it.id === "cart" && cartCount > 0 && (
              <span
                style={{
                  position: "absolute",
                  top: -4,
                  right: "34%",
                  background: COLORS.danger,
                  color: "#fff",
                  fontSize: 9,
                  fontWeight: 700,
                  borderRadius: 8,
                  minWidth: 15,
                  height: 15,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  padding: "0 3px",
                }}
              >
                {cartCount}
              </span>
            )}
            <span style={{ fontFamily: "Cairo", fontSize: 10, fontWeight: 600, color: active ? COLORS.green : COLORS.inkMuted }}>
              {it.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}

/* ---------------------------------------------------
   persistence helpers
--------------------------------------------------- */
const STORAGE_KEYS = {
  cart: "akumu_cart",
  favorites: "akumu_favorites",
  user: "akumu_user",
  orders: "akumu_orders",
  addresses: "akumu_addresses",
  lang: "akumu_lang",
  theme: "akumu_theme",
  recentlyViewed: "akumu_recently_viewed",
  compare: "akumu_compare",
  onboarded: "akumu_onboarded",
  stockAlerts: "akumu_stock_alerts",
  loyaltyPoints: "akumu_loyalty_points",
  searchHistory: "akumu_search_history",
  notifPrefs: "akumu_notif_prefs",
  vendorProducts: "akumu_vendor_products",
};

async function loadJSON(key, fallback) {
  try {
    if (!window.storage) return fallback;
    const res = await window.storage.get(key).catch(() => null);
    return res?.value ? JSON.parse(res.value) : fallback;
  } catch (e) {
    return fallback;
  }
}
async function saveJSON(key, value) {
  try {
    if (!window.storage) return;
    await window.storage.set(key, JSON.stringify(value));
  } catch (e) {
    /* best-effort */
  }
}

/* ---------------------------------------------------
   root app
--------------------------------------------------- */
export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [screen, setScreen] = useState("home");
  const [cart, setCart] = useState({});
  const [activeCat, setActiveCat] = useState("all");
  const [search, setSearch] = useState("");
  const [user, setUser] = useState(null);
  const [addresses, setAddresses] = useState([]);
  const [selectedAddressId, setSelectedAddressId] = useState(null);
  const [payment, setPayment] = useState("cod");
  const [orderId, setOrderId] = useState(null);
  const [wasFirstOrder, setWasFirstOrder] = useState(false);
  const [orders, setOrders] = useState([]);
  const [openOrderId, setOpenOrderId] = useState(null);
  const [openProductId, setOpenProductId] = useState(null);
  const [postLoginTarget, setPostLoginTarget] = useState("checkout");
  const [lang, setLang] = useState("ar");
  const [favorites, setFavorites] = useState({});
  const [reviews, setReviews] = useState({});
  const [questions, setQuestions] = useState({});
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [toast, setToast] = useState(null);
  const [couponCode, setCouponCode] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState(null);
  const [couponError, setCouponError] = useState("");
  const [hydrated, setHydrated] = useState(false);
  const [theme, setTheme] = useState("light");
  const [recentlyViewed, setRecentlyViewed] = useState([]);
  const [compareIds, setCompareIds] = useState([]);
  const [compareOrigin, setCompareOrigin] = useState("home");
  const [onboarded, setOnboarded] = useState(true);
  const [stockAlerts, setStockAlerts] = useState([]);
  const [loyaltyPoints, setLoyaltyPoints] = useState(0);
  const [redeemPoints, setRedeemPoints] = useState(false);
  const [deliverySlot, setDeliverySlot] = useState("any");
  const [giftWrap, setGiftWrap] = useState(false);
  const [giftMessage, setGiftMessage] = useState("");
  const [searchHistory, setSearchHistory] = useState([]);
  const [notifPrefs, setNotifPrefs] = useState({ orderUpdates: true, cartReminders: true, promotions: true });
  const [chatOpen, setChatOpen] = useState(false);
  const [productsTick, setProductsTick] = useState(0);
  const [chatMessages, setChatMessages] = useState([]);
  const cartReminderSentRef = useRef(false);
  const t = (key) => STRINGS[lang][key] || key;

  // Sync the module-level theme flag synchronously during render, before any
  // child component reads COLORS.xxx (see PALETTES / COLORS Proxy above).
  CURRENT_THEME = theme;

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 3000);
    return () => clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 1600);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    setChatMessages([{ from: "bot", text: t("chat_welcome_message") }]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const sendChatMessage = (text) => {
    setChatMessages((prev) => [...prev, { from: "user", text }]);
    setTimeout(() => {
      setChatMessages((prev) => [...prev, { from: "bot", text: t("chat_auto_reply") }]);
    }, 900);
  };

  // hydrate everything that should survive a reload
  useEffect(() => {
    (async () => {
      const [
        savedCart,
        savedFavs,
        savedUser,
        savedOrders,
        savedAddresses,
        savedLang,
        savedTheme,
        savedRecentlyViewed,
        savedCompare,
        savedOnboarded,
        savedStockAlerts,
        savedLoyaltyPoints,
        savedSearchHistory,
        savedNotifPrefs,
        savedVendorProducts,
      ] = await Promise.all([
        loadJSON(STORAGE_KEYS.cart, {}),
        loadJSON(STORAGE_KEYS.favorites, {}),
        loadJSON(STORAGE_KEYS.user, null),
        loadJSON(STORAGE_KEYS.orders, []),
        loadJSON(STORAGE_KEYS.addresses, []),
        loadJSON(STORAGE_KEYS.lang, "ar"),
        loadJSON(STORAGE_KEYS.theme, "light"),
        loadJSON(STORAGE_KEYS.recentlyViewed, []),
        loadJSON(STORAGE_KEYS.compare, []),
        loadJSON(STORAGE_KEYS.onboarded, false),
        loadJSON(STORAGE_KEYS.stockAlerts, []),
        loadJSON(STORAGE_KEYS.loyaltyPoints, 0),
        loadJSON(STORAGE_KEYS.searchHistory, []),
        loadJSON(STORAGE_KEYS.notifPrefs, { orderUpdates: true, cartReminders: true, promotions: true }),
        loadJSON(STORAGE_KEYS.vendorProducts, null),
      ]);
      setCart(savedCart);
      setFavorites(savedFavs);
      setUser(savedUser);
      setOrders(savedOrders);
      setAddresses(savedAddresses);
      if (savedAddresses.length > 0) setSelectedAddressId(savedAddresses[0].id);
      setLang(savedLang);
      setTheme(savedTheme);
      setRecentlyViewed(savedRecentlyViewed);
      setCompareIds(savedCompare);
      setOnboarded(savedOnboarded);
      setStockAlerts(savedStockAlerts);
      setLoyaltyPoints(savedLoyaltyPoints);
      setSearchHistory(savedSearchHistory);
      setNotifPrefs(savedNotifPrefs);
      if (savedVendorProducts && savedVendorProducts.length > 0) {
        PRODUCTS.length = 0;
        PRODUCTS.push(...savedVendorProducts);
        setProductsTick((t) => t + 1);
      }
      setHydrated(true);
    })();
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    saveJSON(STORAGE_KEYS.cart, cart);
  }, [cart, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    saveJSON(STORAGE_KEYS.favorites, favorites);
  }, [favorites, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    saveJSON(STORAGE_KEYS.user, user);
  }, [user, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    saveJSON(STORAGE_KEYS.orders, orders);
  }, [orders, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    saveJSON(STORAGE_KEYS.addresses, addresses);
  }, [addresses, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    saveJSON(STORAGE_KEYS.lang, lang);
  }, [lang, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    saveJSON(STORAGE_KEYS.theme, theme);
  }, [theme, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    saveJSON(STORAGE_KEYS.recentlyViewed, recentlyViewed);
  }, [recentlyViewed, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    saveJSON(STORAGE_KEYS.compare, compareIds);
  }, [compareIds, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    saveJSON(STORAGE_KEYS.onboarded, onboarded);
  }, [onboarded, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    saveJSON(STORAGE_KEYS.stockAlerts, stockAlerts);
  }, [stockAlerts, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    saveJSON(STORAGE_KEYS.loyaltyPoints, loyaltyPoints);
  }, [loyaltyPoints, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    saveJSON(STORAGE_KEYS.searchHistory, searchHistory);
  }, [searchHistory, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    saveJSON(STORAGE_KEYS.notifPrefs, notifPrefs);
  }, [notifPrefs, hydrated]);

  const toggleFavorite = (id) => {
    setFavorites((prev) => {
      const next = { ...prev };
      if (next[id]) delete next[id];
      else next[id] = true;
      return next;
    });
  };
  const favoritesCount = Object.keys(favorites).length;

  const commitSearch = (term) => {
    const trimmed = term.trim();
    if (!trimmed) return;
    setSearchHistory((prev) => [trimmed, ...prev.filter((s) => s !== trimmed)].slice(0, 6));
  };
  const clearSearchHistory = () => setSearchHistory([]);

  const addReview = (productId, review) => {
    setReviews((prev) => {
      const next = { ...prev };
      next[productId] = [...(next[productId] || []), review];
      return next;
    });
  };

  const addQuestion = (productId, question) => {
    setQuestions((prev) => {
      const next = { ...prev };
      next[productId] = [...(next[productId] || []), question];
      return next;
    });
  };

  const saveVendorProduct = (data, editingId) => {
    if (editingId) {
      const existing = PRODUCTS.find((p) => p.id === editingId);
      if (existing) {
        existing.name = data.name;
        existing.cat = data.cat;
        existing.price = data.price;
        existing.stock = data.stock;
        existing.sizes = data.sizes;
        existing.colors = data.colors;
      }
    } else {
      const newId = Math.max(0, ...PRODUCTS.map((p) => p.id)) + 1;
      const seed = `vendor${newId}`;
      PRODUCTS.push({
        id: newId,
        name: data.name,
        cat: data.cat,
        price: data.price,
        seed,
        img: `https://picsum.photos/seed/${seed}/400/400`,
        rating: 4.5,
        sizes: data.sizes,
        colors: data.colors,
        stock: data.stock,
      });
    }
    saveJSON(STORAGE_KEYS.vendorProducts, PRODUCTS);
    setProductsTick((t) => t + 1);
    setToast(t("vendor_product_saved_toast"));
  };

  const deleteVendorProduct = (id) => {
    const idx = PRODUCTS.findIndex((p) => p.id === id);
    if (idx !== -1) PRODUCTS.splice(idx, 1);
    saveJSON(STORAGE_KEYS.vendorProducts, PRODUCTS);
    setProductsTick((tk) => tk + 1);

    // a deleted product must not leave dangling references anywhere else in
    // the app, or the next render of cart/checkout logic would crash trying
    // to read .price/.name off an undefined PRODUCTS.find() result
    setCart((prev) => {
      const next = {};
      Object.entries(prev).forEach(([key, entry]) => {
        if (entry.productId !== id) next[key] = entry;
      });
      return next;
    });
    setFavorites((prev) => {
      if (!prev[id]) return prev;
      const next = { ...prev };
      delete next[id];
      return next;
    });
    setCompareIds((prev) => prev.filter((pid) => pid !== id));
    setStockAlerts((prev) => prev.filter((pid) => pid !== id));
    setRecentlyViewed((prev) => prev.filter((pid) => pid !== id));

    setToast(t("vendor_product_deleted_toast"));
  };

  const addAddress = ({ label, text }) => {
    const id = Date.now();
    setAddresses((prev) => [...prev, { id, label, text }]);
    setSelectedAddressId(id);
  };

  const updateAddress = (id, { label, text }) => {
    setAddresses((prev) => prev.map((a) => (a.id === id ? { ...a, label, text } : a)));
  };

  const removeAddress = (id) => {
    setAddresses((prev) => {
      const next = prev.filter((a) => a.id !== id);
      if (selectedAddressId === id) {
        setSelectedAddressId(next.length > 0 ? next[0].id : null);
      }
      return next;
    });
    setToast(t("address_deleted_toast"));
  };

  const toggleStockAlert = (productId) => {
    setStockAlerts((prev) => {
      if (prev.includes(productId)) return prev.filter((id) => id !== productId);
      setToast(t("notify_stock_toast"));
      return [...prev, productId];
    });
  };

  const applyCoupon = () => {
    const code = couponCode.trim().toUpperCase();
    const found = COUPONS[code];
    if (!found) {
      setCouponError(t("coupon_invalid"));
      setAppliedCoupon(null);
      return;
    }
    setAppliedCoupon({ code, ...found });
    setCouponError("");
  };
  const removeCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode("");
    setCouponError("");
  };

  const addToCart = (productId, size, color, delta) => {
    const key = variantKey(productId, size, color);
    const product = PRODUCTS.find((p) => p.id === productId);
    const maxQty = product ? product.stock : 99;
    setCart((prev) => {
      const next = { ...prev };
      const existingQty = next[key]?.qty || 0;
      const newQty = Math.max(0, Math.min(maxQty, existingQty + delta));
      if (newQty === 0) delete next[key];
      else next[key] = { productId, size, color, qty: newQty };
      return next;
    });
  };
  const removeFromCart = (key) => {
    setCart((prev) => {
      const next = { ...prev };
      delete next[key];
      return next;
    });
  };

  const removeMultipleFromCart = (keys) => {
    setCart((prev) => {
      const next = { ...prev };
      keys.forEach((key) => delete next[key]);
      return next;
    });
  };

  const subtotal = useMemo(
    () => Object.values(cart).reduce((sum, entry) => sum + PRODUCTS.find((p) => p.id === entry.productId).price * entry.qty, 0),
    [cart]
  );
  const cartCount = Object.values(cart).reduce((a, entry) => a + entry.qty, 0);

  const discountAmount = useMemo(() => {
    if (!appliedCoupon) return 0;
    if (appliedCoupon.type === "percent") return Math.round((subtotal * appliedCoupon.value) / 100);
    return Math.min(appliedCoupon.value, subtotal);
  }, [appliedCoupon, subtotal]);

  const pointsDiscount = redeemPoints && loyaltyPoints >= 100 ? 5000 : 0;
  const totalDiscount = discountAmount + pointsDiscount;

  const goCheckout = () => {
    if (!user) {
      setPostLoginTarget("checkout");
      setScreen("login");
    } else {
      setScreen("checkout");
    }
  };

  const handleLogin = (u) => {
    setUser(u);
    setScreen(postLoginTarget);
  };

  const handleConfirmOrder = () => {
    const newId = Math.floor(100000 + Math.random() * 900000);
    const items = Object.values(cart).map((entry) => {
      const p = PRODUCTS.find((x) => x.id === entry.productId);
      return { id: p.id, name: p.name, price: p.price, qty: entry.qty, size: entry.size, color: entry.color };
    });
    const delivery = getDelivery(subtotal);
    const giftWrapFee = giftWrap ? 5000 : 0;
    const isFirstOrder = orders.length === 0;
    const selected = addresses.find((a) => a.id === selectedAddressId);
    const orderTotal = subtotal + delivery + giftWrapFee - totalDiscount;
    const earnedPoints = Math.max(0, Math.floor(orderTotal / 1000));
    const newOrder = {
      id: newId,
      items,
      address: selected ? `${selected.label} - ${selected.text}` : "",
      payment,
      deliverySlot,
      giftWrap,
      giftMessage: giftWrap ? giftMessage.trim() : "",
      coupon: appliedCoupon ? appliedCoupon.code : null,
      discount: totalDiscount,
      pointsRedeemed: pointsDiscount > 0 ? 100 : 0,
      pointsEarned: earnedPoints,
      total: orderTotal,
      date: new Date().toLocaleDateString("ar-SY", { year: "numeric", month: "long", day: "numeric" }),
      stepIndex: 0,
    };
    setOrders((prev) => [...prev, newOrder]);
    setOrderId(newId);
    setWasFirstOrder(isFirstOrder);
    setCart({});
    setCouponCode("");
    setAppliedCoupon(null);
    setCouponError("");
    setRedeemPoints(false);
    setDeliverySlot("any");
    setGiftWrap(false);
    setGiftMessage("");
    setLoyaltyPoints((prev) => prev - (pointsDiscount > 0 ? 100 : 0) + earnedPoints);
    if (earnedPoints > 0) {
      pushNotification(t("loyalty_earned_toast").replace("{n}", earnedPoints));
    }
    setScreen("confirm");
  };

  const pushNotification = (text) => {
    const time = new Date().toLocaleTimeString("ar-SY", { hour: "2-digit", minute: "2-digit" });
    setNotifications((prev) => [...prev, { id: Date.now(), text, time }]);
    setUnreadCount((n) => n + 1);
    setToast(text);
  };

  // simulated abandoned-cart reminder: if items sit in the cart for a while
  // without reaching checkout, nudge the user with a notification + toast
  useEffect(() => {
    if (cartCount === 0) {
      cartReminderSentRef.current = false;
      return;
    }
    if (screen === "checkout" || screen === "confirm" || cartReminderSentRef.current || !notifPrefs.cartReminders) return;
    const timer = setTimeout(() => {
      pushNotification(t("notif_cart_reminder").replace("{n}", cartCount));
      cartReminderSentRef.current = true;
    }, 40000);
    return () => clearTimeout(timer);
  }, [cartCount, screen, notifPrefs.cartReminders]);

  const advanceOrderStatus = (id) => {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id !== id) return o;
        const nextIndex = Math.min(o.stepIndex + 1, ORDER_STEP_KEYS.length - 1);
        if (notifPrefs.orderUpdates) {
          pushNotification(t("notif_status_change").replace("{id}", o.id).replace("{status}", t(`order_step_${ORDER_STEP_KEYS[nextIndex]}`)));
        }
        return { ...o, stepIndex: nextIndex };
      })
    );
  };

  const cancelOrder = (id) => {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id !== id) return o;
        if (notifPrefs.orderUpdates) {
          pushNotification(t("notif_order_cancelled").replace("{id}", o.id));
        }
        return { ...o, cancelled: true };
      })
    );
  };

  const requestReturn = (id, { type, reason }) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === id ? { ...o, returnRequest: { type, reason, status: "pending" } } : o))
    );
    setToast(t("return_already_requested"));
  };

  const reorderItems = (order) => {
    let addedAny = false;
    order.items.forEach((it) => {
      const product = PRODUCTS.find((p) => p.id === it.id);
      if (!product || product.stock <= 0) return;
      addToCart(product.id, it.size || product.sizes[0], it.color || product.colors[0], Math.min(it.qty, product.stock));
      addedAny = true;
    });
    setToast(addedAny ? t("reorder_added_toast") : t("reorder_none_available"));
    if (addedAny) setScreen("cart");
  };

  const openOrder = (id) => {
    setOpenOrderId(id);
    setScreen("orderDetail");
  };

  const openProduct = (id) => {
    setOpenProductId(id);
    setScreen("productDetail");
    setRecentlyViewed((prev) => [id, ...prev.filter((x) => x !== id)].slice(0, 8));
  };

  const toggleCompare = (id) => {
    setCompareIds((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      if (prev.length >= 3) {
        setToast(t("compare_max_reached"));
        return prev;
      }
      return [...prev, id];
    });
  };

  const openNotifications = () => {
    setUnreadCount(0);
    setScreen("notifications");
  };

  const openCompare = () => {
    setCompareOrigin(screen);
    setScreen("compare");
  };

  const handleLogout = () => {
    setUser(null);
    setScreen("account");
  };

  if (showSplash) {
    return (
      <div
        style={{
          minHeight: "100vh",
          display: "flex",
          justifyContent: "center",
          fontFamily: "Cairo",
          background: `linear-gradient(160deg, ${COLORS.greenDark}, ${COLORS.green})`,
        }}
      >
        <style>{FONT_IMPORT}</style>
        <div
          style={{
            width: "100%",
            maxWidth: 390,
            minHeight: "100vh",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            animation: "ak-fadein 0.5s ease",
          }}
        >
          <img src={WORDMARK_IMG} alt="Akumu" style={{ width: "72%", maxWidth: 260 }} />
        </div>
      </div>
    );
  }

  if (hydrated && !onboarded) {
    return (
      <div style={{ minHeight: "100vh", background: COLORS.frame, display: "flex", justifyContent: "center", fontFamily: "Cairo" }}>
        <style>{FONT_IMPORT}</style>
        <div
          dir={STRINGS[lang].dir}
          style={{
            width: "100%",
            maxWidth: 390,
            minHeight: "100vh",
            position: "relative",
            boxShadow: "0 0 40px rgba(0,0,0,0.08)",
          }}
        >
          <OnboardingScreen lang={lang} onFinish={() => setOnboarded(true)} t={t} />
        </div>
      </div>
    );
  }

  let body;
  if (screen === "home") {
    body = (
      <HomeScreen cart={cart} addToCart={addToCart} activeCat={activeCat} setActiveCat={setActiveCat} search={search} setSearch={setSearch} favorites={favorites} toggleFavorite={toggleFavorite} onOpenProduct={openProduct} lang={lang} recentlyViewed={recentlyViewed} searchHistory={searchHistory} onCommitSearch={commitSearch} onClearSearchHistory={clearSearchHistory} t={t} />
    );
  } else if (screen === "cart") {
    body = <CartScreen cart={cart} addToCart={addToCart} removeFromCart={removeFromCart} onRemoveMultiple={removeMultipleFromCart} subtotal={subtotal} goCheckout={goCheckout} onGoHome={() => setScreen("home")} onOpenProduct={openProduct} t={t} />;
  } else if (screen === "login") {
    body = <LoginScreen onLogin={handleLogin} onBack={() => setScreen("home")} lang={lang} t={t} />;
  } else if (screen === "checkout") {
    body = (
      <CheckoutScreen
        subtotal={subtotal}
        itemCount={cartCount}
        addresses={addresses}
        selectedAddressId={selectedAddressId}
        setSelectedAddressId={setSelectedAddressId}
        addAddress={addAddress}
        updateAddress={updateAddress}
        removeAddress={removeAddress}
        payment={payment}
        setPayment={setPayment}
        couponCode={couponCode}
        setCouponCode={setCouponCode}
        appliedCoupon={appliedCoupon}
        couponError={couponError}
        applyCoupon={applyCoupon}
        removeCoupon={removeCoupon}
        discountAmount={totalDiscount}
        loyaltyPoints={loyaltyPoints}
        redeemPoints={redeemPoints}
        setRedeemPoints={setRedeemPoints}
        pointsDiscount={pointsDiscount}
        deliverySlot={deliverySlot}
        setDeliverySlot={setDeliverySlot}
        giftWrap={giftWrap}
        setGiftWrap={setGiftWrap}
        giftMessage={giftMessage}
        setGiftMessage={setGiftMessage}
        onBack={() => setScreen("cart")}
        onConfirm={handleConfirmOrder}
        t={t}
      />
    );
  } else if (screen === "confirm") {
    body = (
      <ConfirmScreen
        orderId={orderId}
        isFirstOrder={wasFirstOrder}
        onHome={() => setScreen("home")}
        onTrack={() => openOrder(orderId)}
        t={t}
      />
    );
  } else if (screen === "account") {
    body = (
      <AccountScreen
        user={user}
        onLoginTap={() => { setPostLoginTarget("account"); setScreen("login"); }}
        onLogout={handleLogout}
        onOpenOrders={() => setScreen("orders")}
        onOpenFavorites={() => setScreen("favorites")}
        onOpenNotifications={openNotifications}
        onOpenContact={() => setScreen("contact")}
        onOpenEditProfile={() => setScreen("editProfile")}
        onOpenDeals={() => setScreen("deals")}
        onOpenMyReviews={() => setScreen("myReviews")}
        onOpenAbout={() => setScreen("about")}
        onOpenVendor={() => setScreen("vendorPin")}
        ordersCount={orders.length}
        favoritesCount={favoritesCount}
        unreadCount={unreadCount}
        lang={lang}
        setLang={setLang}
        theme={theme}
        setTheme={setTheme}
        loyaltyPoints={loyaltyPoints}
        notifPrefs={notifPrefs}
        setNotifPrefs={setNotifPrefs}
        t={t}
      />
    );
  } else if (screen === "orders") {
    body = <OrdersScreen orders={orders} onBack={() => setScreen("account")} onOpenOrder={openOrder} t={t} />;
  } else if (screen === "favorites") {
    body = (
      <FavoritesScreen
        favorites={favorites}
        toggleFavorite={toggleFavorite}
        cart={cart}
        addToCart={addToCart}
        onBack={() => setScreen("account")}
        onGoHome={() => setScreen("home")}
        t={t}
      />
    );
  } else if (screen === "notifications") {
    body = <NotificationsScreen notifications={notifications} onBack={() => setScreen("account")} t={t} />;
  } else if (screen === "contact") {
    body = <ContactScreen onBack={() => setScreen("account")} lang={lang} t={t} />;
  } else if (screen === "deals") {
    body = <DealsScreen onBack={() => setScreen("account")} onOpenProduct={openProduct} lang={lang} t={t} />;
  } else if (screen === "myReviews") {
    body = <MyReviewsScreen reviews={reviews} user={user} onBack={() => setScreen("account")} onOpenProduct={openProduct} t={t} />;
  } else if (screen === "about") {
    body = <AboutScreen onBack={() => setScreen("account")} t={t} />;
  } else if (screen === "vendorPin") {
    body = <VendorPinGateScreen user={user} onSuccess={() => setScreen("vendor")} onBack={() => setScreen("account")} t={t} />;
  } else if (screen === "vendor") {
    body = (
      <VendorScreen
        orders={orders}
        onAdvanceOrder={advanceOrderStatus}
        onBack={() => setScreen("account")}
        onSaveProduct={saveVendorProduct}
        onDeleteProduct={deleteVendorProduct}
        onGoStorefront={() => setScreen("home")}
        t={t}
      />
    );
  } else if (screen === "editProfile") {
    body = (
      <EditProfileScreen
        user={user}
        onSave={(updated) => setUser((prev) => ({ ...prev, ...updated }))}
        onBack={() => setScreen("account")}
        t={t}
      />
    );
  } else if (screen === "productDetail") {
    body = (
      <ProductDetailScreen
        product={PRODUCTS.find((p) => p.id === openProductId)}
        cart={cart}
        addToCart={addToCart}
        favorites={favorites}
        toggleFavorite={toggleFavorite}
        reviews={reviews}
        addReview={addReview}
        questions={questions}
        addQuestion={addQuestion}
        onBack={() => setScreen("home")}
        onOpenProduct={openProduct}
        compareIds={compareIds}
        toggleCompare={toggleCompare}
        stockAlerts={stockAlerts}
        toggleStockAlert={toggleStockAlert}
        user={user}
        t={t}
      />
    );
  } else if (screen === "compare") {
    body = (
      <CompareScreen
        compareIds={compareIds}
        onRemove={toggleCompare}
        onBack={() => setScreen(compareOrigin)}
        t={t}
      />
    );
  } else if (screen === "orderDetail") {
    body = (
      <OrderDetailScreen
        order={orders.find((o) => o.id === openOrderId)}
        onBack={() => setScreen("orders")}
        onAdvance={advanceOrderStatus}
        onCancel={cancelOrder}
        onRequestReturn={requestReturn}
        onReorder={reorderItems}
        t={t}
      />
    );
  }

  const showNav = ["home", "cart", "account"].includes(screen);

  return (
    <div style={{ minHeight: "100vh", background: COLORS.frame, display: "flex", justifyContent: "center", fontFamily: "Cairo" }}>
      <style>{FONT_IMPORT}</style>
      <div
        dir={STRINGS[lang].dir}
        style={{
          width: "100%",
          maxWidth: 390,
          minHeight: "100vh",
          background: COLORS.bg,
          position: "relative",
          boxShadow: "0 0 40px rgba(0,0,0,0.08)",
        }}
      >
        <div key={screen} style={{ animation: "ak-fadein 0.28s ease" }}>
          {body}
        </div>
        {showNav && <BottomNav screen={screen} setScreen={setScreen} cartCount={cartCount} t={t} />}
        {compareIds.length > 0 && screen === "home" && (
          <CompareBar compareIds={compareIds} onOpenCompare={openCompare} onClear={() => setCompareIds([])} t={t} />
        )}
        {showNav && (
          <ChatWidget open={chatOpen} onToggle={() => setChatOpen((v) => !v)} messages={chatMessages} onSend={sendChatMessage} t={t} />
        )}
        {toast && (
          <div
            style={{
              position: "fixed",
              bottom: showNav ? 90 : 20,
              left: "50%",
              transform: "translateX(-50%)",
              width: "calc(100% - 36px)",
              maxWidth: 354,
              background: COLORS.greenDark,
              color: "#fff",
              borderRadius: 12,
              padding: "12px 16px",
              display: "flex",
              alignItems: "center",
              gap: 8,
              fontFamily: "Cairo",
              fontSize: 12.5,
              fontWeight: 600,
              zIndex: 50,
              boxShadow: "0 8px 24px rgba(0,0,0,0.25)",
            }}
          >
            <Bell size={15} />
            {toast}
          </div>
        )}
      </div>
    </div>
  );
}

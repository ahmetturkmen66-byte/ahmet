// Polyfills the `window.storage` API that this app was originally built
// against (get/set/delete/list, all async, with an optional "shared" flag)
// using the browser's real localStorage. This lets App.jsx run completely
// unmodified in a normal web deployment.

function storageKey(key, shared) {
  return `${shared ? "akumu-shared" : "akumu-local"}:${key}`;
}

window.storage = {
  async get(key, shared = false) {
    try {
      const raw = localStorage.getItem(storageKey(key, shared));
      if (raw === null) return null;
      return { key, value: raw, shared };
    } catch (e) {
      return null;
    }
  },

  async set(key, value, shared = false) {
    try {
      localStorage.setItem(storageKey(key, shared), value);
      return { key, value, shared };
    } catch (e) {
      return null;
    }
  },

  async delete(key, shared = false) {
    try {
      localStorage.removeItem(storageKey(key, shared));
      return { key, deleted: true, shared };
    } catch (e) {
      return null;
    }
  },

  async list(prefix = "", shared = false) {
    try {
      const fullPrefix = storageKey(prefix, shared);
      const keys = Object.keys(localStorage)
        .filter((k) => k.startsWith(fullPrefix))
        .map((k) => k.slice(fullPrefix.length - prefix.length));
      return { keys, prefix, shared };
    } catch (e) {
      return null;
    }
  },
};
